# FILE: mqtt/client.py

import threading
import ssl
import os
import paho.mqtt.client as mqtt
from PySide6.QtCore import QObject, Signal
from core.logger import log

THING_NAME = "simulated-device-py"
CLIENT_ID = f"sdk-python-{THING_NAME}"


class MqttSignals(QObject):
    connection_status = Signal(bool, str)
    message_received = Signal(str, str)
    # New, specific signal for shadow responses
    shadow_response = Signal(str, str, str)  # type ('accepted'/'rejected'), payload, thing_name


class MqttClient(QObject):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = mqtt.Client(client_id=CLIENT_ID)
        self.signals = MqttSignals()
        self.connected = False
        self.subscriptions = []

        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.on_message = self.on_message

    def on_message(self, client, userdata, msg):
        """Routes incoming messages to the appropriate signal."""
        payload = msg.payload.decode()
        topic_parts = msg.topic.split('/')

        # Check if it's a shadow response topic
        if len(topic_parts) > 3 and topic_parts[2] == 'shadow':
            try:
                thing_name = topic_parts[1]
                # e.g., 'get', 'update'
                op = topic_parts[3]
                # e.g., 'accepted', 'rejected'
                status = topic_parts[4]

                if op == 'get' or op == 'update':
                    self.signals.shadow_response.emit(status, payload, thing_name)
                    return
            except IndexError:
                pass  # Not a standard shadow topic, fall through

        # Fallback to generic message signal
        self.signals.message_received.emit(msg.topic, payload)

    # ... (on_connect, on_disconnect, and other methods remain the same) ...
    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.connected = True
            self.signals.connection_status.emit(True, "Successfully connected to broker.")
            log.info("Successfully connected to broker.")
            for topic in self.subscriptions:
                self.client.subscribe(topic)
        else:
            error_msg = f"Connection failed with code: {rc} ({mqtt.connack_string(rc)})"
            self.connected = False
            self.signals.connection_status.emit(False, error_msg)
            log.error(error_msg)

    def on_disconnect(self, client, userdata, rc):
        self.connected = False
        msg = "Disconnected from broker."
        self.signals.connection_status.emit(False, msg)
        log.info(msg)

    def connect_to_broker(self):
        broker_config = self.config.get('mqtt_broker')
        if not broker_config or not broker_config.get('endpoint') or not broker_config.get('use_tls'):
            broker_config = self.config.get('simulation_broker')
            log.info("Using simulation broker...")
        else:
            log.info("Attempting to connect to AWS IoT Core...")

        endpoint = broker_config.get('endpoint')
        port = broker_config.get('port')

        if broker_config.get('use_tls'):
            certs = broker_config.get('certs', {})
            ca_path, cert_path, key_path = certs.get('ca_path'), certs.get('cert_path'), certs.get('key_path')
            if not all(map(lambda p: p and os.path.exists(p), [ca_path, cert_path, key_path])):
                msg = "Error: TLS is enabled but certificate paths are invalid or files do not exist."
                log.error(msg)
                self.signals.connection_status.emit(False, msg)
                return

            self.client.tls_set(ca_certs=ca_path, certfile=cert_path, keyfile=key_path,
                                cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS)

        log.info(f"Connecting to {endpoint}:{port}...")
        thread = threading.Thread(target=self._connect_thread, args=(endpoint, port))
        thread.daemon = True
        thread.start()

    def _connect_thread(self, endpoint, port):
        try:
            self.client.connect(endpoint, port, 60)
            self.client.loop_forever()
        except Exception as e:
            msg = f"Connection error: {e}"
            log.error(msg)
            self.signals.connection_status.emit(False, msg)

    def disconnect(self):
        if self.connected:
            self.client.loop_stop()
            self.client.disconnect()
        self.subscriptions = []

    def subscribe(self, topic):
        if self.connected and topic not in self.subscriptions:
            topic = topic.replace("{thing_name}", THING_NAME)
            self.client.subscribe(topic)
            self.subscriptions.append(topic)
            log.info(f"Subscribed to: {topic}")

    def publish(self, topic, payload, retain=False):
        if self.connected:
            self.client.publish(topic, payload, retain=retain)
