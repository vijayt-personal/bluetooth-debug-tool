# FILE: mqtt/client.py

import threading
import json
import ssl
import os
import paho.mqtt.client as mqtt
from PySide6.QtCore import QObject, Signal

# --- Constants ---
THING_NAME = "simulated-device-py"
CLIENT_ID = f"sdk-python-{THING_NAME}"

class MqttSignals(QObject):
    connection_status = Signal(bool)
    message_received = Signal(str, str)
    log_message = Signal(str)

class MqttClient(QObject):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.client = mqtt.Client(client_id=CLIENT_ID)
        self.signals = MqttSignals()
        self.connected = False
        self.subscriptions = []

        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.client.on_message = self.on_message

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.connected = True
            self.signals.connection_status.emit(True)
            self.signals.log_message.emit("Successfully connected to broker.")
            for topic in self.subscriptions:
                self.client.subscribe(topic)
        else:
            self.signals.log_message.emit(f"Connection failed with code: {rc}")
            self.connected = False
            self.signals.connection_status.emit(False)

    def on_disconnect(self, client, userdata, rc):
        self.connected = False
        self.signals.connection_status.emit(False)
        self.signals.log_message.emit("Disconnected from broker.")

    def on_message(self, client, userdata, msg):
        payload = msg.payload.decode()
        self.signals.message_received.emit(msg.topic, payload)

    def connect_to_broker(self):
        # Decide which broker config to use
        broker_config = self.config.get('mqtt_broker')
        # Fallback to simulation broker if real one is not configured properly
        if not broker_config or not broker_config.get('endpoint') or not broker_config.get('use_tls'):
            broker_config = self.config.get('simulation_broker')
            self.signals.log_message.emit("Using simulation broker...")
        else:
            self.signals.log_message.emit("Attempting to connect to AWS IoT Core...")

        endpoint = broker_config.get('endpoint')
        port = broker_config.get('port')

        if broker_config.get('use_tls'):
            certs = broker_config.get('certs', {})
            ca_path = certs.get('ca_path')
            cert_path = certs.get('cert_path')
            key_path = certs.get('key_path')

            if not all([ca_path, cert_path, key_path, os.path.exists(ca_path), os.path.exists(cert_path), os.path.exists(key_path)]):
                self.signals.log_message.emit("Error: TLS is enabled but certificate paths are invalid or files do not exist. Aborting.")
                return

            self.client.tls_set(ca_certs=ca_path,
                                certfile=cert_path,
                                keyfile=key_path,
                                cert_reqs=ssl.CERT_REQUIRED,
                                tls_version=ssl.PROTOCOL_TLS,
                                ciphers=None)

        self.signals.log_message.emit(f"Connecting to {endpoint}:{port}...")
        thread = threading.Thread(target=self._connect_thread, args=(endpoint, port))
        thread.daemon = True
        thread.start()

    def _connect_thread(self, endpoint, port):
        try:
            self.client.connect(endpoint, port, 60)
            self.client.loop_forever()
        except Exception as e:
            self.signals.log_message.emit(f"Error connecting: {e}")
            self.signals.connection_status.emit(False)

    def disconnect(self):
        self.client.loop_stop()
        self.client.disconnect()
        self.subscriptions = []

    def subscribe(self, topic):
        if self.connected and topic not in self.subscriptions:
            # Replace placeholder with actual thing name
            topic = topic.replace("{thing_name}", THING_NAME)
            self.client.subscribe(topic)
            self.subscriptions.append(topic)
            self.signals.log_message.emit(f"Subscribed to: {topic}")

    def publish(self, topic, payload):
        if self.connected:
            self.client.publish(topic, payload)
            self.signals.log_message.emit(f"Published to {topic}")
