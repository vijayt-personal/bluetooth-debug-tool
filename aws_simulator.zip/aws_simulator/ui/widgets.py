# FILE: ui/widgets.py

import json
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
    QPushButton, QLineEdit, QMessageBox, QTableWidget, QTableWidgetItem,
    QHeaderView
)


class ShadowTab(QWidget):
    def __init__(self, app_state, mqtt_client):
        super().__init__()
        self.state = app_state
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)
        display_layout = QHBoxLayout()

        # Reported State
        reported_layout = QVBoxLayout()
        reported_layout.addWidget(QLabel("Reported State"))
        self.shadow_reported_text = QTextEdit()
        self.shadow_reported_text.setReadOnly(True)
        reported_layout.addWidget(self.shadow_reported_text)
        display_layout.addLayout(reported_layout)

        # Desired State
        desired_layout = QVBoxLayout()
        desired_layout.addWidget(QLabel("Desired State"))
        self.shadow_desired_text = QTextEdit()
        self.shadow_desired_text.setReadOnly(True)
        desired_layout.addWidget(self.shadow_desired_text)
        display_layout.addLayout(desired_layout)

        layout.addLayout(display_layout)

        layout.addWidget(QLabel("Update Reported State (JSON):"))
        self.shadow_update_input = QTextEdit()
        self.shadow_update_input.setText('{\n  "status": "running"\n}')
        layout.addWidget(self.shadow_update_input)

        update_button = QPushButton("Publish Shadow Update")
        update_button.clicked.connect(self.publish_shadow_update)
        layout.addWidget(update_button)

        self.state.shadow_updated.connect(self.update_display)
        self.update_display()

    def update_display(self):
        self.shadow_reported_text.setText(json.dumps(self.state.shadow["reported"], indent=2))
        self.shadow_desired_text.setText(json.dumps(self.state.shadow["desired"], indent=2))

    def publish_shadow_update(self):
        try:
            reported_update = json.loads(self.shadow_update_input.toPlainText())
            payload = json.dumps({"state": {"reported": reported_update}})
            topic = f"$aws/things/{self.mqtt.THING_NAME}/shadow/update"
            self.mqtt.publish(topic, payload)
        except json.JSONDecodeError:
            QMessageBox.critical(self, "Error", "Invalid JSON in shadow update.")


class JobsTab(QWidget):
    def __init__(self, app_state, mqtt_client):
        super().__init__()
        self.state = app_state
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)
        controls_layout = QHBoxLayout()
        create_job_button = QPushButton("Simulate New Job Creation")
        create_job_button.clicked.connect(self.create_new_job)
        controls_layout.addWidget(create_job_button)

        check_job_button = QPushButton("Check for Next Job")
        check_job_button.clicked.connect(self.check_for_next_job)
        controls_layout.addWidget(check_job_button)
        layout.addLayout(controls_layout)

        layout.addWidget(QLabel("Active Jobs:"))
        self.jobs_display = QTextEdit()
        self.jobs_display.setReadOnly(True)
        layout.addWidget(self.jobs_display)

        self.state.jobs_updated.connect(self.update_display)
        self.update_display()

    def update_display(self):
        if not self.state.jobs:
            self.jobs_display.setText("No active jobs.")
            return

        display_text = ""
        for job_id, job_data in self.state.jobs.items():
            display_text += f"Job ID: {job_id}\n"
            display_text += f"Status: {job_data['status']}\n"
            display_text += f"Document: {json.dumps(job_data['document'])}\n"
            display_text += "--------------------------------\n"
        self.jobs_display.setText(display_text)

    def create_new_job(self):
        job_id, job_data = self.state.create_new_job()
        self.mqtt.signals.log_message.emit(f"SIMULATOR: Created new job '{job_id}'.")
        topic = f"$aws/things/{self.mqtt.THING_NAME}/jobs/notify"
        self.mqtt.publish(topic, json.dumps({"jobs": self.state.jobs}))

    def check_for_next_job(self):
        job_id, job_data = self.state.start_next_job()
        if job_id:
            topic = f"$aws/things/{self.mqtt.THING_NAME}/jobs/start-next/accepted"
            payload = json.dumps({"execution": {**job_data, "jobId": job_id}})
            self.mqtt.publish(topic, payload)
            self.mqtt.signals.log_message.emit(f"SIMULATOR: Device started job '{job_id}'.")
        else:
            self.mqtt.signals.log_message.emit("SIMULATOR: No queued jobs found.")


class PubSubTab(QWidget):
    def __init__(self, mqtt_client):
        super().__init__()
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Publish"))
        self.pub_topic_input = QLineEdit("my/custom/topic")
        self.pub_payload_input = QTextEdit('{"data": "hello world"}')
        self.pub_payload_input.setFixedHeight(100)
        publish_button = QPushButton("Publish")
        publish_button.clicked.connect(self.publish_custom)
        layout.addWidget(self.pub_topic_input)
        layout.addWidget(self.pub_payload_input)
        layout.addWidget(publish_button)

        layout.addWidget(QLabel("Subscribe"))
        self.sub_topic_input = QLineEdit("device/+/data")
        subscribe_button = QPushButton("Subscribe")
        subscribe_button.clicked.connect(self.subscribe_custom)
        layout.addWidget(self.sub_topic_input)
        layout.addWidget(subscribe_button)

        layout.addStretch()

    def publish_custom(self):
        topic = self.pub_topic_input.text()
        payload = self.pub_payload_input.toPlainText()
        if topic:
            self.mqtt.publish(topic, payload)
        else:
            QMessageBox.warning(self, "Warning", "Publish topic cannot be empty.")

    def subscribe_custom(self):
        topic = self.sub_topic_input.text()
        if topic:
            self.mqtt.subscribe(topic)
        else:
            QMessageBox.warning(self, "Warning", "Subscribe topic cannot be empty.")


class DBLogViewerTab(QWidget):
    """A new widget to view and query the SQLite log database."""

    def __init__(self, database):
        super().__init__()
        self.db = database

        layout = QVBoxLayout(self)

        # Query input
        query_layout = QHBoxLayout()
        query_layout.addWidget(QLabel("SQL WHERE Clause:"))
        self.query_input = QLineEdit("1=1")
        query_layout.addWidget(self.query_input)
        query_button = QPushButton("Query")
        query_button.clicked.connect(self.run_query)
        query_layout.addWidget(query_button)
        layout.addLayout(query_layout)

        # Results table
        self.results_table = QTableWidget()
        self.results_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.results_table.setAlternatingRowColors(True)
        layout.addWidget(self.results_table)

        self.run_query()  # Initial load

    def run_query(self):
        where_clause = self.query_input.text()
        if not where_clause:
            where_clause = "1=1"  # Default to select all

        headers, data = self.db.query_logs(where_clause)

        if not data and not headers and where_clause != "1=1":
            # Handle query error
            QMessageBox.critical(self, "Query Error", "Failed to execute SQL query. Check syntax.")
            return

        self.results_table.setColumnCount(len(headers))
        self.results_table.setHorizontalHeaderLabels(headers)
        self.results_table.setRowCount(len(data))

        for row_index, row_data in enumerate(data):
            for col_index, col_data in enumerate(row_data):
                self.results_table.setItem(row_index, col_index, QTableWidgetItem(str(col_data)))

        self.results_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.results_table.resizeColumnsToContents()
