# FILE: ui/widgets.py

import json
import time
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
    QPushButton, QLineEdit, QMessageBox, QFrame
)
from PySide6.QtGui import QFont
from core.logger import log


class PacketViewerTab(QWidget):
    """A new widget to display the last N received packets."""

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Live View of Last 15 Received Packets"))

        self.packet_display = QTextEdit()
        self.packet_display.setReadOnly(True)
        self.packet_display.setFont(QFont("Courier", 10))
        self.packet_display.setPlaceholderText("Waiting for incoming messages...")

        layout.addWidget(self.packet_display)

    def update_packets(self, packets):
        """Updates the text display with the latest list of packets."""
        display_text = "\n".join(packets)
        self.packet_display.setText(display_text)
        # Auto-scroll to the bottom
        self.packet_display.verticalScrollBar().setValue(self.packet_display.verticalScrollBar().maximum())


class ShadowTab(QWidget):
    def __init__(self, app_state, mqtt_client, connection_signal):
        super().__init__()
        self.state = app_state
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)

        target_layout = QHBoxLayout()
        target_layout.addWidget(QLabel("Target Thing Name:"))
        self.target_thing_input = QLineEdit()
        self.target_thing_input.setPlaceholderText("Leave empty to target self")
        target_layout.addWidget(self.target_thing_input)

        self.get_shadow_button = QPushButton("Get Shadow")
        self.get_shadow_button.clicked.connect(self.request_get_shadow)
        target_layout.addWidget(self.get_shadow_button)
        layout.addLayout(target_layout)

        line = QFrame()
        line.setFrameShape(QFrame.HLine);
        line.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line)

        self.status_label = QLabel("Status: Disconnected. Connect to fetch shadow.")
        self.status_label.setStyleSheet("font-style: italic; color: grey;")
        layout.addWidget(self.status_label)

        display_layout = QHBoxLayout()
        reported_layout = QVBoxLayout()
        reported_layout.addWidget(QLabel("Reported State"))
        self.shadow_reported_text = QTextEdit();
        self.shadow_reported_text.setReadOnly(True)
        reported_layout.addWidget(self.shadow_reported_text)
        display_layout.addLayout(reported_layout)

        desired_layout = QVBoxLayout()
        desired_layout.addWidget(QLabel("Desired State"))
        self.shadow_desired_text = QTextEdit();
        self.shadow_desired_text.setReadOnly(True)
        desired_layout.addWidget(self.shadow_desired_text)
        display_layout.addLayout(desired_layout)
        layout.addLayout(display_layout)

        layout.addWidget(QLabel("Update Reported State (JSON):"))
        self.shadow_update_input = QTextEdit('{\n  "status": "running"\n}')
        layout.addWidget(self.shadow_update_input)

        self.update_button = QPushButton("Publish Shadow Update")
        self.update_button.clicked.connect(self.publish_shadow_update)
        layout.addWidget(self.update_button)

        connection_signal.connect(self.on_connection_changed)
        self.on_connection_changed(False)  # Set initial disabled state

    def on_connection_changed(self, connected):
        """Enable/disable buttons based on connection status."""
        self.update_button.setEnabled(connected)
        self.get_shadow_button.setEnabled(connected)
        if connected:
            self.status_label.setText("Status: Connected. Fetching shadow...")
            self.request_get_shadow()
        else:
            self.status_label.setText("Status: Disconnected. Connect to fetch shadow.")
            self.shadow_reported_text.clear()
            self.shadow_desired_text.clear()

    def get_target_thing(self):
        """Helper to get the target thing name."""
        target_thing = self.target_thing_input.text().strip()
        return target_thing if target_thing else self.mqtt.THING_NAME

    def request_get_shadow(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        target_thing = self.get_target_thing()
        topic = f"$aws/things/{target_thing}/shadow/get"
        log.info(f"Requesting shadow for {target_thing}",
                 extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': '{}'})
        self.mqtt.publish(topic, "{}")
        self.status_label.setText(f"Status: Fetching shadow for {target_thing}...")

    def publish_shadow_update(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        target_thing = self.get_target_thing()
        try:
            reported_update = json.loads(self.shadow_update_input.toPlainText())
            payload = json.dumps({"state": {"reported": reported_update}})
            topic = f"$aws/things/{target_thing}/shadow/update"
            log.info(f"Publishing to {topic}",
                     extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
            self.mqtt.publish(topic, payload)
        except json.JSONDecodeError:
            QMessageBox.critical(self, "Error", "Invalid JSON in shadow update.")

    def process_shadow_response(self, status, payload, thing_name):
        """Updates the UI based on a shadow response from the broker."""
        target_thing = self.get_target_thing()
        if thing_name != target_thing:
            return  # This response is for a different thing than we are currently viewing

        if status == 'accepted':
            try:
                data = json.loads(payload)
                state = data.get('state', {})
                self.shadow_reported_text.setText(json.dumps(state.get('reported', {}), indent=2))
                self.shadow_desired_text.setText(json.dumps(state.get('desired', {}), indent=2))
                self.status_label.setText(f"Status: Shadow for {thing_name} loaded successfully.")
            except json.JSONDecodeError:
                self.status_label.setText(f"Status: Error parsing shadow for {thing_name}.")
        elif status == 'rejected':
            try:
                data = json.loads(payload)
                if data.get('code') == 404:
                    self.status_label.setText(f"Status: No shadow exists for {thing_name}.")
                    self.shadow_reported_text.clear()
                    self.shadow_desired_text.clear()
                else:
                    self.status_label.setText(f"Status: Shadow request rejected for {thing_name}.")
            except json.JSONDecodeError:
                self.status_label.setText(f"Status: Shadow request rejected for {thing_name}.")


class JobsTab(QWidget):
    def __init__(self, app_state, mqtt_client, connection_signal):
        super().__init__()
        self.state = app_state
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)
        target_layout = QHBoxLayout()
        target_layout.addWidget(QLabel("Target Thing Name (for Job Creation):"))
        self.target_thing_input = QLineEdit()
        self.target_thing_input.setPlaceholderText("Enter a specific Thing Name")
        target_layout.addWidget(self.target_thing_input)
        layout.addLayout(target_layout)

        job_id_layout = QHBoxLayout()
        job_id_layout.addWidget(QLabel("Job ID (for Status Updates as self):"))
        self.job_id_input = QLineEdit()
        self.job_id_input.setPlaceholderText("Enter Job ID received in a 'notify' message")
        job_id_layout.addWidget(self.job_id_input)
        layout.addLayout(job_id_layout)

        line = QFrame();
        line.setFrameShape(QFrame.HLine);
        line.setFrameShadow(QFrame.Sunken)
        layout.addWidget(line)

        controls_layout = QHBoxLayout()
        self.create_job_button = QPushButton("Simulate New Job Creation (for Target)")
        self.create_job_button.clicked.connect(self.simulate_new_job)
        controls_layout.addWidget(self.create_job_button)

        self.check_job_button = QPushButton("Check for Next Job (as self)")
        self.check_job_button.clicked.connect(self.check_for_next_job)
        controls_layout.addWidget(self.check_job_button)
        layout.addLayout(controls_layout)

        update_layout = QHBoxLayout()
        update_layout.addWidget(QLabel("Update Job Status (as self):"))
        self.succeeded_button = QPushButton("Succeeded")
        self.failed_button = QPushButton("Failed")
        self.succeeded_button.clicked.connect(lambda: self.update_job_status("SUCCEEDED"))
        self.failed_button.clicked.connect(lambda: self.update_job_status("FAILED"))
        update_layout.addWidget(self.succeeded_button);
        update_layout.addWidget(self.failed_button)
        layout.addLayout(update_layout)

        layout.addStretch()
        connection_signal.connect(self.on_connection_changed)
        self.on_connection_changed(False)

    def on_connection_changed(self, connected):
        for button in [self.create_job_button, self.check_job_button, self.succeeded_button, self.failed_button]:
            button.setEnabled(connected)

    def simulate_new_job(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        target_thing = self.target_thing_input.text().strip()
        if not target_thing:
            QMessageBox.warning(self, "Warning", "Please enter a Target Thing Name to create a job for.")
            return

        job_id = f"job-{int(time.time())}"
        job_doc = {"operation": "FIRMWARE_UPDATE", "url": f"http://example.com/fw-for-{target_thing}.bin"}
        payload = json.dumps(
            {"jobs": {"QUEUED": [{"jobId": job_id, "jobDocument": job_doc, "queuedAt": int(time.time())}]}})
        topic = f"$aws/things/{target_thing}/jobs/notify"
        log.info(f"Simulating job creation for {target_thing}",
                 extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
        self.mqtt.publish(topic, payload)

    def check_for_next_job(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        topic = f"$aws/things/{self.mqtt.THING_NAME}/jobs/start-next"
        payload = "{}"
        log.info(f"Checking for next job for self",
                 extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
        self.mqtt.publish(topic, payload)

    def update_job_status(self, status):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        job_id = self.job_id_input.text().strip()
        if not job_id:
            QMessageBox.warning(self, "Warning", "Please enter a Job ID to update.")
            return

        topic = f"$aws/things/{self.mqtt.THING_NAME}/jobs/{job_id}/update"
        payload = json.dumps({"status": status})
        log.info(f"Updating job {job_id} to {status}",
                 extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
        self.mqtt.publish(topic, payload)


class PubSubTab(QWidget):
    def __init__(self, mqtt_client, connection_signal):
        super().__init__()
        self.mqtt = mqtt_client

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Publish"))
        self.pub_topic_input = QLineEdit("my/custom/topic")
        self.pub_payload_input = QTextEdit('{"data": "hello world"}')
        self.pub_payload_input.setFixedHeight(100)

        pub_controls_layout = QHBoxLayout()
        self.publish_button = QPushButton("Publish")
        self.publish_button.clicked.connect(self.publish_custom)
        self.retain_checkbox = QPushButton("Retain")
        self.retain_checkbox.setCheckable(True)
        pub_controls_layout.addWidget(self.publish_button)
        pub_controls_layout.addWidget(self.retain_checkbox)

        layout.addWidget(self.pub_topic_input)
        layout.addWidget(self.pub_payload_input)
        layout.addLayout(pub_controls_layout)

        layout.addWidget(QLabel("Subscribe"))
        self.sub_topic_input = QLineEdit("device/+/data")
        self.subscribe_button = QPushButton("Subscribe")
        self.subscribe_button.clicked.connect(self.subscribe_custom)
        layout.addWidget(self.sub_topic_input)
        layout.addWidget(self.subscribe_button)

        layout.addStretch()
        connection_signal.connect(self.on_connection_changed)
        self.on_connection_changed(False)

    def on_connection_changed(self, connected):
        self.publish_button.setEnabled(connected)
        self.subscribe_button.setEnabled(connected)

    def publish_custom(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        topic = self.pub_topic_input.text()
        payload = self.pub_payload_input.toPlainText()
        retain = self.retain_checkbox.isChecked()
        if topic:
            log.info(f"Publishing to {topic}",
                     extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
            self.mqtt.publish(topic, payload, retain=retain)
        else:
            QMessageBox.warning(self, "Warning", "Publish topic cannot be empty.")

    def subscribe_custom(self):
        if not self.mqtt.connected:
            QMessageBox.warning(self, "Disconnected", "Please connect to the broker first.")
            return
        topic = self.sub_topic_input.text()
        if topic:
            self.mqtt.subscribe(topic)
        else:
            QMessageBox.warning(self, "Warning", "Subscribe topic cannot be empty.")
