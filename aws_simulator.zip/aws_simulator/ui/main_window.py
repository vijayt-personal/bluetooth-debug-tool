# FILE: ui/main_window.py

import json
from datetime import datetime
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTabWidget, QPlainTextEdit, QFrame
)
from PySide6.QtGui import QFont

from mqtt.client import MqttClient, THING_NAME
from core.state import AppState
from core.database import Database
from ui.widgets import ShadowTab, JobsTab, PubSubTab, DBLogViewerTab


def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Return a default simulation config if file is missing or invalid
        return {
            "simulation_broker": {
                "endpoint": "broker.hivemq.com", "port": 1883, "use_tls": False
            },
            "auto_subscribe_topics": []
        }


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AWS IoT Core Simulator (Modular Python Edition)")
        self.setGeometry(100, 100, 1200, 800)

        self.config = load_config()
        self.app_state = AppState()
        self.db = Database()
        self.mqtt_client = MqttClient(self.config)

        self.db.setup_db()

        self.mqtt_client.signals.connection_status.connect(self.update_connection_status)
        self.mqtt_client.signals.message_received.connect(self.handle_incoming_message)
        self.mqtt_client.signals.log_message.connect(self.log_text_packet)

        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        self.setCentralWidget(main_widget)

        connection_box = QFrame()
        connection_box.setFrameShape(QFrame.StyledPanel)
        connection_layout = QHBoxLayout(connection_box)
        self.status_label = QLabel("Status: Disconnected")
        self.status_label.setStyleSheet("color: red; font-weight: bold;")
        self.thing_name_label = QLabel(f"Thing Name: {THING_NAME}")
        self.connect_button = QPushButton("Connect")
        self.connect_button.clicked.connect(self.toggle_connection)
        connection_layout.addWidget(self.status_label)
        connection_layout.addStretch()
        connection_layout.addWidget(self.thing_name_label)
        connection_layout.addStretch()
        connection_layout.addWidget(self.connect_button)
        main_layout.addWidget(connection_box)

        content_layout = QHBoxLayout()

        self.tabs = QTabWidget()
        self.tabs.addTab(ShadowTab(self.app_state, self.mqtt_client), "Device Shadow")
        self.tabs.addTab(JobsTab(self.app_state, self.mqtt_client), "IoT Jobs")
        self.tabs.addTab(PubSubTab(self.mqtt_client), "Custom Pub/Sub")
        self.tabs.addTab(DBLogViewerTab(self.db), "DB Log Viewer")  # New Tab
        content_layout.addWidget(self.tabs, 2)

        logger_layout = QVBoxLayout()
        logger_layout.addWidget(QLabel("Live Packet Log (also saved to mqtt_log.txt & log.db)"))
        self.logger = QPlainTextEdit()
        self.logger.setReadOnly(True)
        self.logger.setFont(QFont("Courier", 10))
        logger_layout.addWidget(self.logger)
        content_layout.addLayout(logger_layout, 1)

        main_layout.addLayout(content_layout)

    def update_connection_status(self, connected):
        if connected:
            self.status_label.setText("Status: Connected")
            self.status_label.setStyleSheet("color: green; font-weight: bold;")
            self.connect_button.setText("Disconnect")
            self.auto_subscribe()
        else:
            self.status_label.setText("Status: Disconnected")
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
            self.connect_button.setText("Connect")

    def toggle_connection(self):
        if not self.mqtt_client.connected:
            self.mqtt_client.connect_to_broker()
        else:
            self.mqtt_client.disconnect()

    def log_text_packet(self, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.logger.appendPlainText(log_entry)
        try:
            with open("mqtt_log.txt", "a") as f:
                f.write(log_entry + "\n")
        except IOError as e:
            self.logger.appendPlainText(f"Error writing to log file: {e}")

    def auto_subscribe(self):
        topics = self.config.get("auto_subscribe_topics", [])
        for topic in topics:
            self.mqtt_client.subscribe(topic)

    def handle_incoming_message(self, topic, payload):
        self.log_text_packet(f"RECEIVED on {topic}: {payload}")
        self.db.log_packet("RECEIVED", topic, payload)

        if topic == f"$aws/things/{THING_NAME}/shadow/update":
            try:
                data = json.loads(payload)
                if "state" in data and "reported" in data["state"]:
                    self.app_state.update_reported_shadow(data["state"]["reported"])
                    resp_topic = f"$aws/things/{THING_NAME}/shadow/update/accepted"
                    self.mqtt_client.publish(resp_topic, json.dumps({"state": self.app_state.shadow}))
            except json.JSONDecodeError:
                resp_topic = f"$aws/things/{THING_NAME}/shadow/update/rejected"
                self.mqtt_client.publish(resp_topic, '{"error": "Invalid JSON"}')

        if "/jobs/" in topic and "/update" in topic:
            try:
                job_id = topic.split('/')[4]
                data = json.loads(payload)
                if "status" in data:
                    self.app_state.update_job_status(job_id, data["status"])
                    resp_topic = f"$aws/things/{THING_NAME}/jobs/{job_id}/update/accepted"
                    self.mqtt_client.publish(resp_topic, "{}")
            except (IndexError, json.JSONDecodeError):
                pass

    def closeEvent(self, event):
        self.db.close()
        if self.mqtt_client.connected:
            self.mqtt_client.disconnect()
        event.accept()
