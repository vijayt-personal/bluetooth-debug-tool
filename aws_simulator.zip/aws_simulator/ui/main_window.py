# FILE: ui/main_window.py

import json
import collections
from datetime import datetime
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QTabWidget, QFrame
)
from PySide6.QtCore import Signal

from mqtt.client import MqttClient, THING_NAME
from core.state import AppState
from ui.widgets import ShadowTab, JobsTab, PubSubTab, PacketViewerTab
from core.logger import log


def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {
            "simulation_broker": {"endpoint": "broker.hivemq.com", "port": 1883, "use_tls": False},
            "auto_subscribe_topics": []
        }


class MainWindow(QMainWindow):
    connection_changed = Signal(bool)
    # New signal to update the packet viewer
    packets_updated = Signal(list)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("AWS IoT Core Simulator (Python Edition)")
        self.setGeometry(100, 100, 800, 600)

        self.config = load_config()
        self.app_state = AppState()
        self.mqtt_client = MqttClient(self.config)
        # Use a deque to efficiently store the last 15 packets
        self.recent_packets = collections.deque(maxlen=15)

        self.mqtt_client.signals.connection_status.connect(self.update_connection_status)
        self.mqtt_client.signals.message_received.connect(self.handle_incoming_message)
        self.mqtt_client.signals.shadow_response.connect(self.handle_shadow_response)

        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        self.setCentralWidget(main_widget)

        # ... Connection Panel is the same ...
        connection_box = QFrame()
        connection_box.setFrameShape(QFrame.StyledPanel)
        connection_layout = QHBoxLayout(connection_box)
        self.status_label = QLabel("Status: Disconnected")
        self.status_label.setStyleSheet("color: red; font-weight: bold;")
        self.thing_name_label = QLabel(f"Thing Name: {THING_NAME}")
        self.connect_button = QPushButton("Connect")
        self.connect_button.clicked.connect(self.toggle_connection)
        connection_layout.addWidget(self.status_label)
        connection_layout.addStretch()
        connection_layout.addWidget(self.thing_name_label)
        connection_layout.addStretch()
        connection_layout.addWidget(self.connect_button)
        main_layout.addWidget(connection_box)

        self.tabs = QTabWidget()
        self.tabs.addTab(ShadowTab(self.app_state, self.mqtt_client, self.connection_changed), "Device Shadow")
        self.tabs.addTab(JobsTab(self.app_state, self.mqtt_client, self.connection_changed), "IoT Jobs")
        self.tabs.addTab(PubSubTab(self.mqtt_client, self.connection_changed), "Custom Pub/Sub")

        # Add the new Packet Viewer tab
        self.packet_viewer_tab = PacketViewerTab()
        self.packets_updated.connect(self.packet_viewer_tab.update_packets)
        self.tabs.addTab(self.packet_viewer_tab, "Packet Viewer")

        main_layout.addWidget(self.tabs)

    def update_connection_status(self, connected, message):
        if connected:
            self.status_label.setText("Status: Connected")
            self.status_label.setStyleSheet("color: green; font-weight: bold;")
            self.connect_button.setText("Disconnect")
            self.auto_subscribe()
        else:
            self.status_label.setText("Status: Disconnected")
            self.status_label.setStyleSheet("color: red; font-weight: bold;")
            self.connect_button.setText("Connect")
            self.recent_packets.clear()  # Clear packets on disconnect
            self.packets_updated.emit([])

        log.info(message)
        self.connection_changed.emit(connected)

    def toggle_connection(self):
        if not self.mqtt_client.connected:
            self.mqtt_client.connect_to_broker()
        else:
            self.mqtt_client.disconnect()

    def auto_subscribe(self):
        topics = self.config.get("auto_subscribe_topics", [])
        for topic in topics:
            self.mqtt_client.subscribe(topic)

    def handle_incoming_message(self, topic, payload):
        log.info(f"Received from {topic}",
                 extra={'packet': True, 'direction': 'RECEIVED', 'topic': topic, 'payload': payload})

        # Add to our recent packets list and update the UI
        timestamp = datetime.now().strftime("%H:%M:%S")
        packet_str = f"[{timestamp}] RECV on {topic}:\n{payload}"
        self.recent_packets.append(packet_str)
        self.packets_updated.emit(list(self.recent_packets))

    def handle_shadow_response(self, status, payload, thing_name):
        topic = f"$aws/things/{thing_name}/shadow/.../{status}"
        log.info(f"Shadow response for {thing_name}",
                 extra={'packet': True, 'direction': 'RECEIVED', 'topic': topic, 'payload': payload})

        timestamp = datetime.now().strftime("%H:%M:%S")
        packet_str = f"[{timestamp}] RECV Shadow Response on {topic}:\n{payload}"
        self.recent_packets.append(packet_str)
        self.packets_updated.emit(list(self.recent_packets))

        shadow_widget = self.tabs.widget(0)
        if isinstance(shadow_widget, ShadowTab):
            shadow_widget.process_shadow_response(status, payload, thing_name)

    def closeEvent(self, event):
        if self.mqtt_client.connected:
            self.mqtt_client.disconnect()
        event.accept()
