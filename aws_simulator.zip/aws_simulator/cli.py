# FILE: cli.py

import asyncio
import json
import shlex
from functools import partial

from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.application import run_in_terminal

from core.state import AppState
from mqtt.client import MqttClient, THING_NAME
from core.database import Database


def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print("Warning: config.json not found or invalid. Using default simulation settings.")
        return {
            "simulation_broker": {"endpoint": "broker.hivemq.com", "port": 1883, "use_tls": False},
            "auto_subscribe_topics": []
        }


class InteractiveShell:
    """Manages the interactive command-line session."""

    def __init__(self):
        self.console = Console()
        self.config = load_config()
        self.app_state = AppState()
        self.db = Database()
        self.mqtt_client = MqttClient(self.config)

        self.command_completer = WordCompleter([
            'connect', 'disconnect', 'publish', 'subscribe', 'shadow',
            'job_create', 'job_next', 'state', 'help', 'exit'
        ], ignore_case=True)

        self.db.setup_db()
        self.connect_signals()

    def connect_signals(self):
        """Connect signals from backend threads to thread-safe print functions."""
        print_func = partial(run_in_terminal, self.console.print)
        self.mqtt_client.signals.message_received.connect(
            partial(self.on_message_received, print_func=print_func)
        )
        self.mqtt_client.signals.log_message.connect(
            partial(self.on_log_message, print_func=print_func)
        )
        self.mqtt_client.signals.connection_status.connect(
            partial(self.on_connection_status_change, print_func=print_func)
        )

    # --- Signal Handlers (run in main thread via run_in_terminal) ---

    def on_log_message(self, message, print_func):
        print_func(f"\n[dim]LOG: {message}[/dim]")

    def on_message_received(self, topic, payload, print_func):
        print_func(f"\n[bold green]<-- RECEIVED on [cyan]{topic}[/cyan][/bold green]")
        try:
            # Try to pretty-print if it's JSON
            parsed_json = json.loads(payload)
            syntax = Syntax(json.dumps(parsed_json, indent=2), "json", theme="monokai", line_numbers=False)
            print_func(syntax)
        except json.JSONDecodeError:
            print_func(payload)

        self.db.log_packet("RECEIVED", topic, payload)
        self.handle_backend_message(topic, payload)

    def on_connection_status_change(self, connected, print_func):
        if connected:
            print_func("\n[bold green]*** Successfully Connected to Broker ***[/bold green]")
            topics = self.config.get("auto_subscribe_topics", [])
            for topic in topics:
                self.mqtt_client.subscribe(topic)
        else:
            print_func("\n[bold red]*** Disconnected from Broker ***[/bold red]")

    def handle_backend_message(self, topic, payload):
        """Silently processes messages to update state, just like the UI app."""
        if topic == f"$aws/things/{THING_NAME}/shadow/update":
            try:
                data = json.loads(payload)
                if "state" in data and "reported" in data["state"]:
                    self.app_state.update_reported_shadow(data["state"]["reported"])
                    resp_topic = f"$aws/things/{THING_NAME}/shadow/update/accepted"
                    self.mqtt_client.publish(resp_topic, json.dumps({"state": self.app_state.shadow}))
            except json.JSONDecodeError:
                pass

        if "/jobs/" in topic and "/update" in topic:
            try:
                job_id = topic.split('/')[4]
                data = json.loads(payload)
                if "status" in data:
                    self.app_state.update_job_status(job_id, data["status"])
                    resp_topic = f"$aws/things/{THING_NAME}/jobs/{job_id}/update/accepted"
                    self.mqtt_client.publish(resp_topic, "{}")
            except (IndexError, json.JSONDecodeError):
                pass

    # --- Command Handlers (called from the main run loop) ---

    def handle_help(self, args):
        table = Table(title="Available Commands")
        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Arguments", style="magenta")
        table.add_column("Description")

        table.add_row("connect", "", "Connect to the MQTT broker.")
        table.add_row("disconnect", "", "Disconnect from the MQTT broker.")
        table.add_row("publish", "<topic> <payload>", "Publish a message. Use quotes for multi-word payloads.")
        table.add_row("subscribe", "<topic>", "Subscribe to a topic.")
        table.add_row("shadow", "'<json_string>'", "Update reported shadow state. Must use single quotes.")
        table.add_row("job_create", "", "Simulate creating a new job.")
        table.add_row("job_next", "", "Simulate the device requesting the next job.")
        table.add_row("state", "", "View the current shadow and job state.")
        table.add_row("help", "", "Show this help message.")
        table.add_row("exit", "", "Exit the application.")
        self.console.print(table)

    def handle_connect(self, args):
        self.mqtt_client.connect_to_broker()

    def handle_disconnect(self, args):
        self.mqtt_client.disconnect()

    def handle_publish(self, args):
        if len(args) < 2:
            self.console.print("[red]Usage: publish <topic> <payload>[/red]")
            return
        topic, payload = args[0], " ".join(args[1:])
        self.mqtt_client.publish(topic, payload)
        self.db.log_packet("PUBLISHED", topic, payload)

    def handle_subscribe(self, args):
        if not args:
            self.console.print("[red]Usage: subscribe <topic>[/red]")
            return
        self.mqtt_client.subscribe(args[0])

    def handle_shadow(self, args):
        if not args:
            self.console.print("[red]Usage: shadow '<json_string>'[/red]")
            return
        try:
            reported = json.loads(args[0])
            payload = json.dumps({"state": {"reported": reported}})
            topic = f"$aws/things/{THING_NAME}/shadow/update"
            self.mqtt_client.publish(topic, payload)
            self.db.log_packet("PUBLISHED", topic, payload)
        except json.JSONDecodeError:
            self.console.print("[red]Error: Invalid JSON provided for shadow update.[/red]")

    def handle_job_create(self, args):
        job_id, _ = self.app_state.create_new_job()
        self.console.print(f"Created new job: [yellow]{job_id}[/yellow]")

    def handle_job_next(self, args):
        job_id, _ = self.app_state.start_next_job()
        if job_id:
            self.console.print(f"Started job: [yellow]{job_id}[/yellow]")
        else:
            self.console.print("[yellow]No queued jobs found.[/yellow]")

    def handle_state(self, args):
        self.console.print("[bold cyan]--- Current Shadow State ---[/bold cyan]")
        syntax = Syntax(json.dumps(self.app_state.shadow, indent=2), "json", theme="monokai", line_numbers=False)
        self.console.print(syntax)
        self.console.print("\n[bold cyan]--- Current Jobs ---[/bold cyan]")
        syntax = Syntax(json.dumps(self.app_state.jobs, indent=2), "json", theme="monokai", line_numbers=False)
        self.console.print(syntax)

    # --- Main Application Loop ---

    async def run(self):
        session = PromptSession(
            history=FileHistory('.cli_history'),
            auto_suggest=AutoSuggestFromHistory()
        )
        self.console.print("[bold cyan]AWS IoT Simulator CLI[/bold cyan]")
        self.console.print("Type 'help' for a list of commands. Use Tab for auto-completion.")

        while True:
            try:
                if self.mqtt_client.connected:
                    prompt_text = FormattedText([('bold green', 'Connected'), ('', '> ')])
                else:
                    prompt_text = FormattedText([('bold red', 'Disconnected'), ('', '> ')])

                user_input = await session.prompt_async(prompt_text, completer=self.command_completer)

                try:
                    parts = shlex.split(user_input)
                except ValueError:
                    self.console.print("[red]Parsing Error: Check for unclosed quotes.[/red]")
                    continue

                if not parts: continue

                command = parts[0].lower()
                args = parts[1:]

                if command == 'exit':
                    break

                handler = getattr(self, f"handle_{command}", None)
                if handler:
                    handler(args)
                else:
                    self.console.print(f"[red]Unknown command: {command}[/red]")

            except (KeyboardInterrupt, EOFError):
                break

        # Cleanup
        self.console.print("\nExiting...")
        if self.mqtt_client.connected:
            self.mqtt_client.disconnect()
        self.db.close()


async def main():
    shell = InteractiveShell()
    await shell.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"Application terminated with an error: {e}")
