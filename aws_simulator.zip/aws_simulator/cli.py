# FILE: cli.py

import asyncio
import json
import shlex
from functools import partial
import logging

from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.application import run_in_terminal

from core.state import AppState
from mqtt.client import MqttClient
from core.logger import log


def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print("Warning: config.json not found or invalid. Using default simulation settings.")
        return {
            "simulation_broker": {"endpoint": "broker.hivemq.com", "port": 1883, "use_tls": False},
            "auto_subscribe_topics": []
        }


class InteractiveShell:
    def __init__(self):
        self.console = Console()
        self.config = load_config()
        self.app_state = AppState()
        self.mqtt_client = MqttClient(self.config)
        self.log_filter_manager = log.filter_manager

        self.command_completer = WordCompleter([
            'connect', 'disconnect', 'publish', 'subscribe', 'shadow',
            'loglevel', 'log_filter', 'help', 'exit'
        ], ignore_case=True)

        self.connect_signals()

    def connect_signals(self):
        print_func = partial(run_in_terminal, self.console.print)
        self.mqtt_client.signals.message_received.connect(
            partial(self.on_message_received, print_func=print_func)
        )
        self.mqtt_client.signals.connection_status.connect(
            partial(self.on_connection_status_change, print_func=print_func)
        )

    def on_message_received(self, topic, payload, print_func):
        # The logger will automatically filter this based on its rules
        log.info(f"Received from {topic}",
                 extra={'packet': True, 'direction': 'RECEIVED', 'topic': topic, 'payload': payload})

        print_func(f"\n[bold green]<-- RECEIVED on [cyan]{topic}[/cyan][/bold green]")
        try:
            parsed_json = json.loads(payload)
            syntax = Syntax(json.dumps(parsed_json, indent=2), "json", theme="monokai", line_numbers=False)
            print_func(syntax)
        except json.JSONDecodeError:
            print_func(payload)

    def on_connection_status_change(self, connected, message, print_func):
        if connected:
            print_func(f"\n[bold green]*** {message} ***[/bold green]")
            topics = self.config.get("auto_subscribe_topics", [])
            for topic in topics:
                self.mqtt_client.subscribe(topic)
        else:
            print_func(f"\n[bold red]*** {message} ***[/bold red]")

    def handle_help(self, args):
        table = Table(title="Available Commands")
        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Arguments", style="magenta")
        table.add_column("Description")

        table.add_row("connect | disconnect", "", "Connect to or disconnect from the MQTT broker.")
        table.add_row("publish", "<topic> <payload> [--retain]", "Publish a message. Supports --retain flag.")
        table.add_row("subscribe", "<topic>", "Subscribe to a topic.")
        table.add_row("shadow", "<thing_name> '<json>'", "Update a target device's shadow.")
        table.add_row("loglevel", "<debug|info|warning>", "Set the application log level.")
        table.add_row("log_filter", "<add|list|clear> [topic|payload] [pattern]", "Manage packet log filters.")
        table.add_row("help", "", "Show this help message.")
        table.add_row("exit", "", "Exit the application.")
        self.console.print(table)

    def handle_publish(self, args):
        if len(args) < 2:
            self.console.print("[red]Usage: publish <topic> <payload> [--retain][/red]")
            return

        retain = '--retain' in args
        if retain: args.remove('--retain')

        topic, payload = args[0], " ".join(args[1:])
        # Log before publishing to apply filters
        log.info(f"Publishing to {topic}",
                 extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
        self.mqtt_client.publish(topic, payload, retain=retain)
        self.console.print(f"Published to [cyan]{topic}[/cyan]")

    def handle_shadow(self, args):
        if len(args) < 2:
            self.console.print("[red]Usage: shadow <thing_name> '<json_string>'[/red]")
            return

        target_thing, json_str = args[0], args[1]
        try:
            reported = json.loads(json_str)
            payload = json.dumps({"state": {"reported": reported}})
            topic = f"$aws/things/{target_thing}/shadow/update"
            # Log before publishing
            log.info(f"Publishing to {topic}",
                     extra={'packet': True, 'direction': 'PUBLISHED', 'topic': topic, 'payload': payload})
            self.mqtt_client.publish(topic, payload)
            self.console.print(f"Shadow update published for [yellow]{target_thing}[/yellow]")
        except json.JSONDecodeError:
            self.console.print("[red]Error: Invalid JSON provided for shadow update.[/red]")

    def handle_log_filter(self, args):
        if not args:
            self.console.print("[red]Usage: log_filter <add|list|clear> [topic|payload] [pattern][/red]")
            return

        sub_command = args[0].lower()
        if sub_command == 'list':
            self.console.print("[bold]Active Packet Log Filters:[/bold]")
            self.console.print(f"  [cyan]Topic Filters:[/cyan] {self.log_filter_manager.topic_filters or 'None'}")
            self.console.print(f"  [cyan]Payload Filters:[/cyan] {self.log_filter_manager.payload_filters or 'None'}")
        elif sub_command == 'clear':
            self.log_filter_manager.clear_filters()
            self.console.print("[green]All packet log filters cleared.[/green]")
        elif sub_command == 'add' and len(args) > 2:
            filter_type, pattern = args[1].lower(), args[2]
            if filter_type == 'topic':
                self.log_filter_manager.add_topic_filter(pattern)
                self.console.print(f"Added topic filter: [yellow]{pattern}[/yellow]")
            elif filter_type == 'payload':
                self.log_filter_manager.add_payload_filter(pattern)
                self.console.print(f"Added payload filter: [yellow]{pattern}[/yellow]")
            else:
                self.console.print(f"[red]Invalid filter type: '{filter_type}'. Use 'topic' or 'payload'.[/red]")
        else:
            self.console.print("[red]Invalid 'log_filter' command.[/red]")

    # ... (Other handlers like connect, disconnect, subscribe, loglevel remain the same) ...
    def handle_connect(self, args):
        if self.mqtt_client.connected:
            self.console.print("[yellow]Already connected.[/yellow]")
            return
        self.console.print("[dim]Connecting...[/dim]")
        self.mqtt_client.connect_to_broker()

    def handle_disconnect(self, args):
        if not self.mqtt_client.connected:
            self.console.print("[yellow]Not connected.[/yellow]")
            return
        self.mqtt_client.disconnect()

    def handle_subscribe(self, args):
        if not args:
            self.console.print("[red]Usage: subscribe <topic>[/red]")
            return
        self.mqtt_client.subscribe(args[0])
        self.console.print(f"Subscribed to [cyan]{args[0]}[/cyan]")

    def handle_loglevel(self, args):
        if not args or args[0].lower() not in ['debug', 'info', 'warning', 'error']:
            self.console.print("[red]Usage: loglevel <debug|info|warning|error>[/red]")
            return
        level_str = args[0].upper()
        log.setLevel(getattr(logging, level_str))
        self.console.print(f"Application log level set to [bold yellow]{level_str}[/bold yellow].")

    async def run(self):
        session = PromptSession(history=FileHistory('.cli_history'), auto_suggest=AutoSuggestFromHistory())
        self.console.print("[bold cyan]AWS IoT Simulator CLI[/bold cyan]")
        self.console.print("Type 'help' for a list of commands. Use Tab for auto-completion.")

        while True:
            try:
                if self.mqtt_client.connected:
                    prompt_text = FormattedText([('bold green', 'Connected'), ('', '> ')])
                else:
                    prompt_text = FormattedText([('bold red', 'Disconnected'), ('', '> ')])

                user_input = await session.prompt_async(prompt_text, completer=self.command_completer)

                try:
                    parts = shlex.split(user_input)
                except ValueError:
                    self.console.print("[red]Parsing Error: Check for unclosed quotes.[/red]")
                    continue

                if not parts: continue
                command, args = parts[0].lower(), parts[1:]

                if command == 'exit': break

                handler = getattr(self, f"handle_{command}", None)
                if handler:
                    handler(args)
                else:
                    self.console.print(f"[red]Unknown command: {command}[/red]")

            except (KeyboardInterrupt, EOFError):
                break

        self.console.print("\nExiting...")
        self.mqtt_client.disconnect()


async def main():
    shell = InteractiveShell()
    await shell.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"Application terminated with an error: {e}")
