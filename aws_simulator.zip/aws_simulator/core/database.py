# FILE: core/database.py

import sqlite3
from datetime import datetime


class Database:
    """Handles all SQLite database operations."""

    def __init__(self, db_file="log.db"):
        self.db_file = db_file
        self.conn = None

    def connect(self):
        """Create a database connection."""
        try:
            self.conn = sqlite3.connect(self.db_file, check_same_thread=False)
        except sqlite3.Error as e:
            print(f"Database connection error: {e}")

    def setup_db(self):
        """Create the logs table if it doesn't exist."""
        if not self.conn:
            self.connect()

        create_table_sql = """
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            direction TEXT NOT NULL,
            topic TEXT,
            payload TEXT
        );
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(create_table_sql)
            self.conn.commit()
        except sqlite3.Error as e:
            print(f"Database setup error: {e}")

    def log_packet(self, direction, topic, payload):
        """Insert a new log entry into the database."""
        if not self.conn:
            return

        sql = '''INSERT INTO logs(timestamp, direction, topic, payload)
                 VALUES(?,?,?,?)'''
        try:
            cursor = self.conn.cursor()
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
            cursor.execute(sql, (timestamp, direction, topic, payload))
            self.conn.commit()
        except sqlite3.Error as e:
            print(f"Database logging error: {e}")

    def query_logs(self, where_clause="1=1", limit=100):
        """Query the logs table with a custom WHERE clause."""
        if not self.conn:
            return [], []

        query = f"SELECT timestamp, direction, topic, payload FROM logs WHERE {where_clause} ORDER BY timestamp DESC LIMIT {limit}"
        try:
            cursor = self.conn.cursor()
            cursor.execute(query)

            headers = [description[0] for description in cursor.description]
            rows = cursor.fetchall()
            return headers, rows
        except sqlite3.Error as e:
            print(f"Database query error: {e}")
            return [], []

    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
