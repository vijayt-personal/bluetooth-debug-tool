# FILE: core/logger.py

import logging
import os
import fnmatch
from logging.handlers import RotatingFileHandler

# Ensure logs directory exists
if not os.path.exists('logs'):
    os.makedirs('logs')


class LogFilterManager:
    """Manages the filters for the packet logger."""

    def __init__(self):
        self.topic_filters = []
        self.payload_filters = []

    def add_topic_filter(self, pattern):
        self.topic_filters.append(pattern)

    def add_payload_filter(self, text):
        self.payload_filters.append(text)

    def clear_filters(self):
        self.topic_filters = []
        self.payload_filters = []

    def should_log(self, topic, payload):
        """Check if a packet should be logged based on active filters."""
        if not self.topic_filters and not self.payload_filters:
            return True  # No filters, log everything

        log_it = False
        # If there are topic filters, at least one must match
        if self.topic_filters:
            if any(fnmatch.fnmatch(topic, pattern) for pattern in self.topic_filters):
                log_it = True
        else:
            # No topic filters, so we pass this check
            log_it = True

        # If we passed the topic check and there are payload filters, at least one must match
        if log_it and self.payload_filters:
            if not any(text in payload for text in self.payload_filters):
                log_it = False

        return log_it


class PacketLogFilter(logging.Filter):
    """This filter only allows log records that pass the LogFilterManager checks."""

    def __init__(self, filter_manager):
        super().__init__()
        self.manager = filter_manager

    def filter(self, record):
        if not hasattr(record, 'packet'):
            return False  # Not a packet log record

        return self.manager.should_log(record.topic, record.payload)


def setup_logger():
    """Sets up the root logger and handlers for app and packet logs."""
    filter_manager = LogFilterManager()

    # General application logger
    app_handler = RotatingFileHandler('logs/app.log', maxBytes=1024 * 1024, backupCount=5)
    app_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    app_handler.setFormatter(app_formatter)

    # Packet logger
    packet_handler = RotatingFileHandler('logs/packets.log', maxBytes=1024 * 1024, backupCount=5)
    packet_formatter = logging.Formatter('%(asctime)s - %(direction)s - %(topic)s - %(payload)s')
    packet_handler.setFormatter(packet_formatter)
    packet_handler.addFilter(PacketLogFilter(filter_manager))

    logger = logging.getLogger('aws_iot_sim')
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        logger.addHandler(app_handler)
        logger.addHandler(packet_handler)

    # Attach the manager to the logger so it can be accessed globally
    logger.filter_manager = filter_manager
    return logger


# Singleton logger instance
log = setup_logger()
