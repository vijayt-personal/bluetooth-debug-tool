# FILE: core/state.py

import json
import time
from PySide6.QtCore import QObject, Signal

class AppState(QObject):
    """
    Manages the application's shared state (shadow, jobs).
    Emits signals when state changes so the UI can update.
    """
    shadow_updated = Signal()
    jobs_updated = Signal()

    def __init__(self):
        super().__init__()
        self.shadow = {
            "reported": {"status": "init"},
            "desired": {"app_version": "1.1", "mode": "auto"}
        }
        self.jobs = {} # job_id: {status, document}

    def update_reported_shadow(self, reported_update):
        self.shadow["reported"].update(reported_update)
        self.shadow_updated.emit()

    def create_new_job(self):
        job_id = f"job-{int(time.time())}"
        self.jobs[job_id] = {
            "status": "QUEUED",
            "document": {
                "operation": "FIRMWARE_UPDATE",
                "url": f"http://example.com/fw-v{round(time.time() % 10, 1)}.bin"
            }
        }
        self.jobs_updated.emit()
        return job_id, self.jobs[job_id]

    def start_next_job(self):
        for job_id, job_data in self.jobs.items():
            if job_data["status"] == "QUEUED":
                self.jobs[job_id]["status"] = "IN_PROGRESS"
                self.jobs_updated.emit()
                return job_id, self.jobs[job_id]
        return None, None

    def update_job_status(self, job_id, status):
        if job_id in self.jobs:
            self.jobs[job_id]["status"] = status
            self.jobs_updated.emit()
