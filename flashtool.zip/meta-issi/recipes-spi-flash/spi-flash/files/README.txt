NXP i.MX8 Low-Level SPI Flash Tool (SPIDEV Version)
===================================================

This document provides instructions for the spi-flash CLI. This tool bypasses
the Linux MTD subsystem to interact directly with the SPI flash memory controller
using the 'spidev' kernel interface.

1. DANGER: EXPERT USE ONLY
--------------------------
Operating at this low level is extremely dangerous. You are bypassing all kernel
safety mechanisms. Sending the wrong command or writing to the wrong address can
permanently "brick" your device.

YOU MUST have the datasheet for your specific SPI NOR flash chip before use.

** SECTOR VALIDATION **
This tool uses a fixed logical sector size of 128KB. It DOES NOT and CAN NOT
automatically detect the total flash size. YOU, the user, are responsible for
knowing the valid sector range for your chip (e.g., 0-63 for a 64Mb chip,
0-511 for a 512Mb chip). Entering a sector outside your chip's physical range
will cause an error.

2. SYSTEM CONFIGURATION
-----------------------
1. Kernel 'spidev' Support: Your Linux kernel must have spidev enabled.
2. Device Tree Modification: You MUST modify your board's device tree to
   disable the MTD driver for your flash chip and enable a 'spidev' node
   in its place.

3. CONFIGURABLE WARNING ADDRESS
-------------------------------
By default, the tool will abort if you try to access memory below 2MB (0x200000).
You can change this limit using the --warn-addr global option.

Example: Allow operations starting from 1MB
  spi-flash --warn-addr 0x100000 flash erase O 8 8

4. COMMAND REFERENCE
--------------------
  flash read <type> <sector> <size>
    - Reads data from a specified location with formatted output.
    - Example Output:
        sector=0x200000 size=32
        Data read followed by sector 0x200000
        offset 0x00200000 : 00 01 02 03 04 05 06 07
        offset 0x00200008 : 08 09 0A 0B 0C 0D 0E 0F

  (Other commands: write, erase, write-verify, clr, help)