/*
 * spi_flash.c
 *
 * A low-level, non-interactive command-line utility for an NXP i.MX8 board.
 * This version uses the spidev interface to send raw SPI commands.
 *
 * Author: Gemini
 * Date: August 12, 2025
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <stdint.h>
#include <linux/spi/spidev.h>

// --- Configuration ---
#define SPIDEV_DEVICE_DEFAULT "/dev/spidev0.0"
#define BOOTLOADER_WARN_ADDR_DEFAULT 0x200000
#define BASE_SECTOR_SIZE (128 * 1024)
#define PAGE_SIZE 256

// --- SPI Flash Command Opcodes (Example values, CHECK YOUR DATASHEET!) ---
#define CMD_WRITE_ENABLE    0x06
#define CMD_PAGE_PROGRAM    0x02
#define CMD_READ_DATA       0x03
#define CMD_ERASE_4K        0x20
#define CMD_ERASE_32K       0x52
#define CMD_ERASE_128K      0xD8
#define CMD_CHIP_ERASE      0xC7
#define CMD_READ_STATUS_REG 0x05
#define STATUS_REG_BUSY     0x01

// Global variable for configurable warning address
unsigned long g_warn_addr = BOOTLOADER_WARN_ADDR_DEFAULT;

// Prototypes
void print_help(const char *app_name);
int spi_transfer(int fd, uint8_t *tx_buf, uint8_t *rx_buf, int len);
int flash_wait_busy(int fd);
int flash_write_enable(int fd);
int generate_pattern_data(const char* pattern, unsigned char* buffer, long size);
void handle_flash_write(int argc, char *argv[]);
void handle_flash_read(int argc, char *argv[]);
void handle_flash_erase(int argc, char *argv[]);
void handle_flash_write_verify(int argc, char *argv[]);

int main(int argc, char *argv[]) {
    char *exec_name = argv[0];
    int arg_offset = 1;
    if (argc > 2 && strcmp(argv[1], "--warn-addr") == 0) {
        g_warn_addr = strtoul(argv[2], NULL, 16);
        printf(">> Custom Warning Address set to 0x%lX\n", g_warn_addr);
        arg_offset = 3;
    }

    argc -= arg_offset;
    argv += arg_offset;

    if (argc < 1) { print_help(exec_name); return 1; }
    
    if (strcmp(argv[0], "flash") == 0) {
        if (argc < 2) { fprintf(stderr, "Error: Missing flash subcommand.\n"); print_help(exec_name); return 1; }
        char *sub_cmd = argv[1];
        if (strcmp(sub_cmd, "write") == 0) handle_flash_write(argc-1, argv+1);
        else if (strcmp(sub_cmd, "read") == 0) handle_flash_read(argc-1, argv+1);
        else if (strcmp(sub_cmd, "erase") == 0) handle_flash_erase(argc-1, argv+1);
        else if (strcmp(sub_cmd, "write-verify") == 0) handle_flash_write_verify(argc-1, argv+1);
        else { fprintf(stderr, "Error: Unknown flash command '%s'.\n", sub_cmd); print_help(exec_name); return 1; }
    } else if (strcmp(argv[0], "clr") == 0) { printf("\033[H\033[J");
    } else if (strcmp(argv[0], "help") == 0) { print_help(exec_name);
    } else { fprintf(stderr, "Error: Unknown command '%s'.\n", argv[0]); print_help(exec_name); return 1; }
    return 0;
}

void print_help(const char *app_name) {
    printf("Low-Level SPI Flash Tool (SPIDEV Version)\n\n");
    printf("Usage: %s [--warn-addr <hex>] <command> [options]\n\n", app_name);
    printf("Commands:\n");
    printf("  flash write <type> <pattern> <sector> <size>      - Write data to a sector.\n");
    printf("  flash read <type> <sector> <size>                 - Read data from a sector.\n");
    printf("  flash erase <type> <start> <end>                  - Erase sectors/blocks.\n");
    printf("      <type>: Z(4k), Y(32k), O(128k), C(Chip Erase)\n");
    printf("  flash write-verify <t> <sec> <iter> <fail> <log> <full> - Stress test.\n");
    printf("  clr                                               - Clear terminal screen.\n");
    printf("  help                                              - Show this help message.\n\n");
    printf("WARNING: This tool requires custom Device Tree config and bypasses kernel safeguards.\n");
}

int spi_transfer(int fd, uint8_t *tx_buf, uint8_t *rx_buf, int len) {
    struct spi_ioc_transfer tr = {
        .tx_buf = (unsigned long)tx_buf, .rx_buf = (unsigned long)rx_buf,
        .len = len, .speed_hz = 20000000, .bits_per_word = 8,
    };
    if (ioctl(fd, SPI_IOC_MESSAGE(1), &tr) < 1) { perror("ioctl(SPI_IOC_MESSAGE)"); return -1; }
    return 0;
}

int flash_wait_busy(int fd) {
    uint8_t tx_buf[2] = {CMD_READ_STATUS_REG, 0xFF};
    uint8_t rx_buf[2];
    for(int retries = 0; retries < 1000; retries++) {
        if (spi_transfer(fd, tx_buf, rx_buf, 2) != 0) return -1;
        if (!(rx_buf[1] & STATUS_REG_BUSY)) return 0;
        usleep(1000);
    }
    fprintf(stderr, "Error: Timed out waiting for flash ready.\n");
    return -1;
}

int flash_write_enable(int fd) {
    uint8_t cmd = CMD_WRITE_ENABLE;
    return spi_transfer(fd, &cmd, NULL, 1);
}

int generate_pattern_data(const char* pattern, unsigned char* buffer, long size) {
    if (strcmp(pattern, "+") == 0) { for (long i = 0; i < size; i++) buffer[i] = (unsigned char)(i & 0xFF);
    } else if (strcmp(pattern, "-") == 0) { for (long i = 0; i < size; i++) buffer[i] = (unsigned char)((0xFF - i) & 0xFF);
    } else {
        long val = strtol(pattern, NULL, 16);
        if (val < 0 || val > 255) { fprintf(stderr, "Error: Invalid hex pattern.\n"); return -1; }
        memset(buffer, (unsigned char)val, size);
    }
    return 0;
}

void handle_flash_write(int argc, char *argv[]) {
    if (argc != 5) { fprintf(stderr, "Usage: flash write <type> <pattern> <sector> <size>\n"); exit(1); }
    char *pattern = argv[1]; 
    long sector = strtol(argv[2], NULL, 0); 
    long size = strtol(argv[3], NULL, 0);
    uint32_t addr = sector * BASE_SECTOR_SIZE;

    if (addr < g_warn_addr) { fprintf(stderr, "!! DANGER: Address 0x%X is below warning address 0x%lX. Aborting.\n", addr, g_warn_addr); exit(1); }
    if (sector < 0) { fprintf(stderr, "Error: Sector cannot be negative.\n"); exit(1); }
    if (size <= 0 || size > PAGE_SIZE) { fprintf(stderr, "Error: Size must be 1-%d.\n", PAGE_SIZE); exit(1); }

    uint8_t *tx_buf = malloc(4 + size); 
    if(!tx_buf) {perror("malloc"); exit(1);}

    tx_buf[0] = CMD_PAGE_PROGRAM; 
    tx_buf[1] = (addr >> 16) & 0xFF; 
    tx_buf[2] = (addr >> 8) & 0xFF; 
    tx_buf[3] = addr & 0xFF;
    
    if (generate_pattern_data(pattern, &tx_buf[4], size) != 0) { free(tx_buf); exit(1); }
    
    int fd = open(SPIDEV_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("Error opening spidev"); fprintf(stderr, "Check Device Tree configuration.\n"); free(tx_buf); exit(1); }
    
    printf("Writing %ld bytes to sector %ld (Address: 0x%X)...\n", size, sector, addr);
    if (flash_write_enable(fd) != 0 || spi_transfer(fd, tx_buf, NULL, 4 + size) != 0 || flash_wait_busy(fd) != 0) {
        close(fd); free(tx_buf); exit(1);
    }
    
    close(fd); 
    free(tx_buf); 
    printf("Write successful.\n");
}

void handle_flash_read(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "Usage: flash read <type> <sector> <size>\n"); exit(1); }
    long sector = strtol(argv[2], NULL, 0); 
    long size = strtol(argv[3], NULL, 0);
    uint32_t addr = sector * BASE_SECTOR_SIZE;

    if (size <= 0) { fprintf(stderr, "Error: Invalid size.\n"); exit(1); }
    if (sector < 0) { fprintf(stderr, "Error: Sector cannot be negative.\n"); exit(1); }

    uint8_t *tx_buf = calloc(4 + size, 1);
    uint8_t *rx_buf = malloc(4 + size);
    if (!tx_buf || !rx_buf) { perror("malloc"); exit(1); }

    tx_buf[0] = CMD_READ_DATA; 
    tx_buf[1] = (addr >> 16) & 0xFF; 
    tx_buf[2] = (addr >> 8) & 0xFF; 
    tx_buf[3] = addr & 0xFF;
    
    int fd = open(SPIDEV_DEVICE_DEFAULT, O_RDONLY);
    if (fd < 0) { perror("Error opening spidev"); free(tx_buf); free(rx_buf); exit(1); }
    
    int ret = spi_transfer(fd, tx_buf, rx_buf, 4 + size);
    close(fd);

    if (ret != 0) { free(tx_buf); free(rx_buf); exit(1); }
    
    printf("sector=0x%X size=%ld\n", addr, size);
    printf("Data read followed by sector 0x%X\n", addr);
    unsigned char *data_buffer = &rx_buf[4];
    for (long i = 0; i < size; i++) {
        if (i % 8 == 0) {
            if (i > 0) printf("\n");
            printf("offset 0x%08X : ", addr + i);
        }
        printf("%02X ", data_buffer[i]);
    }
    printf("\n");
    free(tx_buf); free(rx_buf);
}

void handle_flash_erase(int argc, char *argv[]) {
    if (argc < 2) { fprintf(stderr, "Usage: flash erase <type> [<start> <end>]\n"); exit(1); }
    char type = argv[1][0];

    int fd = open(SPIDEV_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("Error opening spidev"); exit(1); }

    if (type == 'C' || type == 'c') {
        printf("!!WARNING!! This will erase the ENTIRE chip. Proceed? (y/N): ");
        char confirm = getchar();
        if (confirm != 'y' && confirm != 'Y') { printf("Aborted.\n"); close(fd); exit(0); }
        printf("Erasing entire chip...\n");
        if (flash_write_enable(fd) != 0) { close(fd); exit(1); }
        uint8_t cmd = CMD_CHIP_ERASE;
        if (spi_transfer(fd, &cmd, NULL, 1) != 0) { close(fd); exit(1); }
        if (flash_wait_busy(fd) != 0) { close(fd); exit(1); }
        printf("Chip erase complete.\n"); close(fd); return;
    }

    if (argc != 4) { fprintf(stderr, "Usage for block erase: flash erase <Z|Y|O> <start_param> <end_param>\n"); close(fd); exit(1); }

    long start_param = strtol(argv[2], NULL, 0); 
    long end_param = strtol(argv[3], NULL, 0);
    uint8_t erase_cmd; 
    uint32_t block_size; 
    char* erase_type_str;

    switch(type) {
        case 'Z': erase_cmd = CMD_ERASE_4K; block_size = 4096; erase_type_str = "4KB Sub-sector"; break;
        case 'Y': erase_cmd = CMD_ERASE_32K; block_size = 32768; erase_type_str = "32KB Block"; break;
        case 'O': erase_cmd = CMD_ERASE_128K; block_size = BASE_SECTOR_SIZE; erase_type_str = "128KB Sector"; break;
        default: fprintf(stderr, "Error: Invalid erase type '%c'.\n", type); close(fd); exit(1);
    }

    printf("Erasing using %s command...\n", erase_type_str);
    for (long i = start_param; i <= end_param; i++) {
        uint32_t addr = i * block_size;
        if (addr < g_warn_addr) {
             fprintf(stderr, "!! DANGER: Address 0x%X is below warning address 0x%lX. Aborting.\n", addr, g_warn_addr);
             close(fd); exit(1);
        }
        
        printf("Erasing block at address 0x%X...\n", addr);
        uint8_t tx_buf[4];
        tx_buf[0] = erase_cmd; 
        tx_buf[1] = (addr >> 16) & 0xFF; 
        tx_buf[2] = (addr >> 8) & 0xFF; 
        tx_buf[3] = addr & 0xFF;

        if (flash_write_enable(fd) != 0 || spi_transfer(fd, tx_buf, NULL, 4) != 0 || flash_wait_busy(fd) != 0) {
            close(fd); exit(1);
        }
    }
    
    close(fd); 
    printf("Erase successful.\n");
}

void handle_flash_write_verify(int argc, char *argv[]) {
    if (argc != 7) { fprintf(stderr, "Usage: flash write-verify <t> <sec> <iter> <fail> <log> <full>\n"); exit(1); }
    long start_sector = strtol(argv[2], NULL, 0); 
    long iterations = strtol(argv[3], NULL, 0);
    long fail_stop_count = strtol(argv[4], NULL, 0); 
    int log_enable = atoi(argv[5]); 
    int full_sector_util = atoi(argv[6]);
    unsigned long long iter_count = 0, fail_count = 0, total_pass = 0;
    
    printf("--- Starting SPIDEV Write-Verify Stress Test ---\n");
    printf("Start Sector: %ld | Iterations: %s | Stop on Fails: %s\n", 
            start_sector, (iterations == 0) ? "Infinite" : argv[3], (fail_stop_count == 0) ? "No" : argv[4]);

    unsigned char *write_buf = malloc(PAGE_SIZE); 
    unsigned char *read_buf = malloc(PAGE_SIZE);
    uint8_t spi_tx[4 + PAGE_SIZE]; 
    uint8_t spi_rx[4 + PAGE_SIZE];
    if (!write_buf || !read_buf) { fprintf(stderr, "Error: Failed to malloc test buffers.\n"); exit(1); }

    int fd = open(SPIDEV_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("Error opening spidev"); free(write_buf); free(read_buf); exit(1); }

    while (iterations == 0 || iter_count < iterations) {
        iter_count++;
        long current_sector = full_sector_util ? (start_sector + (iter_count % 240)) : start_sector;
        uint32_t addr = current_sector * BASE_SECTOR_SIZE;
        uint32_t page_addr = addr; // For this test, we operate on the first page of the sector

        if (addr < g_warn_addr) {
            fprintf(stderr, "\n!! DANGER: Calculated sector %ld (addr 0x%X) is in protected region. Stopping.\n", current_sector, addr);
            break;
        }

        generate_pattern_data("A5", write_buf, PAGE_SIZE); write_buf[0] = iter_count & 0xFF;

        uint8_t erase_tx[4] = {CMD_ERASE_128K, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF};
        flash_write_enable(fd); 
        spi_transfer(fd, erase_tx, NULL, 4);
        if (flash_wait_busy(fd) != 0) { fail_count++; if(log_enable) fprintf(stderr, "\nErase fail\n"); continue; }

        spi_tx[0] = CMD_PAGE_PROGRAM; 
        spi_tx[1] = (page_addr >> 16) & 0xFF; 
        spi_tx[2] = (page_addr >> 8) & 0xFF; 
        spi_tx[3] = page_addr & 0xFF;
        memcpy(&spi_tx[4], write_buf, PAGE_SIZE);
        flash_write_enable(fd); 
        spi_transfer(fd, spi_tx, NULL, 4 + PAGE_SIZE);
        if (flash_wait_busy(fd) != 0) { fail_count++; if(log_enable) fprintf(stderr, "\nWrite fail\n"); continue; }

        spi_tx[0] = CMD_READ_DATA;
        spi_transfer(fd, spi_tx, spi_rx, 4 + PAGE_SIZE);
        memcpy(read_buf, &spi_rx[4], PAGE_SIZE);

        if (memcmp(write_buf, read_buf, PAGE_SIZE) == 0) {
            total_pass++;
        } else {
            fail_count++;
            if (log_enable) { fprintf(stderr, "\n[ITER %llu] FAIL on Sector %ld! (Total fails: %llu)\n", iter_count, current_sector, fail_count); }
            if (fail_stop_count > 0 && fail_count >= fail_stop_count) { fprintf(stderr, "\nStopping test: Maximum fail count reached.\n"); break; }
        }
        
        printf("\rTest Progress: Iter %llu | Sector %ld | Pass: %llu | Fail: %llu ", iter_count, current_sector, total_pass, fail_count);
        fflush(stdout);
    }
    
    close(fd); 
    free(write_buf); 
    free(read_buf);
    printf("\n--- Test Complete ---\n");
}