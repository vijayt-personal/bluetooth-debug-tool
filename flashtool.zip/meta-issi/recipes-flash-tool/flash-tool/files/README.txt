NXP i.MX8 Flash Tool (Advanced MTD Version)
============================================

This document provides instructions for the flash_tool CLI. This version uses the standard
Linux MTD subsystem for all flash operations, ensuring safety and compatibility.

1. SAFETY WARNING
-------------------
Writing to the wrong memory location can permanently "brick" your device. This tool
defaults to a safe warning address but can be overridden. ALWAYS consult your board's
memory map and documentation before writing to flash.

The tool automatically determines the valid sector range based on the size of the
MTD partition (e.g., /dev/mtd0).

2. CONFIGURABLE WARNING ADDRESS
-------------------------------
By default, the tool will abort if you try to access memory below 2MB (0x200000).
You can change this limit using the --warn-addr global option.

Example: Allow operations starting from 1MB
  flash-tool --warn-addr 0x100000 flash erase O 8 8

Example: Disable all safety checks (EXTREMELY DANGEROUS)
  flash-tool --warn-addr 0x0 flash erase O 1 1


3. COMMAND REFERENCE
--------------------

  flash write <type> <pattern> <sector> <size>
    - Writes data with a generated pattern to a specified sector.
    - <type> is ignored. Logical sector size is 128KB.

  flash read <type> <sector> <size>
    - Reads data from a specified location with formatted output.
    - Example Output:
        sector=0x200000 size=32
        Data read followed by sector 0x200000
        offset 0x00200000 : 00 01 02 03 04 05 06 07
        offset 0x00200008 : 08 09 0A 0B 0C 0D 0E 0F

  flash erase <type> <start_sector> <end_sector>
    - Erases a region of flash. Must align to the physical erase block size.

  flash write-verify <type> <sector> <iter> <fail_count> <log> <full_util>
    - Performs a continuous write-read-verify stress test.

  clr / help
    - Clears the screen or displays the help message.