/*
 * flash_tool.c
 *
 * An advanced, non-interactive command-line utility for an NXP i.MX8 board.
 * This version uses the native MTD subsystem for safe flash interaction
 * and includes advanced functionality for stress testing.
 *
 * Author: Gemini
 * Date: August 12, 2025
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <ctype.h>
#include <mtd/mtd-user.h>

#define MTD_DEVICE_DEFAULT "/dev/mtd0"
#define BOOTLOADER_WARN_ADDR_DEFAULT 0x200000 // Default safety margin: 2MB
#define SECTOR_SIZE (128 * 1024)             // Define a logical sector as 128KB
#define PAGE_SIZE 256                        // Max size for pattern writes/reads

// Global variable for configurable warning address
unsigned long g_warn_addr = BOOTLOADER_WARN_ADDR_DEFAULT;

// Prototypes
void print_help(const char *app_name);
int generate_pattern_data(const char* pattern, unsigned char* buffer, long size);
int mtd_erase_region(int fd, long offset, long len, const mtd_info_t *mtd_info);
int get_mtd_info(mtd_info_t *mtd_info);
int validate_sector(long sector, const mtd_info_t *mtd_info);

// Command handlers
void handle_flash_write(int argc, char *argv[]);
void handle_flash_read(int argc, char *argv[]);
void handle_flash_erase(int argc, char *argv[]);
void handle_flash_write_verify(int argc, char *argv[]);

int main(int argc, char *argv[]) {
    char *exec_name = argv[0];
    int arg_offset = 1;
    if (argc > 2 && strcmp(argv[1], "--warn-addr") == 0) {
        char *endptr;
        g_warn_addr = strtoul(argv[2], &endptr, 16);
        if (*endptr != '\0') {
            fprintf(stderr, "Error: Invalid hex value for --warn-addr.\n");
            return 1;
        }
        printf(">> Custom Warning Address set to 0x%lX\n", g_warn_addr);
        arg_offset = 3;
    }
    
    argc -= arg_offset;
    argv += arg_offset;

    if (argc < 1) {
        print_help(exec_name);
        return 1;
    }
    
    if (strcmp(argv[0], "flash") == 0) {
        if (argc < 2) { fprintf(stderr, "Error: Missing flash subcommand.\n"); print_help(exec_name); return 1; }
        char *sub_cmd = argv[1];
        if (strcmp(sub_cmd, "write") == 0) handle_flash_write(argc-1, argv+1);
        else if (strcmp(sub_cmd, "read") == 0) handle_flash_read(argc-1, argv+1);
        else if (strcmp(sub_cmd, "erase") == 0) handle_flash_erase(argc-1, argv+1);
        else if (strcmp(sub_cmd, "write-verify") == 0) handle_flash_write_verify(argc-1, argv+1);
        else { fprintf(stderr, "Error: Unknown flash command '%s'.\n", sub_cmd); print_help(exec_name); return 1; }
    } else if (strcmp(argv[0], "clr") == 0) { printf("\033[H\033[J");
    } else if (strcmp(argv[0], "help") == 0) { print_help(exec_name);
    } else { fprintf(stderr, "Error: Unknown command '%s'.\n", argv[0]); print_help(exec_name); return 1; }
    
    return 0;
}

void print_help(const char *app_name) {
    printf("NXP i.MX8 Flash Tool (Advanced MTD Version)\n\n");
    printf("Usage: %s [--warn-addr <hex>] <command> [options]\n\n", app_name);
    printf("Commands:\n");
    printf("  flash write <type> <pattern> <sector> <size>        - Write pattern to flash.\n");
    printf("  flash read <type> <sector> <size>                   - Read data from flash.\n");
    printf("  flash erase <type> <start_sector> <end_sector>      - Erase flash region.\n");
    printf("  flash write-verify <t> <sec> <iter> <fail> <log> <full> - Stress test flash.\n");
    printf("  clr                                                 - Clear terminal screen.\n");
    printf("  help                                                - Show this help message.\n\n");
    printf("NOTE: <type> parameter is ignored. MTD alignment is enforced.\n");
}

int generate_pattern_data(const char* pattern, unsigned char* buffer, long size) {
    if (strcmp(pattern, "+") == 0) { for (long i = 0; i < size; i++) buffer[i] = (unsigned char)(i & 0xFF);
    } else if (strcmp(pattern, "-") == 0) { for (long i = 0; i < size; i++) buffer[i] = (unsigned char)((0xFF - i) & 0xFF);
    } else {
        char *endptr;
        long val = strtol(pattern, &endptr, 16);
        if (*endptr != '\0' || val < 0 || val > 255) { fprintf(stderr, "Error: Invalid hex pattern.\n"); return -1; }
        memset(buffer, (unsigned char)val, size);
    }
    return 0;
}

int get_mtd_info(mtd_info_t *mtd_info) {
    int fd = open(MTD_DEVICE_DEFAULT, O_RDONLY);
    if (fd < 0) { perror("open(MEMGETINFO)"); return -1; }
    if (ioctl(fd, MEMGETINFO, mtd_info) != 0) {
        perror("ioctl(MEMGETINFO)");
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

int validate_sector(long sector, const mtd_info_t *mtd_info) {
    long max_sector = mtd_info->size / SECTOR_SIZE - 1;
    if (sector < 0 || sector > max_sector) {
        fprintf(stderr, "Error: Sector %ld is out of range. Valid range for this device is 0-%ld.\n", sector, max_sector);
        return -1;
    }
    return 0;
}

int mtd_erase_region(int fd, long offset, long len, const mtd_info_t *mtd_info) {
    if (offset % mtd_info->erasesize != 0 || len % mtd_info->erasesize != 0) {
        fprintf(stderr, "Error: Erase offset (0x%lx) and length (0x%lx) must be multiples of the erase block size (0x%x).\n",
                offset, len, mtd_info->erasesize);
        return -1;
    }

    erase_info_t erase_info = { .start = (uint32_t)offset, .length = (uint32_t)len };
    printf("Issuing MEMERASE: start=0x%x, length=0x%x\n", erase_info.start, erase_info.length);
    if (ioctl(fd, MEMERASE, &erase_info) != 0) {
        perror("ioctl(MEMERASE)");
        return -1;
    }
    return 0;
}

void handle_flash_write(int argc, char *argv[]) {
    if (argc != 5) { fprintf(stderr, "Usage: flash write <type> <pattern> <sector> <size>\n"); exit(1); }
    char *pattern = argv[1];
    long sector = strtol(argv[2], NULL, 0);
    long size = strtol(argv[3], NULL, 0);
    long offset = sector * SECTOR_SIZE;

    mtd_info_t mtd_info;
    if (get_mtd_info(&mtd_info) != 0 || validate_sector(sector, &mtd_info) != 0) exit(1);

    if (offset < g_warn_addr) {
        fprintf(stderr, "!! DANGER: Address 0x%lX is below warning address 0x%lX. Aborting.\n", offset, g_warn_addr);
        exit(1);
    }
    if (size <= 0 || size > PAGE_SIZE) {
        fprintf(stderr, "Error: Size must be between 1 and %d bytes.\n", PAGE_SIZE);
        exit(1);
    }

    unsigned char *data_buffer = malloc(size);
    if (!data_buffer || generate_pattern_data(pattern, data_buffer, size) != 0) {
        fprintf(stderr, "Error allocating or generating pattern data.\n");
        if(data_buffer) free(data_buffer);
        exit(1);
    }

    int fd = open(MTD_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("open"); free(data_buffer); exit(1); }

    printf("Writing %ld bytes to sector %ld (Offset 0x%lX)...\n", size, sector, offset);
    
    long erase_offset = (offset / mtd_info.erasesize) * mtd_info.erasesize;
    printf("Pre-erasing alignment block at 0x%lX...\n", erase_offset);
    if (mtd_erase_region(fd, erase_offset, mtd_info.erasesize, &mtd_info) != 0) {
        free(data_buffer); close(fd); exit(1);
    }

    if (lseek(fd, offset, SEEK_SET) == (off_t)-1) {
        perror("lseek");
        free(data_buffer); close(fd); exit(1);
    }
    
    ssize_t written = write(fd, data_buffer, size);
    
    free(data_buffer);
    close(fd);

    if (written != size) {
        fprintf(stderr, "Error: Wrote %ld of %ld bytes.\n", written, size);
        perror("write");
        exit(1);
    }
    printf("Write successful.\n");
}

void handle_flash_read(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "Usage: flash read <type> <sector> <size>\n"); exit(1); }
    long sector = strtol(argv[2], NULL, 0);
    long size = strtol(argv[3], NULL, 0);
    long offset = sector * SECTOR_SIZE;

    mtd_info_t mtd_info;
    if (get_mtd_info(&mtd_info) != 0 || validate_sector(sector, &mtd_info) != 0) exit(1);
    if (size <= 0) { fprintf(stderr, "Error: Invalid size.\n"); exit(1); }

    unsigned char *data_buffer = malloc(size);
    if (!data_buffer) { fprintf(stderr, "Error: malloc failed.\n"); exit(1); }
    
    int fd = open(MTD_DEVICE_DEFAULT, O_RDONLY);
    if (fd < 0) { perror("open"); free(data_buffer); exit(1); }
    
    lseek(fd, offset, SEEK_SET);
    ssize_t bytes_read = read(fd, data_buffer, size);
    close(fd);

    if (bytes_read < 0) { perror("read"); free(data_buffer); exit(1); }
    
    printf("sector=0x%lX size=%ld\n", offset, bytes_read);
    printf("Data read followed by sector 0x%lX\n", offset);
    for (long i = 0; i < bytes_read; i++) {
        if (i % 8 == 0) {
            if (i > 0) printf("\n");
            printf("offset 0x%08lX : ", offset + i);
        }
        printf("%02X ", data_buffer[i]);
    }
    printf("\n");
    free(data_buffer);
}

void handle_flash_erase(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "Usage: flash erase <type> <start_sector> <end_sector>\n"); exit(1); }
    long start_sector = strtol(argv[2], NULL, 0);
    long end_sector = strtol(argv[3], NULL, 0);

    mtd_info_t mtd_info;
    if (get_mtd_info(&mtd_info) != 0) exit(1);
    if (validate_sector(start_sector, &mtd_info) != 0 || validate_sector(end_sector, &mtd_info) != 0) exit(1);

    if (start_sector > end_sector) {
        fprintf(stderr, "Error: Start sector cannot be greater than end sector.\n");
        exit(1);
    }

    long offset = start_sector * SECTOR_SIZE;
    long len = (end_sector - start_sector + 1) * SECTOR_SIZE;

    if (offset < g_warn_addr) {
        fprintf(stderr, "!! DANGER: Address 0x%lX is below warning address 0x%lX. Aborting.\n", offset, g_warn_addr);
        exit(1);
    }
    
    int fd = open(MTD_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("open"); exit(1); }

    printf("Erasing from sector %ld to %ld (Offset 0x%lX, Length 0x%lX)...\n", start_sector, end_sector, offset, len);

    if (mtd_erase_region(fd, offset, len, &mtd_info) != 0) {
        close(fd);
        exit(1);
    }
    
    close(fd);
    printf("Erase successful.\n");
}

void handle_flash_write_verify(int argc, char *argv[]) {
    if (argc != 7) { fprintf(stderr, "Usage: flash write-verify <t> <sec> <iter> <fail> <log> <full>\n"); exit(1); }
    long start_sector = strtol(argv[2], NULL, 0);
    long iterations = strtol(argv[3], NULL, 0);
    long fail_stop_count = strtol(argv[4], NULL, 0);
    int log_enable = atoi(argv[5]);
    int full_sector_util = atoi(argv[6]);

    unsigned long long iter_count = 0, fail_count = 0, total_pass = 0;
    
    printf("--- Starting MTD Write-Verify Stress Test ---\n");
    printf("Start Sector: %ld | Iterations: %s | Stop on Fails: %s\n", 
            start_sector, (iterations == 0) ? "Infinite" : argv[3], (fail_stop_count == 0) ? "No" : argv[4]);

    mtd_info_t mtd_info;
    if (get_mtd_info(&mtd_info) != 0) exit(1);
    
    int fd = open(MTD_DEVICE_DEFAULT, O_RDWR);
    if (fd < 0) { perror("open"); exit(1); }
    
    long max_sectors = mtd_info.size / SECTOR_SIZE;

    unsigned char *write_buf = malloc(SECTOR_SIZE);
    unsigned char *read_buf = malloc(SECTOR_SIZE);
    if (!write_buf || !read_buf) { fprintf(stderr, "Malloc failed for test buffers\n"); close(fd); exit(1); }

    while (iterations == 0 || iter_count < iterations) {
        iter_count++;
        long current_sector = start_sector;
        if (full_sector_util) {
            long safe_sector_start = (g_warn_addr + SECTOR_SIZE - 1) / SECTOR_SIZE;
            long num_safe_sectors = max_sectors - safe_sector_start;
            if (num_safe_sectors <= 0) { fprintf(stderr, "\nError: No safe sectors available for full utilization test.\n"); break; }
            current_sector = safe_sector_start + (iter_count % num_safe_sectors);
        }
        
        if (validate_sector(current_sector, &mtd_info) != 0) {
            fprintf(stderr, "\nError: Calculated sector %ld is invalid. Stopping.\n", current_sector);
            break;
        }
        
        long offset = current_sector * SECTOR_SIZE;
        
        generate_pattern_data("+", write_buf, SECTOR_SIZE);
        write_buf[0] = iter_count & 0xFF;

        if (mtd_erase_region(fd, offset, SECTOR_SIZE, &mtd_info) != 0) { fail_count++; if(log_enable) fprintf(stderr, "\nErase fail on sector %ld\n", current_sector); continue; }
        lseek(fd, offset, SEEK_SET);
        if (write(fd, write_buf, SECTOR_SIZE) != SECTOR_SIZE) { fail_count++; if(log_enable) fprintf(stderr, "\nWrite fail on sector %ld\n", current_sector); continue; }
        lseek(fd, offset, SEEK_SET);
        if (read(fd, read_buf, SECTOR_SIZE) != SECTOR_SIZE) { fail_count++; if(log_enable) fprintf(stderr, "\nRead fail on sector %ld\n", current_sector); continue; }

        if (memcmp(write_buf, read_buf, SECTOR_SIZE) == 0) {
            total_pass++;
        } else {
            fail_count++;
            if (log_enable) { fprintf(stderr, "\n[ITER %llu] VERIFY FAILED on Sector %ld! (Total fails: %llu)\n", iter_count, current_sector, fail_count); }
            if (fail_stop_count > 0 && fail_count >= fail_stop_count) { fprintf(stderr, "\nStopping test: Maximum fail count reached.\n"); break; }
        }
        
        printf("\rTest Progress: Iter %llu | Sector %ld | Pass: %llu | Fail: %llu ", iter_count, current_sector, total_pass, fail_count);
        fflush(stdout);
    }
    
    free(write_buf); free(read_buf);
    close(fd);
    printf("\n--- Test Complete ---\n");
}
