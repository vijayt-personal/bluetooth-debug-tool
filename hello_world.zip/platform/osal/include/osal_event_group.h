#pragma once

#include "osal_types.h"
#include <memory>

/**
 * @file osal_event_group.h
 * @brief Provides a C++ wrapper for an event group.
 */

namespace osal {

class EventGroupImpl; // Forward declaration

/**
 * @class EventGroup
 * @brief A mechanism for tasks to synchronize on specific events.
 *
 * @details An event group is a set of event bits (flags). Tasks can wait for a
 * combination of bits to be set, and other tasks or ISRs can set bits.
 * It's a powerful tool for managing multiple states and events.
 */
class EventGroup {
public:
    /**
     * @brief Constructs an EventGroup.
     */
    EventGroup();

    /**
     * @brief Destroys the EventGroup and releases its resources.
     */
    ~EventGroup();

    // Non-copyable
    EventGroup(const EventGroup&) = delete;
    EventGroup& operator=(const EventGroup&) = delete;

    // Movable
    EventGroup(EventGroup&& other) noexcept;
    EventGroup& operator=(EventGroup&& other) noexcept;

    /**
     * @brief Sets specified bits in the event group.
     * @param bits_to_set A bitmask of the bits to set.
     * @return The value of the event group after the bits are set.
     */
    EventBits SetBits(EventBits bits_to_set);

    /**
     * @brief Clears specified bits in the event group.
     * @param bits_to_clear A bitmask of the bits to clear.
     * @return The value of the event group *before* the bits were cleared.
     */
    EventBits ClearBits(EventBits bits_to_clear);

    /**
     * @brief Waits for a combination of bits to be set.
     * @param bits_to_wait_for The bitmask of bits to wait for.
     * @param clear_on_exit If true, the bits that caused the wait to complete are
     * atomically cleared.
     * @param wait_for_all If true, waits for all bits in the mask to be set.
     * If false, waits for any one of the bits in the mask to be set.
     * @param timeout The maximum duration to wait. Use osal::kMaxDuration to
     * wait indefinitely.
     * @return The value of the event group when the wait condition was met.
     * On timeout, bits that were not set will be 0.
     */
    EventBits WaitBits(EventBits bits_to_wait_for,
                       bool clear_on_exit,
                       bool wait_for_all,
                       Duration timeout = kMaxDuration);

    /**
     * @brief Gets the current value of the event bits.
     * @return The current bitmask of the event group.
     */
    EventBits GetBits() const;

    /**
     * @brief Sets bits in the event group from an Interrupt Service Routine (ISR).
     * @param bits_to_set A bitmask of the bits to set.
     * @param [out] higher_priority_task_woken Set to true by the underlying OS
     * if setting the bits caused a higher priority task to unblock.
     * @return The new value of the event group after the bits are set.
     */
    EventBits SetBitsFromISR(EventBits bits_to_set, bool& higher_priority_task_woken);

    /**
     * @brief Atomically waits for a set of bits, and upon waking, sets other bits.
     * @param bits_to_set The bitmask of bits to set when the wait is satisfied.
     * @param bits_to_wait_for The bitmask of bits to wait for.
     * @param timeout The maximum duration to wait.
     * @return The value of the event group before the new bits were set.
     */
    EventBits Sync(EventBits bits_to_set, EventBits bits_to_wait_for, Duration timeout = kMaxDuration);

private:
    std::unique_ptr<EventGroupImpl> impl_;
};

} // namespace osal
