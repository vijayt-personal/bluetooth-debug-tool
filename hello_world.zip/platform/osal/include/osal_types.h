#pragma once

#include <chrono>
#include <cstdint>

/**
 * @file osal_types.h
 * @brief Common type definitions and constants for the OSAL.
 */

namespace osal {

/**
 * @brief Standard duration type for timeouts, delays, and periods.
 * @details Represents time in milliseconds.
 */
using Duration = std::chrono::milliseconds;

/**
 * @brief Represents an infinite or maximum duration for blocking calls.
 */
constexpr Duration kMaxDuration = Duration::max();

/**
 * @brief Represents event bits for use with osal::EventGroup.
 * @details This is typically a 32-bit unsigned integer.
 */
using EventBits = uint32_t;

/**
 * @brief Default stack depth for tasks in words.
 * @details A "word" is typically 4 bytes on ESP32. This value (4096 words)
 * equates to a 16KB stack, which is a safe default for many tasks.
 * Adjust as needed for specific task requirements.
 */
constexpr uint32_t kDefaultTaskStackDepth = 4096;

/**
 * @brief Default priority for tasks.
 * @details FreeRTOS priorities range from 0 (lowest) to configMAX_PRIORITIES - 1.
 * A value of 5 is a common medium priority.
 */
constexpr uint32_t kDefaultTaskPriority = 5;

/**
 * @brief Constant representing that a task has no specific core affinity.
 * @details The scheduler is free to run the task on any available core.
 */
constexpr int kNoCoreAffinity = -1;

} // namespace osal
