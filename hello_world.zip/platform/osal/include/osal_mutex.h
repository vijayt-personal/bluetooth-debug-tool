#pragma once

#include "osal_types.h"
#include <memory>

/**
 * @file osal_mutex.h
 * @brief Provides a C++ wrapper for a recursive mutex.
 */

namespace osal {

// Forward declaration of the implementation class to hide FreeRTOS details.
class MutexImpl;

/**
 * @class Mutex
 * @brief A recursive mutual exclusion synchronization primitive.
 *
 * @details A recursive mutex can be locked multiple times by the same task
 * without causing a deadlock. The mutex must be unlocked the same
 * number of times it was locked before another task can acquire it.
 */
class Mutex {
public:
    /**
     * @brief Constructs a Mutex.
     */
    Mutex();

    /**
     * @brief Destroys the Mutex and releases its underlying resources.
     */
    ~Mutex();

    // The Mutex is non-copyable.
    Mutex(const Mutex&) = delete;
    Mutex& operator=(const Mutex&) = delete;

    // The Mutex is movable.
    Mutex(Mutex&& other) noexcept;
    Mutex& operator=(Mutex&& other) noexcept;

    /**
     * @brief Locks the mutex, blocking until it becomes available.
     * @param timeout The maximum duration to wait for the lock.
     * Use osal::kMaxDuration to wait indefinitely.
     * @return true if the lock was acquired, false on timeout or error.
     */
    bool Lock(Duration timeout = kMaxDuration);

    /**
     * @brief Tries to lock the mutex without blocking.
     * @return true if the lock was acquired immediately, false otherwise.
     */
    bool TryLock();

    /**
     * @brief Unlocks the mutex.
     * @details A recursive mutex must be unlocked by the owning task for each
     * successful lock call.
     * @return true if the unlock was successful, false on error (e.g., not
     * the owner).
     */
    bool Unlock();

private:
    std::unique_ptr<MutexImpl> impl_;
};

} // namespace osal
