#pragma once

#include "osal_task.h" 
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string>

namespace osal {

/**
 * @class TaskImpl
 * @brief The private implementation of the osal::Task.
 */
class TaskImpl {
public:
    TaskImpl(TaskFunction task_function,
             void* user_data,
             const std::string& name,
             uint32_t stack_depth,
             uint32_t priority,
             int core_id);
    ~TaskImpl();

    TaskImpl(const TaskImpl&) = delete;
    TaskImpl& operator=(const TaskImpl&) = delete;
    TaskImpl(TaskImpl&&) = default;
    TaskImpl& operator=(TaskImpl&&) = default;

    void Suspend();
    void Resume();
    void Delete();

    TaskHandle_t task_handle_;
    std::string name_;
};

} // namespace osal
