#pragma once

#include "osal_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

namespace osal {

/**
 * @class QueueImpl
 * @brief The private implementation of the osal::Queue.
 */
class QueueImpl {
public:
    QueueImpl(uint32_t item_count, uint32_t item_size);
    ~QueueImpl();

    QueueImpl(const QueueImpl&) = delete;
    QueueImpl& operator=(const QueueImpl&) = delete;
    QueueImpl(QueueImpl&&) = default;
    QueueImpl& operator=(QueueImpl&&) = default;

    bool Send(const void* item_to_send, Duration timeout);
    bool Receive(void* buffer, Duration timeout);
    bool Peek(void* buffer, Duration timeout) const;
    bool SendFromISR(const void* item_to_send, bool& higher_priority_task_woken);
    bool ReceiveFromISR(void* buffer, bool& higher_priority_task_woken);
    uint32_t GetCount() const;
    bool Reset();

    QueueHandle_t queue_handle_;
};

} // namespace osal
