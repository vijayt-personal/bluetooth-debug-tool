#pragma once

#include "osal_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

namespace osal {

/**
 * @class MutexImpl
 * @brief The private implementation of the osal::Mutex.
 * @details This class holds the FreeRTOS handle and directly calls
 * FreeRTOS APIs. It is not part of the public API.
 */
class MutexImpl {
public:
    MutexImpl();
    ~MutexImpl();

    MutexImpl(const MutexImpl&) = delete;
    MutexImpl& operator=(const MutexImpl&) = delete;
    MutexImpl(MutexImpl&&) = default;
    MutexImpl& operator=(MutexImpl&&) = default;

    bool Lock(Duration timeout);
    bool Unlock();

    SemaphoreHandle_t mutex_handle_;
};

} // namespace osal
