#include "osal_queue_impl.h"
#include <esp_log.h>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalQueue";

QueueImpl::QueueImpl(uint32_t item_count, uint32_t item_size)
    : queue_handle_(nullptr) {
    if (item_count == 0 || item_size == 0) {
        ESP_LOGE(kTag, "Queue item count and size must be greater than 0.");
        return;
    }
    queue_handle_ = xQueueCreate(item_count, item_size);
    if (queue_handle_ == nullptr) {
        ESP_LOGE(kTag, "Failed to create queue.");
    }
}

QueueImpl::~QueueImpl() {
    if (queue_handle_ != nullptr) {
        vQueueDelete(queue_handle_);
        queue_handle_ = nullptr;
    }
}

bool QueueImpl::Send(const void* item_to_send, Duration timeout) {
    if (queue_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xQueueSend(queue_handle_, item_to_send, ticks_to_wait) == pdTRUE);
}

bool QueueImpl::Receive(void* buffer, Duration timeout) {
    if (queue_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xQueueReceive(queue_handle_, buffer, ticks_to_wait) == pdTRUE);
}

bool QueueImpl::Peek(void* buffer, Duration timeout) const {
    if (queue_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xQueuePeek(queue_handle_, buffer, ticks_to_wait) == pdTRUE);
}

bool QueueImpl::SendFromISR(const void* item_to_send, bool& higher_priority_task_woken) {
    if (queue_handle_ == nullptr) {
        higher_priority_task_woken = false;
        return false;
    }
    BaseType_t x_higher_priority_task_woken = pdFALSE;
    bool success = (xQueueSendFromISR(queue_handle_, item_to_send, &x_higher_priority_task_woken) == pdTRUE);
    higher_priority_task_woken = (x_higher_priority_task_woken == pdTRUE);
    return success;
}

bool QueueImpl::ReceiveFromISR(void* buffer, bool& higher_priority_task_woken) {
    if (queue_handle_ == nullptr) {
        higher_priority_task_woken = false;
        return false;
    }
    BaseType_t x_higher_priority_task_woken = pdFALSE;
    bool success = (xQueueReceiveFromISR(queue_handle_, buffer, &x_higher_priority_task_woken) == pdTRUE);
    higher_priority_task_woken = (x_higher_priority_task_woken == pdTRUE);
    return success;
}

uint32_t QueueImpl::GetCount() const {
    if (queue_handle_ == nullptr) return 0;
    // This can be called from an ISR context as well.
    if (xPortInIsrContext()) {
        return uxQueueMessagesWaitingFromISR(queue_handle_);
    }
    return uxQueueMessagesWaiting(queue_handle_);
}

bool QueueImpl::Reset() {
    if (queue_handle_ == nullptr) return false;
    return (xQueueReset(queue_handle_) == pdTRUE);
}

} // namespace osal
