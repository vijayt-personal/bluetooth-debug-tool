#include "osal_semaphore_impl.h"
#include <esp_log.h>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalSemaphore";

SemaphoreImpl::SemaphoreImpl(uint32_t max_count, uint32_t initial_count)
    : semaphore_handle_(nullptr) {
    if (max_count == 0) {
        ESP_LOGE(kTag, "Max count for semaphore cannot be 0.");
        return;
    }
    if (initial_count > max_count) {
        ESP_LOGW(kTag, "Initial count (%lu) > max count (%lu). Clamping to max.",
                 (unsigned long)initial_count, (unsigned long)max_count);
        initial_count = max_count;
    }

    if (max_count == 1) { // Binary semaphore
        semaphore_handle_ = xSemaphoreCreateBinary();
        if (semaphore_handle_ != nullptr && initial_count == 1) {
            xSemaphoreGive(semaphore_handle_);
        }
    } else { // Counting semaphore
        semaphore_handle_ = xSemaphoreCreateCounting(max_count, initial_count);
    }

    if (semaphore_handle_ == nullptr) {
        ESP_LOGE(kTag, "Failed to create semaphore.");
    }
}

SemaphoreImpl::~SemaphoreImpl() {
    if (semaphore_handle_ != nullptr) {
        vSemaphoreDelete(semaphore_handle_);
        semaphore_handle_ = nullptr;
    }
}

bool SemaphoreImpl::Acquire(Duration timeout) {
    if (semaphore_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xSemaphoreTake(semaphore_handle_, ticks_to_wait) == pdTRUE);
}

bool SemaphoreImpl::Release() {
    if (semaphore_handle_ == nullptr) return false;
    return (xSemaphoreGive(semaphore_handle_) == pdTRUE);
}

bool SemaphoreImpl::ReleaseFromISR(bool& higher_priority_task_woken) {
    if (semaphore_handle_ == nullptr) {
        higher_priority_task_woken = false;
        return false;
    }
    BaseType_t x_higher_priority_task_woken = pdFALSE;
    bool success = (xSemaphoreGiveFromISR(semaphore_handle_, &x_higher_priority_task_woken) == pdTRUE);
    higher_priority_task_woken = (x_higher_priority_task_woken == pdTRUE);
    return success;
}

uint32_t SemaphoreImpl::GetCount() const {
    if (semaphore_handle_ == nullptr) return 0;
    return uxSemaphoreGetCount(semaphore_handle_);
}

} // namespace osal
