#include "osal_task_impl.h"
#include <esp_log.h>
#include <utility>
#include <array>
#include <mutex> // Required for std::mutex to protect the argument pool

namespace osal {

// File-static logger tag
static const char* kTag = "OsalTask";

/**
 * @brief Helper struct to pass both the C++ function object and user data
 * to the C-style FreeRTOS task entry point.
 */
struct TaskRunnerArgs {
    TaskFunction task_function_;
    void* user_data_;
};

// --- Task Argument Memory Pool ---
// This pattern avoids dynamic memory allocation (new/delete) for task arguments,
// which is safer for embedded systems and eliminates compiler warnings.

// Maximum number of tasks that can be created concurrently. Adjust if needed.
constexpr size_t kMaxConcurrentTasks = 16; 

// A pre-allocated pool of argument structures.
static std::array<TaskRunnerArgs, kMaxConcurrentTasks> g_task_args_pool;
// A corresponding array to track which pool slots are in use.
static std::array<bool, kMaxConcurrentTasks> g_task_args_in_use{};
// A mutex to ensure thread-safe allocation/deallocation from the pool.
static std::mutex g_task_args_mutex;

/**
 * @brief Allocates a TaskRunnerArgs struct from the static pool.
 * @return A pointer to an available struct, or nullptr if the pool is full.
 */
static TaskRunnerArgs* AllocateArgs() {
    std::lock_guard<std::mutex> lock(g_task_args_mutex);
    for (size_t i = 0; i < kMaxConcurrentTasks; ++i) {
        if (!g_task_args_in_use[i]) {
            g_task_args_in_use[i] = true;
            return &g_task_args_pool[i];
        }
    }
    ESP_LOGE(kTag, "Task argument pool is full! Increase kMaxConcurrentTasks.");
    return nullptr;
}

/**
 * @brief Returns a TaskRunnerArgs struct to the static pool.
 * @param args_ptr A pointer to the struct to be freed.
 */
static void FreeArgs(TaskRunnerArgs* args_ptr) {
    if (args_ptr == nullptr) return;
    
    std::lock_guard<std::mutex> lock(g_task_args_mutex);
    // Calculate the index of the pointer within the pool
    ptrdiff_t index = args_ptr - g_task_args_pool.data();
    if (index >= 0 && index < kMaxConcurrentTasks) {
        // Clear the function object to release any captured resources
        g_task_args_pool[index].task_function_ = nullptr;
        g_task_args_in_use[index] = false;
    }
}


/**
 * @brief This C-style function is the actual entry point for all created tasks.
 * @details It executes the user function and then frees the argument struct
 * back to the memory pool before deleting the task itself.
 * @param parameters A pointer to a TaskRunnerArgs struct from the pool.
 */
static void task_entry_point(void* parameters) {
    auto* args = static_cast<TaskRunnerArgs*>(parameters);
    if (!args) {
        ESP_LOGE(kTag, "Task started with null arguments. Aborting.");
        vTaskDelete(nullptr);
        return;
    }

    if (args->task_function_) {
        args->task_function_(args->user_data_);
    }

    // The task function has returned. Free the argument struct back to the pool.
    FreeArgs(args);
    
    // Delete the task.
    vTaskDelete(nullptr);
}

TaskImpl::TaskImpl(TaskFunction task_function,
                   void* user_data,
                   const std::string& name,
                   uint32_t stack_depth,
                   uint32_t priority,
                   int core_id)
    : task_handle_(nullptr), name_(name) {
    
    if (stack_depth == 0) {
        ESP_LOGE(kTag, "Task '%s': Stack depth cannot be 0.", name_.c_str());
        return;
    }
    if (priority >= configMAX_PRIORITIES) {
        ESP_LOGW(kTag, "Task '%s': Priority %lu is too high, clamping to %d.",
                 name_.c_str(), (unsigned long)priority, configMAX_PRIORITIES - 1);
        priority = configMAX_PRIORITIES - 1;
    }

    // Allocate an argument structure from our warning-free static pool.
    TaskRunnerArgs* runner_args = AllocateArgs();
    if (!runner_args) {
        // Error already logged by AllocateArgs
        return;
    }
    // Populate the struct.
    runner_args->task_function_ = std::move(task_function);
    runner_args->user_data_ = user_data;

    BaseType_t result;
    if (core_id == kNoCoreAffinity) {
        result = xTaskCreate(task_entry_point, name_.c_str(), stack_depth,
                             runner_args, priority, &task_handle_);
    } else {
        result = xTaskCreatePinnedToCore(task_entry_point, name_.c_str(),
                                         stack_depth, runner_args, priority,
                                         &task_handle_, static_cast<BaseType_t>(core_id));
    }

    if (result != pdPASS) {
        ESP_LOGE(kTag, "Failed to create task '%s'. FreeRTOS error code: %d", name_.c_str(), result);
        // Clean up the argument struct if task creation fails
        FreeArgs(runner_args);
        task_handle_ = nullptr;
    } else {
        ESP_LOGD(kTag, "Task '%s' created successfully.", name_.c_str());
    }
}

TaskImpl::~TaskImpl() {
    if (task_handle_ != nullptr) {
        ESP_LOGD(kTag, "osal::Task for '%s' destroyed, FreeRTOS task handle %p remains (detached).",
                 name_.c_str(), task_handle_);
    }
}

void TaskImpl::Suspend() {
    if (task_handle_ != nullptr) {
        vTaskSuspend(task_handle_);
    }
}

void TaskImpl::Resume() {
    if (task_handle_ != nullptr) {
        vTaskResume(task_handle_);
    }
}

void TaskImpl::Delete() {
    if (task_handle_ != nullptr) {
        ESP_LOGW(kTag, "Forcefully deleting task '%s'.", name_.c_str());
        TaskHandle_t handle_to_delete = task_handle_;
        task_handle_ = nullptr;
        vTaskDelete(handle_to_delete);
    }
}

} // namespace osal
