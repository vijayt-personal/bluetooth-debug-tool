#include "osal_event_group_impl.h"
#include <esp_log.h>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalEventGroup";

EventGroupImpl::EventGroupImpl() : event_group_handle_(nullptr) {
    event_group_handle_ = xEventGroupCreate();
    if (event_group_handle_ == nullptr) {
        ESP_LOGE(kTag, "Failed to create event group.");
    }
}

EventGroupImpl::~EventGroupImpl() {
    if (event_group_handle_ != nullptr) {
        vEventGroupDelete(event_group_handle_);
        event_group_handle_ = nullptr;
    }
}

EventBits EventGroupImpl::SetBits(EventBits bits_to_set) {
    if (event_group_handle_ == nullptr) return 0;
    return xEventGroupSetBits(event_group_handle_, static_cast<EventBits_t>(bits_to_set));
}

EventBits EventGroupImpl::ClearBits(EventBits bits_to_clear) {
    if (event_group_handle_ == nullptr) return 0;
    return xEventGroupClearBits(event_group_handle_, static_cast<EventBits_t>(bits_to_clear));
}

EventBits EventGroupImpl::WaitBits(EventBits bits_to_wait_for,
                                   bool clear_on_exit,
                                   bool wait_for_all,
                                   Duration timeout) {
    if (event_group_handle_ == nullptr) return 0;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;

    return xEventGroupWaitBits(event_group_handle_,
                               static_cast<EventBits_t>(bits_to_wait_for),
                               clear_on_exit ? pdTRUE : pdFALSE,
                               wait_for_all ? pdTRUE : pdFALSE,
                               ticks_to_wait);
}

EventBits EventGroupImpl::GetBits() const {
    if (event_group_handle_ == nullptr) return 0;
    // This can be called from an ISR context as well.
    if (xPortInIsrContext()) {
        return xEventGroupGetBitsFromISR(event_group_handle_);
    }
    return xEventGroupGetBits(event_group_handle_);
}

EventBits EventGroupImpl::SetBitsFromISR(EventBits bits_to_set, bool& higher_priority_task_woken) {
    if (event_group_handle_ == nullptr) {
        higher_priority_task_woken = false;
        return 0;
    }
    BaseType_t x_higher_priority_task_woken = pdFALSE;
    xEventGroupSetBitsFromISR(event_group_handle_, static_cast<EventBits_t>(bits_to_set), &x_higher_priority_task_woken);
    higher_priority_task_woken = (x_higher_priority_task_woken == pdTRUE);
    return xEventGroupGetBitsFromISR(event_group_handle_);
}

EventBits EventGroupImpl::Sync(EventBits bits_to_set, EventBits bits_to_wait_for, Duration timeout) {
    if (event_group_handle_ == nullptr) return 0;
    TickType_t ticks_to_wait = (timeout == kMaxDuration) ? portMAX_DELAY : pdMS_TO_TICKS(timeout.count());
    if (timeout.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;

    return xEventGroupSync(event_group_handle_,
                           static_cast<EventBits_t>(bits_to_set),
                           static_cast<EventBits_t>(bits_to_wait_for),
                           ticks_to_wait);
}

} // namespace osal
