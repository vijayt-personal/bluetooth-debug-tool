#include "osal_timer_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalTimer";

/**
 * @brief This C-style function is the entry point for all timer callbacks.
 * @details It safely retrieves the C++ std::function pointer from the timer's
 * ID and executes it. With exceptions disabled, it is the user's
 * responsibility to ensure their callback code does not throw.
 * @param xTimer The handle of the timer that expired.
 */
static void timer_callback_entry_point(TimerHandle_t xTimer) {
    // Retrieve the std::function pointer from the timer's ID
    TimerCallback* callback_ptr = static_cast<TimerCallback*>(pvTimerGetTimerID(xTimer));
    if (callback_ptr && (*callback_ptr)) { // Check both pointer and function object
        // Directly execute the callback.
        // If the callback attempts to throw an exception on a system with
        // exceptions disabled, it will likely result in std::terminate being called.
        (*callback_ptr)();
    }
}

TimerImpl::TimerImpl(const std::string& name,
                     TimerCallback callback,
                     Duration period,
                     bool auto_reload)
    : timer_handle_(nullptr), name_(name), user_callback_(std::move(callback)) {

    if (period.count() <= 0) {
        ESP_LOGE(kTag, "Timer '%s': Period must be positive.", name_.c_str());
        return;
    }
    TickType_t timer_period_ticks = pdMS_TO_TICKS(period.count());
    if (timer_period_ticks == 0) {
        timer_period_ticks = 1;
        ESP_LOGW(kTag, "Timer '%s': period %lld ms converted to 0 ticks, using 1 tick.", name_.c_str(), (long long)period.count());
    }
    
    // The timer ID is a pointer to the user_callback_ member. This is safe because
    // the destructor ensures the OS timer is deleted before user_callback_ is destroyed.
    timer_handle_ = xTimerCreate(name_.c_str(),
                                 timer_period_ticks,
                                 auto_reload ? pdTRUE : pdFALSE,
                                 static_cast<void*>(&user_callback_),
                                 timer_callback_entry_point);

    if (timer_handle_ == nullptr) {
        ESP_LOGE(kTag, "Failed to create timer '%s'.", name_.c_str());
    }
}

TimerImpl::~TimerImpl() {
    if (timer_handle_ != nullptr) {
        // Block indefinitely to ensure the timer is stopped and then deleted.
        // This is crucial to prevent the timer callback from firing after this
        // object (and its user_callback_ member) has been destroyed.
        if (xTimerIsTimerActive(timer_handle_)) {
            xTimerStop(timer_handle_, portMAX_DELAY);
        }
        xTimerDelete(timer_handle_, portMAX_DELAY);
        timer_handle_ = nullptr;
    }
}

bool TimerImpl::Start(Duration block_time) {
    if (timer_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = pdMS_TO_TICKS(block_time.count());
    if (block_time.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xTimerStart(timer_handle_, ticks_to_wait) == pdPASS);
}

bool TimerImpl::Stop(Duration block_time) {
    if (timer_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = pdMS_TO_TICKS(block_time.count());
    if (block_time.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xTimerStop(timer_handle_, ticks_to_wait) == pdPASS);
}

bool TimerImpl::Reset(Duration block_time) {
    if (timer_handle_ == nullptr) return false;
    TickType_t ticks_to_wait = pdMS_TO_TICKS(block_time.count());
    if (block_time.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;
    return (xTimerReset(timer_handle_, ticks_to_wait) == pdPASS);
}

bool TimerImpl::ChangePeriod(Duration new_period, Duration block_time) {
    if (timer_handle_ == nullptr) return false;
    if (new_period.count() <= 0) {
        ESP_LOGE(kTag, "Timer '%s': New period must be positive.", name_.c_str());
        return false;
    }
    TickType_t new_period_ticks = pdMS_TO_TICKS(new_period.count());
    if (new_period_ticks == 0) new_period_ticks = 1;

    TickType_t ticks_to_wait = pdMS_TO_TICKS(block_time.count());
    if (block_time.count() > 0 && ticks_to_wait == 0) ticks_to_wait = 1;

    return (xTimerChangePeriod(timer_handle_, new_period_ticks, ticks_to_wait) == pdPASS);
}

bool TimerImpl::IsRunning() const {
    return (timer_handle_ != nullptr && xTimerIsTimerActive(timer_handle_) != pdFALSE);
}

} // namespace osal
