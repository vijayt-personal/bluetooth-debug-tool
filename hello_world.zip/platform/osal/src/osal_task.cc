#include "osal_task.h"
#include "osal_task_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

Task::Task(TaskFunction task_function,
           void* user_data,
           const std::string& name,
           uint32_t stack_depth,
           uint32_t priority,
           int core_id)
    : impl_(std::make_unique<TaskImpl>(std::move(task_function), user_data, name, stack_depth, priority, core_id)) {}

Task::~Task() = default;

Task::Task(Task&& other) noexcept = default;

Task& Task::operator=(Task&& other) noexcept = default;

void Task::Suspend() {
    if (impl_) impl_->Suspend();
}

void Task::Resume() {
    if (impl_) impl_->Resume();
}

void Task::Delete() {
    if (impl_) impl_->Delete();
}

void Task::SleepFor(Duration duration) {
    if (duration.count() < 0) {
        return; // Sleeping for a negative duration is a no-op.
    }
    TickType_t ticks_to_delay = pdMS_TO_TICKS(duration.count());
    // Ensure that a small, non-zero millisecond duration results in a delay
    // of at least one tick. A zero duration will yield.
    if (duration.count() > 0 && ticks_to_delay == 0) {
        ticks_to_delay = 1;
    }
    vTaskDelay(ticks_to_delay);
}

uint32_t Task::GetTickCount() {
    // Can be called from ISR or task context.
    return xTaskGetTickCount();
}

uint32_t Task::GetMinFreeStackWords() {
    // The first argument 'NULL' specifies the calling task.
    return uxTaskGetStackHighWaterMark(NULL);
}

bool Task::IsValid() const {
    return impl_ && impl_->task_handle_ != nullptr;
}

} // namespace osal
