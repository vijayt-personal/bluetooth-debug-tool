#include "osal_event_group.h"
#include "osal_event_group_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalEventGroup";

EventGroup::EventGroup() : impl_(std::make_unique<EventGroupImpl>()) {}

EventGroup::~EventGroup() = default;

EventGroup::EventGroup(EventGroup&& other) noexcept = default;

EventGroup& EventGroup::operator=(EventGroup&& other) noexcept = default;

EventBits EventGroup::SetBits(EventBits bits_to_set) {
    if (!impl_ || !impl_->event_group_handle_) {
        ESP_LOGE(kTag, "SetBits: EventGroup not properly initialized.");
        return 0;
    }
    return impl_->SetBits(bits_to_set);
}

EventBits EventGroup::ClearBits(EventBits bits_to_clear) {
    if (!impl_ || !impl_->event_group_handle_) {
        ESP_LOGE(kTag, "ClearBits: EventGroup not properly initialized.");
        return 0;
    }
    return impl_->ClearBits(bits_to_clear);
}

EventBits EventGroup::WaitBits(EventBits bits_to_wait_for,
                               bool clear_on_exit,
                               bool wait_for_all,
                               Duration timeout) {
    if (!impl_ || !impl_->event_group_handle_) {
        ESP_LOGE(kTag, "WaitBits: EventGroup not properly initialized.");
        return 0;
    }
    return impl_->WaitBits(bits_to_wait_for, clear_on_exit, wait_for_all, timeout);
}

EventBits EventGroup::GetBits() const {
    if (!impl_ || !impl_->event_group_handle_) {
        ESP_LOGE(kTag, "GetBits: EventGroup not properly initialized.");
        return 0;
    }
    return impl_->GetBits();
}

EventBits EventGroup::SetBitsFromISR(EventBits bits_to_set, bool& higher_priority_task_woken) {
    if (!impl_ || !impl_->event_group_handle_) {
        higher_priority_task_woken = false;
        return 0;
    }
    return impl_->SetBitsFromISR(bits_to_set, higher_priority_task_woken);
}

EventBits EventGroup::Sync(EventBits bits_to_set, EventBits bits_to_wait_for, Duration timeout) {
    if (!impl_ || !impl_->event_group_handle_) {
        ESP_LOGE(kTag, "Sync: EventGroup not properly initialized.");
        return 0;
    }
    return impl_->Sync(bits_to_set, bits_to_wait_for, timeout);
}

} // namespace osal
