#include "osal_semaphore.h"
#include "osal_semaphore_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalSemaphore";

Semaphore::Semaphore(uint32_t max_count, uint32_t initial_count)
    : impl_(std::make_unique<SemaphoreImpl>(max_count, initial_count)) {}

Semaphore::~Semaphore() = default;

Semaphore::Semaphore(Semaphore&& other) noexcept = default;

Semaphore& Semaphore::operator=(Semaphore&& other) noexcept = default;

bool Semaphore::Acquire(Duration timeout) {
    if (!impl_ || !impl_->semaphore_handle_) {
        ESP_LOGE(kTag, "Acquire: Semaphore not properly initialized.");
        return false;
    }
    return impl_->Acquire(timeout);
}

bool Semaphore::Release() {
    if (!impl_ || !impl_->semaphore_handle_) {
        ESP_LOGE(kTag, "Release: Semaphore not properly initialized.");
        return false;
    }
    return impl_->Release();
}

bool Semaphore::ReleaseFromISR(bool& higher_priority_task_woken) {
    if (!impl_ || !impl_->semaphore_handle_) {
        // Avoid logging from ISR context for safety
        higher_priority_task_woken = false;
        return false;
    }
    return impl_->ReleaseFromISR(higher_priority_task_woken);
}

uint32_t Semaphore::GetCount() const {
    if (!impl_ || !impl_->semaphore_handle_) {
        ESP_LOGE(kTag, "GetCount: Semaphore not properly initialized.");
        return 0;
    }
    return impl_->GetCount();
}

} // namespace osal
