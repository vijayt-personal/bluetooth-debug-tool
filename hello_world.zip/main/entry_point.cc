#include <iostream>
#include <string>
#include <memory>
#include <atomic>
#include <utility> // For std::forward

// Include the necessary OSAL headers
#include "osal_mutex.h"
#include "osal_queue.h"
#include "osal_task.h"
#include "osal_types.h"

// For ESP-IDF logging and time
#include "esp_log.h"
#include "esp_timer.h"

static const char* kExampleTag = "AppExample";

// --- 1. Define the Shared Application Context ---

struct SensorData {
    uint32_t timestamp;
    float value;
};

struct AppContext {
    osal::Mutex data_access_mutex;
    osal::Queue sensor_data_queue;
    AppContext() : sensor_data_queue(10, sizeof(SensorData)) {}
};


// --- 2. Define the Manager (Policy) Classes ---

class SensorDataManager {
public:
    explicit SensorDataManager(AppContext& context) 
        : context_(context), is_running_(false) {}

    void Init() {
        ESP_LOGI("SensorTask", "Manager initializing...");
        is_running_ = true;
    }
    
    void Deinit() {
        ESP_LOGI("SensorTask", "Manager de-initializing...");
        is_running_ = false;
    }

    bool IsRunning() const { return is_running_; }

    void Run() {
        SensorData data;
        data.timestamp = osal::Task::GetTickCount();
        data.value = (rand() % 1000) / 10.0f;

        ESP_LOGI("SensorTask", "Read sensor data (value: %.2f). Sending to queue.", data.value);

        if (!context_.sensor_data_queue.Send(&data, osal::Duration(100))) {
            ESP_LOGE("SensorTask", "Failed to send data to queue!");
        }
    }

private:
    AppContext& context_;
    std::atomic<bool> is_running_;
};

class NetworkUploader {
public:
    explicit NetworkUploader(AppContext& context)
        : context_(context), is_running_(false) {}

    void Init() {
        ESP_LOGI("NetworkTask", "Manager initializing. Waiting for data to upload.");
        is_running_ = true;
    }

    void Deinit() {
        ESP_LOGI("NetworkTask", "Manager de-initializing...");
        is_running_ = false;
    }

    bool IsRunning() const { return is_running_; }

    void Run() {
        SensorData data;
        if (context_.sensor_data_queue.Receive(&data, osal::Duration(1000))) {
            ESP_LOGW("NetworkTask", "--> Received data from queue. Timestamp: %lu, Value: %.2f. SIMULATING UPLOAD.",
                     data.timestamp, data.value);
        }
    }

private:
    AppContext& context_;
    std::atomic<bool> is_running_;
};


// --- 3. The Generic TaskRunner ---
// Updated to be fully configurable.
template <typename ManagerPolicy>
class TaskRunner {
public:
    /**
     * @brief Constructs the TaskRunner with full configuration.
     * @param name Name of the task for debugging.
     * @param work_interval The delay between calls to manager.Run(). Use 0 for event-driven tasks.
     * @param priority The FreeRTOS priority for the task.
     * @param stack_size The stack size in words for the task.
     * @param args Arguments to be forwarded to the ManagerPolicy constructor.
     */
    template<typename... Args>
    explicit TaskRunner(const std::string& name,
                        osal::Duration work_interval,
                        uint32_t priority,
                        uint32_t stack_size,
                        Args&&... args)
        : manager_(std::forward<Args>(args)...), 
          task_name_(name),
          work_interval_(work_interval),
          priority_(priority),
          stack_size_(stack_size)
    {}

    void Start() {
        task_ = std::make_unique<osal::Task>(
            [this](void*) { this->Execute(); },
            nullptr, task_name_, stack_size_, priority_
        );
        if (!task_->IsValid()) {
            ESP_LOGE(kExampleTag, "Failed to start TaskRunner for %s", task_name_.c_str());
        }
    }

    ManagerPolicy& GetManager() { return manager_; }

private:
    void Execute() {
        manager_.Init();
        
        const int64_t stack_check_interval_ms = 10000; // Check stack every 10 seconds
        int64_t last_stack_check_ms = 0;

        while (manager_.IsRunning()) {
            manager_.Run();

            // If a work interval is configured, sleep for that duration.
            if (work_interval_.count() > 0) {
                osal::Task::SleepFor(work_interval_);
            }

            // Periodically check task stack usage
            int64_t current_time_ms = esp_timer_get_time() / 1000;
            if (current_time_ms - last_stack_check_ms >= stack_check_interval_ms) {
                // Use the new OSAL method to get stack info, keeping the abstraction pure.
                uint32_t min_free_stack = osal::Task::GetMinFreeStackWords();
                ESP_LOGD(task_name_.c_str(), "Stack health: %lu words free (min)", min_free_stack);
                last_stack_check_ms = current_time_ms;
            }
        }
        ESP_LOGI(task_name_.c_str(), "Run loop finished. Manager de-initializing.");
        manager_.Deinit();
    }

    ManagerPolicy manager_;
    std::string task_name_;
    std::unique_ptr<osal::Task> task_;
    
    // Configuration members
    osal::Duration work_interval_;
    uint32_t priority_;
    uint32_t stack_size_;
};


// --- 4. The Main Application Class ---
class App {
public:
    App() {
        ESP_LOGI(kExampleTag, "Application initializing...");
        // The constructor creates the task runners, injecting the context and providing full configuration.
        sensor_runner_ = std::make_unique<TaskRunner<SensorDataManager>>(
            "SensorTask",           // Task Name
            osal::Duration(2000),   // Work Interval (polling)
            5,                      // Priority
            4096,                   // Stack Size
            context_                // Manager Argument (AppContext)
        );

        network_runner_ = std::make_unique<TaskRunner<NetworkUploader>>(
            "NetworkTask",          // Task Name
            osal::Duration(0),      // Work Interval (event-driven)
            5,                      // Priority
            4096,                   // Stack Size
            context_                // Manager Argument (AppContext)
        );
    }

    void Start() {
        ESP_LOGI(kExampleTag, "Starting application services...");
        sensor_runner_->Start();
        network_runner_->Start();
    }
    
    void Stop() {
        ESP_LOGI(kExampleTag, "Stopping application services...");
        // Calling Deinit on the manager signals it to stop its loop.
        sensor_runner_->GetManager().Deinit();
        network_runner_->GetManager().Deinit();
    }
    
    void RunMainLoop() {
        ESP_LOGI(kExampleTag, "Application running. Main task entering idle loop.");
        while (true) {
            osal::Task::SleepFor(osal::Duration(10000));
        }
    }

private:
    AppContext context_;
    std::unique_ptr<TaskRunner<SensorDataManager>> sensor_runner_;
    std::unique_ptr<TaskRunner<NetworkUploader>> network_runner_;
};


// --- 5. app_main (Now extremely simple) ---
extern "C" void app_main(void) {
    auto app = std::make_unique<App>();
    app->Start();
    app->RunMainLoop();
}
