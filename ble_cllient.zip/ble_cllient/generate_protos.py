import os
import sys
import subprocess


def compile_protos():
    """
    Finds all .proto files in the 'protos' directory and compiles them
    into Python modules in the 'input' directory.
    """
    protos_dir = 'protos'
    output_dir = 'input'

    # Ensure the output directory exists
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # We assume 'input/__init__.py' exists, making 'input' a package.

    print(f"Compiling .proto files from '{protos_dir}/' into '{output_dir}/'")

    try:
        # Find all .proto files to be compiled
        proto_files = [os.path.join(protos_dir, f) for f in os.listdir(protos_dir) if f.endswith('.proto')]
        if not proto_files:
            print("No .proto files found to compile.")
            return

        # The command to run the protobuf compiler
        command = [
            sys.executable,
            '-m',
            'grpc_tools.protoc',
            f'--proto_path={protos_dir}',  # Look for .proto files here
            f'--python_out={output_dir}'  # Output generated Python files here
        ]
        command.extend(proto_files)

        # Execute the command
        subprocess.run(command, check=True)
        print("Protobuf files compiled successfully.")

    except subprocess.CalledProcessError as e:
        print(f"Error: Failed to compile .proto files.\n{e}")
        print("Please ensure 'grpcio-tools' is installed (`pip install -r requirements.txt`)")
        sys.exit(1)
    except FileNotFoundError:
        print("Error: 'protoc' command not found.")
        print("Please ensure 'grpcio-tools' is installed (`pip install -r requirements.txt`)")
        sys.exit(1)


if __name__ == "__main__":
    compile_protos()
