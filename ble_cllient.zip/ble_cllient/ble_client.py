import asyncio
import logging
from typing import Optional
from bleak import BleakClient, BleakScanner
from utils import constants as const

logger = logging.getLogger(__name__)


class BleClient:
    """Manages BLE connection and communication."""

    def __init__(self):
        self._client: Optional[BleakClient] = None
        self._notification_queue = asyncio.Queue()

    def is_connected(self) -> bool:
        return self._client is not None and self._client.is_connected

    async def scan_and_connect(self, mac_address: str = None, device_name: str = None) -> bool:
        """Scans for a device and connects, prioritizing MAC, then name, then service."""
        target_address = mac_address
        device = None

        if target_address:
            logger.info(f"Attempting to connect directly to specified MAC address: {target_address}...")
        elif device_name:
            logger.info(f"Scanning for device with name '{device_name}'...")
            device = await BleakScanner.find_device_by_name(device_name, timeout=10.0)
        else:
            logger.info("Scanning for device with OTA service UUID...")
            device = await BleakScanner.find_device_by_filter(
                lambda d, ad: const.DEVICE_UPDATE_SERVICE_UUID in ad.service_uuids,
                timeout=10.0
            )

        # If we scanned and found a device, get its address
        if device:
            target_address = device.address
            logger.info(f"Found device: {device.name} ({target_address})")

        if not target_address:
            logger.error("Could not find a target device. Please check Bluetooth, device power, and configuration.")
            return False

        logger.info(f"Connecting to {target_address}...")
        try:
            self._client = BleakClient(target_address)
            await self._client.connect()

            logger.info(f"Connection successful. Negotiated MTU: {self._client.mtu_size} bytes")

            logger.info("Enabling notifications...")
            await self._client.start_notify(const.STATUS_PROGRESS_CHAR_UUID, self._notification_handler)
            logger.info("Notifications enabled.")
            return self.is_connected()
        except Exception as e:
            logger.error(f"Failed to connect to {target_address}: {e}")
            return False

    async def disconnect(self):
        if self.is_connected():
            await self._client.disconnect()
        self._client = None

    def _notification_handler(self, sender, data: bytearray):
        """Puts incoming data into the async queue and logs it."""
        logger.debug(f"<-- NOTIFY from {sender}: {data.hex().upper()}")
        self._notification_queue.put_nowait(data)

    async def write(self, uuid: str, data: bytes, with_response: bool = True):
        """Writes data to a characteristic and logs it."""
        logger.debug(f"--> WRITE to {uuid}: {data.hex().upper()}")
        await self._client.write_gatt_char(uuid, data, response=with_response)

    async def wait_for_notification(self, timeout: float = 10.0) -> bytes:
        """Waits for and returns the next notification from the queue."""
        return await asyncio.wait_for(self._notification_queue.get(), timeout)