import hashlib
import logging
from typing import Dict
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn
from ble_client import BleClient
from utils import constants as const
from utils import packet_framer
from protos import local_ota_pb2

logger = logging.getLogger(__name__)


class OtaService:
    def __init__(self, client: BleClient, config: Dict, console):
        self.client = client
        self.config = config
        self.console = console

    async def run_update(self, firmware_path: str):
        logger.info("Starting OTA process...")
        firmware_data = self._load_firmware(firmware_path)
        if not firmware_data:
            return

        await self._request_and_validate_info()
        await self._send_start_ota(firmware_data)
        await self._transfer_data(firmware_data)
        await self._send_end_ota(firmware_data)
        logger.info("✅ OTA Update Completed Successfully!")

    def _load_firmware(self, path: str) -> bytes:
        logger.info(f"Loading firmware from '{path}'...")
        with open(path, "rb") as f:
            return f.read()

    async def _wait_for_response(self, expected_type: int):
        raw_data = await self.client.wait_for_notification()
        unpacked = packet_framer.unpack_response(raw_data)
        if not unpacked or unpacked[0] != expected_type:
            raise Exception(f"Received unexpected response. Got {unpacked}, expected type {expected_type}.")
        return unpacked[1]

    async def _request_and_validate_info(self):
        logger.info("Querying device info...")
        request_info = local_ota_pb2.OtaControl(request_info_payload=local_ota_pb2.OtaRequestInfo())
        packet = packet_framer.create_control_packet(request_info)
        await self.client.write(const.CONTROL_POINT_CHAR_UUID, packet)

        info_response = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_INFO_RESPONSE)
        logger.info(
            f"Device Info | FW: {info_response.current_fw_version}, "
            f"HW: {info_response.hw_version}, "
            f"Product: {info_response.product_id}, "
            f"Scheme: {info_response.supported_ota_scheme_version}"
        )

        update_type_enum = local_ota_pb2.UpdateType.Value(self.config['update_type'])
        if info_response.product_id != self.config['product_id'] or \
                info_response.hw_version != self.config['hw_version'] or \
                update_type_enum not in info_response.supported_update_types:
            raise Exception("Device is not compatible with this update.")
        logger.info("Device is compatible.")

    async def _send_start_ota(self, firmware_data: bytes):
        update_type = local_ota_pb2.UpdateType.Value(self.config['update_type'])
        start_payload = local_ota_pb2.OtaStart(
            update_type=update_type,
            image_size=len(firmware_data),
            fw_version=self.config['fw_version'],
            hw_version=self.config['hw_version'],
            product_id=self.config['product_id'],
            # ADD THIS LINE to send the scheme version from the config
            ota_scheme_version=self.config['ota_scheme_version']
        )
        control_msg = local_ota_pb2.OtaControl(start_payload=start_payload)
        packet = packet_framer.create_control_packet(control_msg)
        await self.client.write(const.CONTROL_POINT_CHAR_UUID, packet)

        ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK)
        if ack.status != local_ota_pb2.OK:
            raise Exception(f"Device rejected OTA start. Reason: {ack.message}")
        logger.info("OTA process started by peripheral.")

    async def _transfer_data(self, firmware_data: bytes):
        total_size = len(firmware_data)
        chunks = [firmware_data[i:i + const.CHUNK_SIZE] for i in range(0, total_size, const.CHUNK_SIZE)]

        with Progress(SpinnerColumn(), TextColumn("[cyan]{task.description}"), BarColumn(),
                      TextColumn("[green]{task.percentage:>3.0f}%"), TimeRemainingColumn(),
                      console=self.console) as progress:
            task = progress.add_task("Uploading Firmware...", total=total_size)

            for i, chunk in enumerate(chunks):
                chunk_num = i + 1
                data_payload = local_ota_pb2.OtaData(chunk_num=chunk_num, chunk=chunk)
                packet = packet_framer.create_data_packet(data_payload)
                await self.client.write(const.DATA_TRANSFER_CHAR_UUID, packet, with_response=False)

                ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK)
                if ack.status != local_ota_pb2.OK or ack.received_chunk_num != chunk_num:
                    raise Exception(f"Chunk transfer failed at {chunk_num}. Status: {ack.status}")
                progress.update(task, advance=len(chunk))

    async def _send_end_ota(self, firmware_data: bytes):
        logger.info("Finalizing update...")
        image_hash = hashlib.sha256(firmware_data).digest()
        end_payload = local_ota_pb2.OtaEnd(
            total_chunks=len(firmware_data) // const.CHUNK_SIZE + 1,
            image_hash=image_hash
        )
        control_msg = local_ota_pb2.OtaControl(end_payload=end_payload)
        packet = packet_framer.create_control_packet(control_msg)
        await self.client.write(const.CONTROL_POINT_CHAR_UUID, packet)

        ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK)
        if ack.status != local_ota_pb2.OK:
            raise Exception(f"Device rejected OtaEnd command. Reason: {ack.message}")

        logger.info("Peripheral is validating image... Awaiting final confirmation.")
        final_ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK)
        if final_ack.status != local_ota_pb2.OK:
            raise Exception(f"Device failed validation. Reason: {final_ack.message}")

        logger.info("Image validated and committed by peripheral.")