import asyncio
import hashlib
import logging
import os
from typing import Dict
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeRemainingColumn
from transports.base_transport import BaseTransport
from transports.file_transport import FileTransport  # Import to check instance type
from utils import constants as const
from utils import modern_protocol_framer as framer
from input import local_ota_pb2

logger = logging.getLogger(__name__)

MAX_CHUNK_RETRIES = 3
CHUNK_ACK_TIMEOUT = 5.0
CONTROL_MSG_TIMEOUT = 10.0


class OtaService:
    def __init__(self, transport: BaseTransport, config: Dict, console):
        self.transport = transport
        self.config = config
        self.console = console

    async def run_update(self, firmware_path: str):
        logger.info("Starting OTA process...")

        is_dry_run = isinstance(self.transport, FileTransport)

        if not is_dry_run:
            await self.transport.subscribe(const.OTA_STATUS_PROGRESS_CHAR_UUID)

        firmware_data = self._load_firmware(firmware_path)
        if not firmware_data:
            logger.error("Firmware file is missing or empty. Aborting.")
            return

        if not is_dry_run:
            await self._request_and_validate_info()

        await self._send_start_ota(firmware_data, is_dry_run)
        await self._transfer_data(firmware_data, is_dry_run)
        await self._send_end_ota(firmware_data, is_dry_run)

        logger.info("OTA Process Finished!")

    def _load_firmware(self, path: str) -> bytes:
        logger.info(f"Loading firmware from '{path}'...")
        if not os.path.exists(path):
            logger.error(f"Firmware file not found at path: {path}")
            return None
        with open(path, "rb") as f:
            return f.read()

    async def _wait_for_response(self, expected_type: int, timeout: float):
        raw_data = await self.transport.read(const.OTA_STATUS_PROGRESS_CHAR_UUID, timeout=timeout)
        unpacked = framer.unpack_response(raw_data)
        if not unpacked:
            raise Exception("Failed to unpack response from device.")

        msg_type, payload = unpacked
        if msg_type != expected_type:
            raise Exception(f"Received unexpected message type. Got {msg_type}, expected {expected_type}.")

        if expected_type == local_ota_pb2.MSG_TYPE_OTA_ACK:
            ack = local_ota_pb2.OtaAck()
            ack.ParseFromString(payload)
            return ack
        elif expected_type == local_ota_pb2.MSG_TYPE_OTA_INFO_RESPONSE:
            info = local_ota_pb2.OtaInfoResponse()
            info.ParseFromString(payload)
            return info
        return None

    async def _request_and_validate_info(self):
        logger.info("Querying device info...")
        request_info_payload = local_ota_pb2.OtaRequestInfo()
        control_msg = local_ota_pb2.OtaControl(request_info_payload=request_info_payload)
        packet = framer.create_packet(local_ota_pb2.MSG_TYPE_OTA_CONTROL, control_msg.SerializeToString())
        await self.transport.write(const.OTA_CONTROL_POINT_CHAR_UUID, packet)

        info_response = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_INFO_RESPONSE,
                                                      timeout=CONTROL_MSG_TIMEOUT)
        logger.info(
            f"Device Info | FW: {info_response.current_fw_version}, HW: {info_response.hw_version}, Product: {info_response.product_id}, Scheme: {info_response.supported_ota_scheme_version}")

        update_type_enum = local_ota_pb2.UpdateType.Value(self.config['update_type'])
        if info_response.product_id != self.config['product_id'] or \
                info_response.hw_version != self.config['hw_version'] or \
                update_type_enum not in info_response.supported_update_types:
            raise Exception("Device is not compatible with this update.")
        logger.info("Device is compatible.")

    async def _send_start_ota(self, firmware_data: bytes, is_dry_run: bool):
        logger.info("Sending OTA Start command...")
        update_type = local_ota_pb2.UpdateType.Value(self.config['update_type'])
        start_payload = local_ota_pb2.OtaStart(
            update_type=update_type, image_size=len(firmware_data), fw_version=self.config['fw_version'],
            hw_version=self.config['hw_version'], product_id=self.config['product_id'],
            ota_scheme_version=self.config['ota_scheme_version']
        )
        control_msg = local_ota_pb2.OtaControl(start_payload=start_payload)
        packet = framer.create_packet(local_ota_pb2.MSG_TYPE_OTA_CONTROL, control_msg.SerializeToString())
        await self.transport.write(const.OTA_CONTROL_POINT_CHAR_UUID, packet)

        if not is_dry_run:
            ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK, timeout=CONTROL_MSG_TIMEOUT)
            if ack.status != local_ota_pb2.OK:
                raise Exception(f"Device rejected OTA start. Reason: {ack.message}")
            logger.info("OTA process started by peripheral.")

    async def _transfer_data(self, firmware_data: bytes, is_dry_run: bool):
        total_size = len(firmware_data)
        chunks = [firmware_data[i:i + const.OTA_CHUNK_SIZE] for i in range(0, total_size, const.OTA_CHUNK_SIZE)]
        total_chunks = len(chunks)

        with Progress(SpinnerColumn(), TextColumn("[cyan]{task.description}"), BarColumn(),
                      TextColumn("[green]{task.percentage:>3.0f}%"),
                      TextColumn("[yellow]({task.fields[completed_chunks]}/{task.fields[total_chunks]} Chunks)"),
                      TimeRemainingColumn(), console=self.console) as progress:

            task = progress.add_task("Uploading Firmware...", total=total_size, completed_chunks=0,
                                     total_chunks=total_chunks)

            for i, chunk in enumerate(chunks):
                chunk_num = i + 1
                data_payload = local_ota_pb2.OtaData(chunk_num=chunk_num, chunk=chunk)
                packet = framer.create_packet(local_ota_pb2.MSG_TYPE_OTA_DATA, data_payload.SerializeToString())

                if is_dry_run:
                    await self.transport.write(const.OTA_DATA_TRANSFER_CHAR_UUID, packet, with_response=False)
                    await asyncio.sleep(0.001)  # Tiny sleep to make progress bar visible
                else:
                    success = False
                    for attempt in range(MAX_CHUNK_RETRIES):
                        try:
                            await self.transport.write(const.OTA_DATA_TRANSFER_CHAR_UUID, packet, with_response=False)
                            ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK,
                                                                timeout=CHUNK_ACK_TIMEOUT)
                            if ack.status == local_ota_pb2.OK and ack.received_chunk_num == chunk_num:
                                success = True
                                break
                        except asyncio.TimeoutError:
                            logger.warning(f"Attempt {attempt + 1}: Timed out on chunk #{chunk_num}. Retrying...")
                        if attempt < MAX_CHUNK_RETRIES - 1:
                            await asyncio.sleep(0.2)
                    if not success:
                        raise Exception(f"Failed to send chunk #{chunk_num} after {MAX_CHUNK_RETRIES} attempts.")

                progress.update(task, advance=len(chunk), completed_chunks=chunk_num)

    async def _send_end_ota(self, firmware_data: bytes, is_dry_run: bool):
        logger.info("Sending OTA End command...")
        image_hash = hashlib.sha256(firmware_data).digest()
        end_payload = local_ota_pb2.OtaEnd(total_chunks=len(firmware_data) // const.OTA_CHUNK_SIZE + 1,
                                           image_hash=image_hash)
        control_msg = local_ota_pb2.OtaControl(end_payload=end_payload)
        packet = framer.create_packet(local_ota_pb2.MSG_TYPE_OTA_CONTROL, control_msg.SerializeToString())
        await self.transport.write(const.OTA_CONTROL_POINT_CHAR_UUID, packet)

        if not is_dry_run:
            ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK, timeout=CONTROL_MSG_TIMEOUT)
            if ack.status != local_ota_pb2.OK:
                raise Exception(f"Device rejected OtaEnd command. Reason: {ack.message}")

            logger.info("Peripheral is validating image... Awaiting final confirmation.")
            final_ack = await self._wait_for_response(local_ota_pb2.MSG_TYPE_OTA_ACK, timeout=30.0)
            if final_ack.status != local_ota_pb2.OK:
                raise Exception(f"Device failed validation. Reason: {final_ack.message}")
            logger.info("Image validated and committed by peripheral.")
