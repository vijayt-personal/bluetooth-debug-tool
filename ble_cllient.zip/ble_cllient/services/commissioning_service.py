import logging
from rich.table import Table
from transports.base_transport import BaseTransport
from utils import constants as const
from utils import legacy_protocol_framer as framer
from input import local_commissioning_pb2

logger = logging.getLogger(__name__)

COMMISSIONING_MSG_TIMEOUT = 120.0


class CommissioningService:
    def __init__(self, transport: BaseTransport, console):
        self.transport = transport
        self.console = console

    async def _wait_for_response(self, expected_type: int, timeout: float):
        raw_data = await self.transport.read(const.COMMISSIONING_RESPONSE_CHAR_UUID, timeout=timeout)
        unpacked = framer.unpack_response(raw_data)
        if not unpacked:
            raise Exception("Failed to unpack response from device.")

        msg_type, payload = unpacked
        if msg_type != expected_type:
            raise Exception(f"Received unexpected message type. Got {msg_type}, expected {expected_type}.")

        # Parse payload based on expected type
        if expected_type == local_commissioning_pb2.MSG_TYPE_WIFI_SCAN:
            resp = local_commissioning_pb2.WifiScanningResponse()
            resp.ParseFromString(payload)
            return resp
        elif expected_type == local_commissioning_pb2.MSG_TYPE_WIFI_CONNECT:
            resp = local_commissioning_pb2.WifiConfigurationResponse()
            resp.ParseFromString(payload)
            return resp
        elif expected_type == local_commissioning_pb2.MSG_TYPE_COMMISSIONING_END:
            resp = local_commissioning_pb2.CommissioningEndResponse()
            resp.ParseFromString(payload)
            return resp
        return None

    async def wifi_scan(self):
        logger.info("Requesting Wi-Fi scan from device...")
        await self.transport.subscribe(const.COMMISSIONING_RESPONSE_CHAR_UUID)
        packet = framer.create_request(local_commissioning_pb2.MSG_TYPE_WIFI_SCAN, b'')
        await self.transport.write(const.COMMISSIONING_REQUEST_CHAR_UUID, packet)

        scan_response = await self._wait_for_response(local_commissioning_pb2.MSG_TYPE_WIFI_SCAN, timeout=20.0)

        if scan_response.resp != local_commissioning_pb2.SCANNING_STATUS_SUCCESS:
            logger.error(f"Wi-Fi scan failed with status: {scan_response.resp}")
            return

        table = Table(title=f"Found {scan_response.wifi_network_count} Wi-Fi Networks")
        table.add_column("SSID", style="cyan")
        table.add_column("RSSI", style="magenta")
        table.add_column("Auth Mode", style="yellow")

        for network in scan_response.wifi_list:
            auth_mode_str = local_commissioning_pb2.AuthMode.Name(network.auth_mode)
            table.add_row(network.ssid, str(network.rssi), auth_mode_str)

        self.console.print(table)

    async def wifi_connect(self, ssid: str, password: str):
        logger.info(f"Sending Wi-Fi credentials for SSID: {ssid}")
        await self.transport.subscribe(const.COMMISSIONING_RESPONSE_CHAR_UUID)
        request = local_commissioning_pb2.WifiConfigurationRequest(
            ssid=ssid,
            ssid_len=len(ssid),
            password=password,
            password_len=len(password)
        )
        packet = framer.create_request(local_commissioning_pb2.MSG_TYPE_WIFI_CONNECT, request.SerializeToString())
        await self.transport.write(const.COMMISSIONING_REQUEST_CHAR_UUID, packet)

        response = await self._wait_for_response(local_commissioning_pb2.MSG_TYPE_WIFI_CONNECT, timeout=COMMISSIONING_MSG_TIMEOUT)

        if response.resp_type == local_commissioning_pb2.WIFI_RESPONSE_TYPE_CONNECTION_SUCCESS:
            logger.info(f"Successfully connected to Wi-Fi network '{response.resp_ssid}'")
        else:
            logger.error(
                f"Failed to connect to Wi-Fi. Reason: {local_commissioning_pb2.WifiResponseType.Name(response.resp_type)}")

    async def end_commissioning(self, success: bool):
        req_type = local_commissioning_pb2.COMMISSIONING_END_REQUEST_TYPE_SUCCESS if success else local_commissioning_pb2.COMMISSIONING_END_REQUEST_TYPE_FAILURE
        logger.info(f"Ending commissioning with status: {local_commissioning_pb2.CommissioningEndRequestType.Name(req_type)}")
        await self.transport.subscribe(const.COMMISSIONING_RESPONSE_CHAR_UUID)

        request = local_commissioning_pb2.CommissioningEndRequest(request=req_type)
        packet = framer.create_request(local_commissioning_pb2.MSG_TYPE_COMMISSIONING_END, request.SerializeToString())
        await self.transport.write(const.COMMISSIONING_REQUEST_CHAR_UUID, packet)

        response = await self._wait_for_response(local_commissioning_pb2.MSG_TYPE_COMMISSIONING_END,
                                                 timeout=COMMISSIONING_MSG_TIMEOUT)
        if response.resp_type == local_commissioning_pb2.COMMISSIONING_END_RESPONSE_TYPE_ACK:
            logger.info("Commissioning ended successfully.")
        else:
            logger.error("Failed to end commissioning.")
