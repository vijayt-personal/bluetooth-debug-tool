import os
import sys
import json
import asyncio
import argparse
import logging
from rich.console import Console

# No build logic needed here, it's in generate_protos.py

from utils.logger import setup_logger
from services.ota_service import OtaService
from transports.ble_transport import BleTransport
from transports.file_transport import FileTransport

logger = logging.getLogger(__name__)


async def main(args):
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logger(log_level)
    console = Console()

    logger.info("Application starting...")
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
        logger.info(f"Loaded configuration from '{args.config_file}'.")
    except Exception as e:
        logger.error(f"Error loading config file: {e}")
        return

    # --- Transport Selection ---
    transport = None
    connect_kwargs = {}
    if args.transport == 'ble':
        transport = BleTransport()
        connect_kwargs = {
            "mac_address": config.get("ble_mac_address"),
            "device_name": config.get("device_name")
        }
    elif args.transport == 'file':
        if not args.output_file:
            logger.error("Error: Must specify --output-file for 'file' transport.")
            return
        transport = FileTransport()
        connect_kwargs = {"output_file": args.output_file}
    else:
        logger.error(f"Unsupported transport type: {args.transport}")
        return

    try:
        await transport.connect(**connect_kwargs)

        # For this single-task runner, we assume it's for OTA
        ota_service = OtaService(transport, config, console)
        await ota_service.run_update(args.firmware_file)

    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}", exc_info=(log_level == logging.DEBUG))
    finally:
        if transport and transport.is_connected:
            await transport.disconnect()
        logger.info("Application finished.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Multi-Transport OTA Client.")
    parser.add_argument("config_file", help="Path to the ota_config.json file.")
    parser.add_argument("firmware_file", help="Path to the firmware file (e.g., input/firmware.bin).")

    # New arguments for transport selection
    parser.add_argument(
        '--transport',
        type=str,
        choices=['ble', 'file'],
        default='ble',
        help="The transport layer to use (default: ble)."
    )
    parser.add_argument(
        '--output-file',
        type=str,
        help="Path to the output log file for the 'file' transport."
    )

    parser.add_argument('-v', '--verbose', action='store_true', help="Enable debug logging.")
    args = parser.parse_args()
    asyncio.run(main(args))
