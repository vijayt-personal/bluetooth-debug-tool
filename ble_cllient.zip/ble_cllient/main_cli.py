import os
import sys
import json
import asyncio
import argparse
import logging
import subprocess
from rich.console import Console

def setup_dependencies():
    """Compiles the .proto file if the output doesn't exist."""
    proto_file_path = os.path.join('protos', 'local_ota.proto')
    # The output will be inside the 'protos' package
    output_file_path = os.path.join('protos', 'local_ota_pb2.py')

    if not os.path.exists(output_file_path):
        print(f"Attempting to compile '{proto_file_path}'...")
        try:
            subprocess.run(
                [
                    sys.executable, '-m', 'grpc_tools.protoc',
                    '--proto_path=.',
                    '--python_out=.',
                    proto_file_path
                ],
                check=True
            )
            print("Protobuf file compiled successfully.")
        except Exception as e:
            print(f"Error compiling .proto file: {e}\nMake sure you have run 'pip install grpcio-tools'")
            sys.exit(1)

# Run the setup function at the start of the script
setup_dependencies()

from utils.logger import setup_logger
from ble_client import BleClient
from services.ota_service import OtaService

logger = logging.getLogger(__name__)

async def main(args):
    """Main function to run the CLI client."""
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logger(log_level)
    console = Console()

    logger.info("Application starting...")
    try:
        with open(args.config_file, 'r') as f:
            config = json.load(f)
        logger.info(f"Loaded configuration from '{args.config_file}'.")
    except Exception as e:
        logger.error(f"Error loading config file: {e}")
        return

    client = BleClient()
    try:
        connected = await client.scan_and_connect(
            mac_address=config.get("ble_mac_address"),
            device_name=config.get("device_name")
        )
        if not connected:
             logger.error("Failed to establish connection. Exiting.")
             return

        ota_service = OtaService(client, config, console)
        await ota_service.run_update(args.firmware_file)

    except Exception as e:
        logger.error(f"An unexpected error occurred during operation: {e}", exc_info=(log_level == logging.DEBUG))
    finally:
        if client.is_connected():
            logger.info("Disconnecting client...")
            await client.disconnect()
        logger.info("Application finished.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BLE Client for Device Updates.")
    parser.add_argument("config_file", help="Path to the ota_config.json file.")
    parser.add_argument("firmware_file", help="Path to the firmware.bin file.")
    parser.add_argument('-v', '--verbose', action='store_true', help="Enable debug logging with raw hex dumps")
    args = parser.parse_args()
    asyncio.run(main(args))