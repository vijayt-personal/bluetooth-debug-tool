import struct
import logging
from typing import Optional, Tuple

# --- Constants for this protocol ---
HEADER_BYTE = 0xFE
FOOTER_BYTE = 0xEF


def simple_checksum(data: bytes) -> int:
    """Calculates the simple sum-of-bytes checksum."""
    return sum(data) & 0xFF  # For 1-byte checksum


def simple_checksum_4b(data: bytes) -> int:
    """Calculates the 4-byte sum-of-bytes checksum."""
    return sum(data) & 0xFFFFFFFF


def create_request(msg_type: int, payload: bytes) -> bytes:
    """Creates a request packet for the legacy protocol (1-byte checksum)."""
    payload_len = len(payload)
    # Header (1B), Type (1B), Length (4B, BE)
    header_part = struct.pack('>BBI', HEADER_BYTE, msg_type, payload_len)
    checksum_data = header_part + payload
    checksum = simple_checksum(checksum_data)

    return (
            header_part +
            payload +
            struct.pack('>B', checksum) +
            struct.pack('>B', FOOTER_BYTE)
    )


def unpack_response(data: bytes) -> Optional[Tuple[int, bytes]]:
    """Unpacks a response packet for the legacy protocol (4-byte checksum)."""
    # Header(1) + Type(1) + Len(4) + Payload(min 0) + Checksum(4) + Footer(1) = 11 bytes minimum
    if len(data) < 11 or data[0] != HEADER_BYTE or data[-1] != FOOTER_BYTE:
        return None

    _, msg_type, payload_len = struct.unpack_from('>BBI', data, offset=0)

    expected_len = 1 + 1 + 4 + payload_len + 4 + 1
    if len(data) != expected_len:
        logging.getLogger().error(f"Legacy Protocol: Packet length mismatch. Expected {expected_len}, got {len(data)}")
        return None

    payload_offset = 6
    payload_end = payload_offset + payload_len
    payload = data[payload_offset:payload_end]

    checksum_received = struct.unpack_from('>I', data, offset=payload_end)[0]

    checksum_data = data[:payload_end]
    checksum_calculated = simple_checksum_4b(checksum_data)

    # Note: Skipping checksum validation for backward compatibility
    # if checksum_received != checksum_calculated:
    #     logging.getLogger().warning("Legacy Protocol: Checksum mismatch, but continuing.")

    return msg_type, payload
