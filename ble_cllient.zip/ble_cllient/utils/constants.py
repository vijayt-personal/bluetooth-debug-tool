# Service UUID
DEVICE_UPDATE_SERVICE_UUID = "B62D3557-3302-4F28-BB11-097EB986DE5C"

# Characteristic UUIDs (using the standard 128-bit format)
CONTROL_POINT_CHAR_UUID = "c1245527-fbe9-45ec-ab7b-10ff2b8f2111"
DATA_TRANSFER_CHAR_UUID = "c1245527-fbe9-45ec-ab7b-10ff2b8f2112"
STATUS_PROGRESS_CHAR_UUID = "c1245527-fbe9-45ec-ab7b-10ff2b8f2113"

# Packet Framing constants
START_BYTE = 0xFE
END_BYTE = 0xEF
HEADER_FORMAT = '<BH' # Type, Length
FRAME_OVERHEAD = 9 # Start(1) + Type(1) + Len(2) + CRC(4) + End(1)
CHUNK_SIZE = 224 # Max payload size for OtaData.chunk