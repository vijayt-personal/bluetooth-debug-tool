import struct
import zlib
import logging
from typing import Optional, Tuple
from . import constants as const
from protos import local_ota_pb2


def crc32_isohdlc(data: bytes) -> int:
    """Calculates the standard CRC-32/ISO-HDLC checksum."""
    crc = zlib.crc32(data)
    # The final XOR and mask are required to match the standard
    return crc


def create_control_packet(control_payload: local_ota_pb2.OtaControl) -> bytes:
    """Creates a complete OtaControl packet."""
    payload_bytes = control_payload.SerializeToString()
    return _frame_packet(local_ota_pb2.MSG_TYPE_OTA_CONTROL, payload_bytes)


def create_data_packet(data_payload: local_ota_pb2.OtaData) -> bytes:
    """Creates a complete OtaData packet."""
    payload_bytes = data_payload.SerializeToString()
    return _frame_packet(local_ota_pb2.MSG_TYPE_OTA_DATA, payload_bytes)


def _frame_packet(msg_type: int, payload: bytes) -> bytes:
    """Applies the framing (Header, CRC, Start/End bytes) to a payload."""
    payload_len = len(payload)
    header_part = struct.pack(const.HEADER_FORMAT, msg_type, payload_len)

    # Use the helper function for the correct CRC calculation
    crc = crc32_isohdlc(header_part + payload)

    return (
            struct.pack('<B', const.START_BYTE) +
            header_part +
            payload +
            struct.pack('<I', crc) +
            struct.pack('<B', const.END_BYTE)
    )


def unpack_response(data: bytes) -> Optional[Tuple[int, object]]:
    """Unpacks a framed response from the peripheral."""
    if len(data) < const.FRAME_OVERHEAD or data[0] != const.START_BYTE or data[-1] != const.END_BYTE:
        return None

    msg_type, payload_len = struct.unpack_from(const.HEADER_FORMAT, data, offset=1)

    if len(data) != payload_len + const.FRAME_OVERHEAD:
        logging.getLogger().error(
            f"Packet length mismatch. Expected {payload_len + const.FRAME_OVERHEAD}, got {len(data)}")
        return None

    payload_offset = 1 + struct.calcsize(const.HEADER_FORMAT)
    payload_end = payload_offset + payload_len
    payload = data[payload_offset:payload_end]
    crc_received = struct.unpack_from('<I', data, offset=payload_end)[0]

    header_part = data[1:payload_offset]
    # Use the helper function for verification
    crc_calculated = crc32_isohdlc(header_part + payload)

    if crc_received != crc_calculated:
        logging.getLogger().error(f"CRC Mismatch! Got {crc_received}, expected {crc_calculated}")
        return None

    pb_message = None
    if msg_type == local_ota_pb2.MSG_TYPE_OTA_ACK:
        pb_message = local_ota_pb2.OtaAck()
    elif msg_type == local_ota_pb2.MSG_TYPE_OTA_INFO_RESPONSE:
        pb_message = local_ota_pb2.OtaInfoResponse()
    else:
        logging.getLogger().error(f"Received unknown message type: {msg_type}")
        return None

    try:
        pb_message.ParseFromString(payload)
    except Exception as e:
        logging.getLogger().error(f"Failed to parse protobuf payload: {e}")
        return None

    return msg_type, pb_message
