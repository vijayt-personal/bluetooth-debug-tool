import struct
import zlib
import logging
from typing import Optional, Tuple
from . import constants as const
from input import local_ota_pb2

# --- Constants for this protocol ---
START_BYTE = 0xAA
END_BYTE = 0xDD
HEADER_FORMAT = '<BH'  # Type (1B), Length (2B, LE)
FRAME_OVERHEAD = 9  # Start(1) + Header(3) + CRC(4) + End(1)


def crc32_isohdlc(data: bytes) -> int:
    """Calculates the standard CRC-32/ISO-HDLC checksum."""
    return (zlib.crc32(data, 0xFFFFFFFF) ^ 0xFFFFFFFF) & 0xFFFFFFFF


def create_packet(msg_type: int, payload: bytes) -> bytes:
    """Applies framing to a payload for the modern protocol."""
    payload_len = len(payload)
    header_part = struct.pack(HEADER_FORMAT, msg_type, payload_len)
    crc = crc32_isohdlc(header_part + payload)
    return (
            struct.pack('<B', START_BYTE) +
            header_part +
            payload +
            struct.pack('<I', crc) +
            struct.pack('<B', END_BYTE)
    )


def unpack_response(data: bytes) -> Optional[Tuple[int, bytes]]:
    """Unpacks a framed response for the modern protocol."""
    if len(data) < FRAME_OVERHEAD or data[0] != START_BYTE or data[-1] != END_BYTE:
        return None

    msg_type, payload_len = struct.unpack_from(HEADER_FORMAT, data, offset=1)

    if len(data) != payload_len + FRAME_OVERHEAD:
        logging.getLogger().error(f"Modern Protocol: Packet length mismatch.")
        return None

    payload_offset = 1 + struct.calcsize(HEADER_FORMAT)
    payload_end = payload_offset + payload_len
    payload = data[payload_offset:payload_end]
    crc_received = struct.unpack_from('<I', data, offset=payload_end)[0]

    header_part = data[1:payload_offset]
    crc_calculated = crc32_isohdlc(header_part + payload)

    if crc_received != crc_calculated:
        logging.getLogger().error(f"Modern Protocol: CRC Mismatch!")
        return None

    return msg_type, payload
