# Local Communication Simulator

A versatile, command-line tool for interacting with connected devices over various communication protocols like Bluetooth Low Energy (BLE). The tool is built with a clean, modular architecture that separates the transport layer from application-level services (e.g., OTA updates, Wi-Fi Commissioning), making it highly extensible for future features.

It features two primary modes of operation:

1.  **Interactive Shell**: A user-friendly, command-driven interface for scanning, connecting, and interacting with devices in real-time.
2.  **Single-Task Runner**: A scriptable, single-shot command for executing automated tasks.

## Features

* **Interactive & Scriptable**: Use the interactive shell for manual control or the single-task script for automation.
* **Multi-Service Architecture**: Supports different device functionalities (like OTA and Commissioning) with their own unique communication protocols.
* **Modular Transport Layer**: Easily extendable to support other communication methods (e.g., Serial/UART).
* **Auto-Discovery (BLE)**: Scans for devices by name or by the services they advertise.
* **Dynamic Logging**: Switch between standard and verbose debug modes on-the-fly within the interactive shell.
* **Automatic Protobuf Compilation**: A dedicated script compiles all `.proto` files, simplifying setup.
* **Dry Run Mode**: Log all outgoing packets to a file for debugging without connecting to a real device.
* **Professional CLI**: The interactive shell features command history, auto-completion, and robust argument parsing.

## Project Structure

```
ble-client/
├── generate_protos.py        # Dedicated script to compile all .proto files
├── interactive_cli.py        # Main entry point for the interactive shell
├── main_cli.py               # Entry point for single-task execution
├── requirements.txt
|
├── configs/
│   └── ota_config.json
|
├── input/
│   ├── __init__.py           # Makes this a package for generated code
│   └── firmware.bin
|
├── protos/                   # Submodule
│   ├── local_commissioning.proto
│   └── local_ota.proto
|
├── services/
│   ├── commissioning_service.py
│   └── ota_service.py
|
└── utils/
│   ├── constants.py
│   ├── legacy_protocol_framer.py
│   ├── logger.py
│   └── modern_protocol_framer.py
```

## Setup & Installation

### Prerequisites

* Python 3.8+
* A functioning communication interface on your computer (e.g., a Bluetooth adapter for BLE).

### Installation Steps

1.  **Prepare Project Files**: Create the file structure as shown above, or clone the repository. If `protos` is a submodule, initialize it (`git submodule update --init`).

2.  **Install Dependencies**: Open your terminal in the project's root directory and run:
    ```bash
    pip install -r requirements.txt
    ```

3.  **Compile Protocol Files**: Run the dedicated build script. This only needs to be done once, or whenever you change a `.proto` file.
    ```bash
    python generate_protos.py
    ```

4.  **Prepare Assets**:
    * Place any necessary files (e.g., firmware images) in the `input/` directory.
    * Edit configuration files in the `configs/` directory to match your target device and desired operation.

## USAGE

### Interactive Mode (Recommended)

This mode provides a powerful shell for general-purpose device interaction.

**1. Start the Shell:**

```bash
python interactive_cli.py
```

**2. Available Commands:**

| Command | Arguments | Description |
| :--- | :--- | :--- |
| `scan` | | Scan for nearby BLE devices. |
| `list` | | List devices found in the last scan. |
| `connect` | `<index_or_address>` | Connect to a device by its scan index or MAC address. |
| `disconnect` | | Disconnect from the current device. |
| `services` | | List services and characteristics of the connected device. |
| `loglevel` | `<info\|debug>` | Set the logging verbosity on-the-fly. |
| `ota` | `<config> <firmware>` | Perform an OTA update on the connected device. |
| `wifi_scan` | | Scan for Wi-Fi networks via the device. |
| `wifi_connect`| `"<ssid with spaces>"`| Connect the device to a Wi-Fi network. **Use quotes for SSIDs with spaces.** |
| `commissioning_end`| `<success\|failure>`| End the commissioning process. |
| `help` | | Show this help message. |
| `exit` | | Exit the application. |

**3. Example Session:**

```
(Disconnected) > loglevel debug
Log level set to DEBUG.
(Disconnected) > scan
(Disconnected) > list
(Disconnected) > connect 0
(Connected) > services
(Connected) > wifi_scan
(Connected) > wifi_connect "My Home Network 5G"
Enter password for 'My Home Network 5G': ****
(Connected) > commissioning_end success
(Connected) > disconnect
(Disconnected) > exit
```

### Single-Task Mode (for Automation)

This mode is for running a single task, like a scripted OTA update.

**1. Run a Standard BLE Update:**

```bash
python main_cli.py configs/ota_config.json input/firmware.bin
```

**2. Verbose Mode:**
Add the `-v` or `--verbose` flag to any command to see detailed debug logs.

```bash
python main_cli.py -v configs/ota_config.json input/firmware.bin
