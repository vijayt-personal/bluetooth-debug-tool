import asyncio
import logging
import json
import os
import sys
import shlex  # <-- Import the shell-like parsing library
from typing import Optional, List
from getpass import getpass

from rich.console import Console
from rich.table import Table
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import FormattedText

# No special path modifications needed

from utils.logger import setup_logger
from services.ota_service import OtaService
from services.commissioning_service import CommissioningService
from transports.ble_transport import BleTransport
from bleak import BleakScanner

setup_logger(logging.INFO)
logger = logging.getLogger(__name__)
console = Console()


class InteractiveShell:
    """Manages the interactive command-line session."""

    def __init__(self):
        self.transport: Optional[BleTransport] = None
        self.discovered_devices: List[str] = []
        self.command_completer = WordCompleter([
            'scan', 'list', 'connect', 'disconnect', 'services', 'ota', 'help', 'exit',
            'wifi_scan', 'wifi_connect', 'commissioning_end', 'loglevel'
        ], ignore_case=True)

    async def run(self):
        session = PromptSession(
            history=FileHistory('.cli_history'),
            auto_suggest=AutoSuggestFromHistory()
        )
        console.print("[bold cyan]Local Communication Simulator[/bold cyan]")
        console.print("Type 'help' for a list of commands.")

        while True:
            try:
                if self.transport and self.transport.is_connected:
                    prompt_text = FormattedText([('bold green', 'Connected'), ('', ' > ')])
                else:
                    prompt_text = FormattedText([('bold red', 'Disconnected'), ('', ' > ')])

                user_input = await session.prompt_async(prompt_text, completer=self.command_completer)

                try:
                    parts = shlex.split(user_input)
                except ValueError:
                    console.print("[red]Parsing Error: Check for unclosed quotes.[/red]")
                    continue

                if not parts: continue

                command = parts[0].lower()
                args = parts[1:]

                if command == 'exit':
                    if self.transport and self.transport.is_connected:
                        await self.transport.disconnect()
                    break

                handler = getattr(self, f"handle_{command}", None)
                if handler:
                    await handler(args)
                else:
                    console.print(f"[red]Unknown command: {command}[/red]")

            except KeyboardInterrupt:
                console.print("\nKeyboardInterrupt. Type 'exit' to quit.")
                continue
            except EOFError:
                if self.transport and self.transport.is_connected:
                    await self.transport.disconnect()
                break
            except Exception as e:
                logger.error(f"An error occurred: {e}", exc_info=True)

    async def handle_help(self, args: List[str]):
        table = Table(title="Available Commands")
        table.add_column("Command", style="cyan")
        table.add_column("Arguments", style="magenta")
        table.add_column("Description")

        table.add_row("scan", "", "Scan for nearby BLE devices.")
        table.add_row("list", "", "List devices found in the last scan.")
        table.add_row("connect", "<index_or_address>", "Connect to a device by its scan index or MAC address.")
        table.add_row("disconnect", "", "Disconnect from the current device.")
        table.add_row("services", "", "List services and characteristics of the connected device.")
        table.add_row("loglevel", "<info|debug>", "Set the logging verbosity.")
        table.add_row("ota", "<config_path> <firmware_path>", "Perform an OTA update.")
        table.add_row("wifi_scan", "", "Scan for Wi-Fi networks via the device.")
        table.add_row("wifi_connect", '"<ssid with spaces>"',
                      "Connect the device to a Wi-Fi network. Use quotes for SSIDs with spaces.")
        table.add_row("commissioning_end", "<success|failure>", "End the commissioning process.")
        table.add_row("help", "", "Show this help message.")
        table.add_row("exit", "", "Exit the application.")
        console.print(table)

    async def handle_loglevel(self, args: List[str]):
        """Sets the application log level."""
        if not args or args[0].lower() not in ['info', 'debug']:
            console.print("[red]Usage: loglevel <info|debug>[/red]")
            return

        level_str = args[0].lower()
        if level_str == 'debug':
            level = logging.DEBUG
        else:
            level = logging.INFO

        root_logger = logging.getLogger()
        root_logger.setLevel(level)
        console.print(f"Log level set to [bold yellow]{level_str.upper()}[/bold yellow].")

    async def handle_scan(self, args: List[str]):
        self.discovered_devices = []
        with console.status("[bold blue]Scanning for devices...[/bold blue]"):
            devices = await BleakScanner.discover(timeout=5.0)
        if not devices:
            console.print("[yellow]No devices found.[/yellow]")
            return
        self.discovered_devices = list(devices)
        await self.handle_list(args)

    async def handle_list(self, args: List[str]):
        if not self.discovered_devices:
            console.print("[yellow]No devices in list. Run 'scan' first.[/yellow]")
            return
        table = Table(title="Discovered Devices (Last Scan)")
        table.add_column("Index", style="yellow")
        table.add_column("Address", style="cyan")
        table.add_column("Name")
        for i, device in enumerate(self.discovered_devices):
            table.add_row(str(i), device.address, device.name or "N/A")
        console.print(table)

    async def handle_connect(self, args: List[str]):
        if not args:
            console.print("[red]Usage: connect <index_or_address>[/red]")
            return
        if self.transport and self.transport.is_connected:
            console.print("[yellow]Already connected. Please disconnect first.[/yellow]")
            return
        target_input = args[0]
        target_device = None
        try:
            device_index = int(target_input)
            if 0 <= device_index < len(self.discovered_devices):
                target_device = self.discovered_devices[device_index]
            else:
                console.print(f"[red]Invalid index '{device_index}'. Run 'scan' or 'list'.[/red]")
                return
        except (ValueError, IndexError):
            target_device = target_input
        with console.status(
                f"[bold blue]Connecting to {getattr(target_device, 'address', target_device)}...[/bold blue]"):
            self.transport = BleTransport()
            try:
                await self.transport.connect(mac_address=getattr(target_device, 'address', target_device))
            except ConnectionError as e:
                console.print(f"[red]Connection failed: {e}[/red]")
                self.transport = None

    async def handle_disconnect(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[yellow]Not connected to any device.[/yellow]")
            return
        with console.status("[bold blue]Disconnecting...[/bold blue]"):
            await self.transport.disconnect()
        console.print("Disconnected.")
        self.transport = None

    async def handle_services(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[red]Not connected. Please connect to a device first.[/red]")
            return
        with console.status("[bold blue]Discovering services...[/bold blue]"):
            for service in self.transport._client.services:
                console.print(f"\n[bold cyan]Service {service.uuid}[/bold cyan]")
                table = Table()
                table.add_column("Characteristic UUID", style="cyan")
                table.add_column("Properties", style="magenta")
                for char in service.characteristics:
                    table.add_row(char.uuid, ', '.join(char.properties))
                console.print(table)

    async def handle_ota(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[red]Not connected. Please connect to a device first.[/red]")
            return
        if len(args) < 2:
            console.print("[red]Usage: ota <config_path> <firmware_path>[/red]")
            return
        config_path, firmware_path = args[0], args[1]
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except Exception as e:
            console.print(f"[red]Error loading config file: {e}[/red]")
            return
        ota_service = OtaService(self.transport, config, console)
        await ota_service.run_update(firmware_path)

    async def handle_wifi_scan(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[red]Not connected. Please connect to a device first.[/red]")
            return
        with console.status("[bold blue]Requesting Wi-Fi scan...[/bold blue]"):
            service = CommissioningService(self.transport, console)
            await service.wifi_scan()

    async def handle_wifi_connect(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[red]Not connected. Please connect to a device first.[/red]")
            return
        if not args:
            console.print('[red]Usage: wifi_connect "<ssid with spaces>"[/red]')
            return

        ssid = args[0]

        password = getpass(f"Enter password for '{ssid}': ")
        with console.status(f"[bold blue]Sending credentials for {ssid}...[/bold blue]"):
            service = CommissioningService(self.transport, console)
            await service.wifi_connect(ssid, password)

    async def handle_commissioning_end(self, args: List[str]):
        if not self.transport or not self.transport.is_connected:
            console.print("[red]Not connected. Please connect to a device first.[/red]")
            return
        if not args or args[0].lower() not in ['success', 'failure']:
            console.print("[red]Usage: commissioning_end <success|failure>[/red]")
            return
        success = args[0].lower() == 'success'
        with console.status("[bold blue]Ending commissioning...[/bold blue]"):
            service = CommissioningService(self.transport, console)
            await service.end_commissioning(success)


if __name__ == "__main__":
    shell = InteractiveShell()
    try:
        asyncio.run(shell.run())
    except Exception as e:
        logger.error(f"Application terminated with an error: {e}")
