import asyncio
import logging
from typing import Optional, Callable
from bleak import BleakClient, BleakScanner
from .base_transport import BaseTransport

logger = logging.getLogger(__name__)


class BleTransport(BaseTransport):
    """BLE transport layer implementation using Bleak."""

    def __init__(self):
        self._client: Optional[BleakClient] = None
        # A dictionary to hold a separate notification queue for each characteristic
        self._notification_queues: dict[str, asyncio.Queue] = {}

    @property
    def is_connected(self) -> bool:
        return self._client is not None and self._client.is_connected

    async def connect(self, mac_address: str = None, device_name: str = None, **kwargs):
        target_address = mac_address
        device = None

        if target_address:
            logger.info(f"Attempting to connect directly to MAC: {target_address}...")
        elif device_name:
            logger.info(f"Scanning for device with name '{device_name}'...")
            device = await BleakScanner.find_device_by_name(device_name, timeout=10.0)
        else:
            logger.info("Scanning for any BLE device...")
            devices = await BleakScanner.discover(timeout=5.0)
            if devices:
                device = devices[0]

        if device:
            target_address = device.address
            logger.info(f"Found device: {device.name} ({target_address})")

        if not target_address:
            raise ConnectionError("Could not find a target BLE device.")

        logger.info(f"Connecting to {target_address}...")
        try:
            self._client = BleakClient(target_address)
            await self._client.connect()
            logger.info(f"Connection successful. Negotiated MTU: {self._client.mtu_size} bytes")
        except Exception as e:
            raise ConnectionError(f"Failed to connect to {target_address}: {e}")

    async def disconnect(self):
        if self.is_connected:
            await self._client.disconnect()
        self._client = None

    def _get_notification_handler(self, char_uuid: str) -> Callable:
        """Creates a specific handler for a characteristic's notifications."""

        def handler(sender, data: bytearray):
            logger.debug(f"<-- BLE NOTIFY from {char_uuid}: {data.hex().upper()}")
            if char_uuid in self._notification_queues:
                self._notification_queues[char_uuid].put_nowait(data)

        return handler

    async def subscribe(self, char_uuid: str, callback=None):
        if char_uuid not in self._notification_queues:
            self._notification_queues[char_uuid] = asyncio.Queue()

        handler = callback if callback else self._get_notification_handler(char_uuid)
        await self._client.start_notify(char_uuid, handler)
        logger.info(f"Subscribed to notifications on {char_uuid}")

    async def write(self, char_uuid: str, data: bytes, with_response: bool = True):
        logger.debug(f"--> BLE WRITE to {char_uuid}: {data.hex().upper()}")
        await self._client.write_gatt_char(char_uuid, data, response=with_response)

    async def read(self, char_uuid: str, timeout: float) -> bytes:
        if char_uuid not in self._notification_queues:
            raise ValueError(f"Not subscribed to notifications on {char_uuid}. Please subscribe first.")
        return await asyncio.wait_for(self._notification_queues[char_uuid].get(), timeout)
