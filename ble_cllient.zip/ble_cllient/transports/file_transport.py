import logging
from .base_transport import BaseTransport

logger = logging.getLogger(__name__)

class FileTransport(BaseTransport):
    """A 'dry run' transport that writes all outgoing packets to a file."""
    def __init__(self):
        self._output_file = None
        self._is_open = False

    @property
    def is_connected(self) -> bool:
        return self._is_open

    async def connect(self, output_file: str, **kwargs):
        logger.info(f"Dry run mode enabled. Writing all packets to '{output_file}'")
        try:
            self._output_file = open(output_file, 'w')
            self._is_open = True
            self._output_file.write("# OTA Packet Log (Hexadecimal Format)\n")
        except Exception as e:
            raise ConnectionError(f"Failed to open output file: {e}")

    async def disconnect(self):
        if self._output_file:
            self._output_file.close()
        self._is_open = False
        logger.info(f"Dry run finished. Log file '{self._output_file.name}' closed.")

    async def write(self, char_uuid: str, data: bytes, with_response: bool = True):
        hex_data = data.hex().upper()
        self._output_file.write(f"WRITE to {char_uuid}: {hex_data}\n")
        logger.info(f"DRY RUN: Wrote {len(data)} bytes to log file.")
        # No actual write, so we can return immediately.

    async def read(self, char_uuid: str, timeout: float) -> bytes:
        # In a dry run, we don't receive ACKs. We simulate an immediate, successful ACK
        # by returning empty bytes. The service layer must handle this.
        logger.info("DRY RUN: Simulating successful ACK. No actual read occurred.")
        return b''

    async def subscribe(self, char_uuid: str, callback=None):
        # Subscription is not applicable in a dry run.
        logger.info(f"DRY RUN: Skipping subscription to {char_uuid}.")
        pass
