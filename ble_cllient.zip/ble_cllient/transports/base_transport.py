from abc import ABC, abstractmethod


class BaseTransport(ABC):
    """Abstract base class for all transport layers."""

    @abstractmethod
    async def connect(self, **kwargs):
        pass

    @abstractmethod
    async def disconnect(self):
        pass

    @abstractmethod
    async def write(self, char_uuid: str, data: bytes, with_response: bool = True):
        """Write data to a specific characteristic."""
        pass

    @abstractmethod
    async def read(self, char_uuid: str, timeout: float) -> bytes:
        """Read data from a specific characteristic's notification queue."""
        pass

    @abstractmethod
    async def subscribe(self, char_uuid: str, callback=None):
        """Subscribe to notifications from a characteristic."""
        pass

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        pass
