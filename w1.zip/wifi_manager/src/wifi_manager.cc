/**
 * @file WiFiManager.cpp
 * @brief Implementation of the WiFiManager class using the PIMPL idiom.
 * All ESP-IDF specific code is contained within this file.
 */

#include "wifi_manager.h"

// --- ESP-IDF Specific Headers ---
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_timer.h" // Added for esp_timer_get_time()
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <atomic>
#include <cstring>
#include <algorithm> // For std::min

// --- Logger Tag ---
static const char* TAG = "WiFiManager";

namespace platform {
// --- PIMPL Implementation Struct ---
struct WiFiManager::Impl {
public:
    /**
     * @brief Constructor for the implementation.
     */
    Impl() 
        : state_(WiFiState::kDeinitialized),
          is_scanning_(false),
          auto_reconnect_(false),
          reconnect_interval_ms_(kDefaultReconnectIntervalMs),
          last_reconnect_attempt_(0),
          scan_callback_(nullptr),
          connect_callback_(nullptr),
          disconnect_callback_(nullptr),
          event_handler_instance_(nullptr)
    {
        // Initialize credentials to empty.
        ssid_.fill(0);
        password_.fill(0);
        // Reserve memory for scan results once at creation to prevent reallocations.
        scan_results_.reserve(kMaxAPList);
    }

    /**
     * @brief Initializes the WiFi-specific components.
     * @note Assumes esp_netif_init() and esp_event_loop_create_default() have already been called.
     */
    void Init() {
        if (state_ != WiFiState::kDeinitialized) {
            ESP_LOGW(TAG, "WiFi already initialized.");
            return;
        }
        ESP_LOGI(TAG, "Initializing WiFi-specific components...");

        // Create the default Wi-Fi station interface.
        esp_netif_create_default_wifi_sta();

        // Initialize Wi-Fi with default config
        wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
        ESP_ERROR_CHECK(esp_wifi_init(&cfg));

        // Register event handlers
        ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                            ESP_EVENT_ANY_ID,
                                                            &WiFiManager::Impl::EventHandler,
                                                            this,
                                                            &event_handler_instance_));
        ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                            IP_EVENT_STA_GOT_IP,
                                                            &WiFiManager::Impl::EventHandler,
                                                            this,
                                                            &event_handler_instance_));
        
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
        ESP_ERROR_CHECK(esp_wifi_start());
    }

    /**
     * @brief Deinitializes the WiFi stack.
     * @note Does not de-initialize the event loop or netif stack, as other modules might use them.
     */
    void Deinit() {
        if (state_ == WiFiState::kDeinitialized) {
            ESP_LOGW(TAG, "WiFi already deinitialized.");
            return;
        }
        ESP_LOGI(TAG, "Deinitializing WiFi...");

        if (event_handler_instance_) {
            esp_event_handler_instance_unregister(WIFI_EVENT, ESP_EVENT_ANY_ID, event_handler_instance_);
            esp_event_handler_instance_unregister(IP_EVENT, IP_EVENT_STA_GOT_IP, event_handler_instance_);
        }
        
        esp_wifi_stop();
        esp_wifi_deinit();

        state_ = WiFiState::kDeinitialized;
        ESP_LOGI(TAG, "WiFi Deinitialized.");
    }
    
    /**
     * @brief Connects to the stored AP using a "scan-then-connect" approach for robust auth detection.
     */
    void Connect() {
        if (state_ == WiFiState::kConnecting || state_ == WiFiState::kConnected) {
            ESP_LOGW(TAG, "Already connecting or connected.");
            return;
        }

        if (strlen(ssid_.data()) == 0) {
            ESP_LOGE(TAG, "Cannot connect, SSID not set.");
            return;
        }
        
        wifi_auth_mode_t authmode = WIFI_AUTH_OPEN;
        if (!get_security_for_ssid(authmode)) {
            ESP_LOGE(TAG, "Could not find SSID '%s' during pre-connect scan. Aborting connection.", ssid_.data());
            return;
        }

        auto_reconnect_ = true;
        state_ = WiFiState::kConnecting;
        ESP_LOGI(TAG, "Connecting to SSID: '%s' (Auth mode: %d)", ssid_.data(), authmode);
        
        wifi_config_t wifi_config = {};
        strncpy(reinterpret_cast<char*>(wifi_config.sta.ssid), ssid_.data(), sizeof(wifi_config.sta.ssid));
        strncpy(reinterpret_cast<char*>(wifi_config.sta.password), password_.data(), sizeof(wifi_config.sta.password));
        
        wifi_config.sta.threshold.authmode = authmode;

        if (authmode >= WIFI_AUTH_WPA2_PSK) {
            wifi_config.sta.pmf_cfg.capable = true;
            wifi_config.sta.pmf_cfg.required = false;
        }

        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
        esp_err_t err = esp_wifi_connect();
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "esp_wifi_connect failed: %s", esp_err_to_name(err));
            state_ = WiFiState::kDisconnected;
        }
    }
    
    /**
     * @brief Disconnects from the current AP.
     */
    void Disconnect() {
        if (state_ != WiFiState::kConnected && state_ != WiFiState::kConnecting) {
            ESP_LOGW(TAG, "Not connected or connecting.");
            return;
        }
        auto_reconnect_ = false;
        ESP_LOGI(TAG, "Disconnecting from WiFi.");
        ESP_ERROR_CHECK(esp_wifi_disconnect());
    }

    /**
     * @brief Manually triggers a reconnect.
     */
    bool Reconnect(bool immediate) {
        auto_reconnect_ = true;
        ESP_LOGI(TAG, "Manual reconnect triggered. Immediate: %s", immediate ? "true" : "false");
        
        if (strlen(ssid_.data()) == 0) {
            ESP_LOGE(TAG, "Cannot reconnect, SSID not set.");
            return false;
        }

        if (state_ == WiFiState::kConnecting || state_ == WiFiState::kConnected) {
            ESP_LOGI(TAG, "Already connected or connecting. Will disconnect first to force reconnect.");
            esp_wifi_disconnect();
            return true;
        }
        
        if (immediate) {
            ESP_LOGI(TAG, "Attempting immediate reconnect...");
            Connect();
            last_reconnect_attempt_ = esp_timer_get_time();
            return true;
        }

        int64_t now = esp_timer_get_time();
        if (last_reconnect_attempt_ == 0 || (now - last_reconnect_attempt_) / 1000 > reconnect_interval_ms_) {
            ESP_LOGI(TAG, "Attempting to reconnect now (interval elapsed)...");
            Connect();
            last_reconnect_attempt_ = now;
            return true;
        } else {
            ESP_LOGW(TAG, "Reconnect attempt skipped, interval not elapsed.");
            return false;
        }
    }
    
    /**
     * @brief Loads credentials into member variables.
     */
    void LoadCredentials(const char* ssid, const char* password) {
        if (!ssid) return;
        
        strncpy(ssid_.data(), ssid, kMaxSSIDLength);
        ssid_[kMaxSSIDLength - 1] = '\0';

        if (password) {
            strncpy(password_.data(), password, kMaxPasswordLength);
            password_[kMaxPasswordLength - 1] = '\0';
        } else {
            password_.fill(0);
        }

        ESP_LOGI(TAG, "Credentials loaded for SSID: %s", ssid_.data());
    }
    
    /**
     * @brief Clears stored credentials.
     */
    void ClearCredentials() {
        ssid_.fill(0);
        password_.fill(0);
        ESP_LOGI(TAG, "Credentials cleared.");
    }
    
    /**
     * @brief Starts a WiFi scan. Relies on the event handler to process results.
     */
    void StartScan(bool blocking) {
        if (is_scanning_.load()) {
            ESP_LOGW(TAG, "Scan already in progress.");
            return;
        }
        
        is_scanning_ = true;
        
        ESP_LOGI(TAG, "Starting WiFi scan...");
        wifi_scan_config_t scan_config = {};
        scan_config.show_hidden = true;
        
        esp_err_t err = esp_wifi_scan_start(&scan_config, blocking);
        if (err != ESP_OK) {
             ESP_LOGE(TAG, "Scan start failed: %s", esp_err_to_name(err));
             // If scan fails to start, immediately revert the scanning flag.
             is_scanning_ = false;
        }
    }

    /**
     * @brief Stops an ongoing WiFi scan.
     */
    void StopScan() {
        if (!is_scanning_.load()) {
            ESP_LOGW(TAG, "No scan in progress to stop.");
            return;
        }
        ESP_LOGI(TAG, "Stopping WiFi scan.");
        esp_err_t err = esp_wifi_scan_stop();
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Scan stop failed: %s", esp_err_to_name(err));
        }
        // The SCAN_DONE event will still fire, which will set is_scanning_ to false.
    }


private:
    /**
     * @brief Performs a self-contained, blocking scan to find a specific SSID's security type.
     * This function does NOT rely on the main event handler to process its results.
     */
    bool get_security_for_ssid(wifi_auth_mode_t& authmode) {
        ESP_LOGI(TAG, "Performing targeted scan for SSID: %s", ssid_.data());
        
        wifi_scan_config_t scan_config = {};
        scan_config.ssid = reinterpret_cast<uint8_t*>(ssid_.data());
        scan_config.channel = 0;
        scan_config.show_hidden = true;
        scan_config.scan_type = WIFI_SCAN_TYPE_ACTIVE;

        // This call blocks until the scan is done.
        esp_err_t err = esp_wifi_scan_start(&scan_config, true);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Targeted scan failed to start: %s", esp_err_to_name(err));
            return false;
        }
        
        uint16_t ap_count = 0;
        esp_wifi_scan_get_ap_num(&ap_count);
        if (ap_count == 0) {
            ESP_LOGW(TAG, "Targeted scan found no results for SSID: %s", ssid_.data());
            return false;
        }

        // We only need one record, and we process it right here.
        wifi_ap_record_t ap_record;
        uint16_t max_records = 1;
        ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&max_records, &ap_record));
        
        authmode = ap_record.authmode;
        return true;
    }


    /**
     * @brief Processes scan results for a general scan. This is the single source of truth for public scans.
     */
    void ProcessGeneralScanDone() {
        uint16_t ap_count = 0;
        ESP_ERROR_CHECK(esp_wifi_scan_get_ap_num(&ap_count));

        scan_results_.clear(); // Clear previous results before filling
        if (ap_count > 0) {
            std::vector<wifi_ap_record_t> ap_records(ap_count);
            ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&ap_count, ap_records.data()));
            
            for (uint16_t i = 0; i < ap_count && i < kMaxAPList; ++i) {
                APInfo ap_info;
                strncpy(ap_info.ssid.data(), reinterpret_cast<const char*>(ap_records[i].ssid), kMaxSSIDLength);
                ap_info.ssid[kMaxSSIDLength - 1] = '\0';
                ap_info.rssi = ap_records[i].rssi;
                ap_info.security = MapSecurityType(ap_records[i].authmode);
                scan_results_.push_back(ap_info);
            }
            ESP_LOGI(TAG, "General scan done, %u APs found.", scan_results_.size());
        } else {
             ESP_LOGI(TAG, "General scan done, no APs found.");
        }

        if (scan_callback_) {
            scan_callback_(scan_results_);
        }
    }

    /**
     * @brief Maps an ESP-IDF authentication mode to our SecurityType enum.
     */
    SecurityType MapSecurityType(wifi_auth_mode_t auth_mode) {
        switch (auth_mode) {
            case WIFI_AUTH_OPEN:            return SecurityType::kOpen;
            case WIFI_AUTH_WEP:             return SecurityType::kWep;
            case WIFI_AUTH_WPA_PSK:         return SecurityType::kWpa;
            case WIFI_AUTH_WPA2_PSK:        return SecurityType::kWpa2;
            case WIFI_AUTH_WPA_WPA2_PSK:    return SecurityType::kWpa2;
            case WIFI_AUTH_WPA2_ENTERPRISE: return SecurityType::kWpa2Enterprise;
            case WIFI_AUTH_WPA3_PSK:        return SecurityType::kWpa3;
            case WIFI_AUTH_WPA2_WPA3_PSK:   return SecurityType::kWpa3;
            default:                        return SecurityType::kUnknown;
        }
    }
    
    /**
     * @brief Static event handler that forwards events to the instance's handler.
     */
    static void EventHandler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data) {
        WiFiManager::Impl* self = static_cast<WiFiManager::Impl*>(arg);
        self->InstanceEventHandler(event_base, event_id, event_data);
    }
    
    /**
     * @brief Instance-specific event handler logic.
     */
    void InstanceEventHandler(esp_event_base_t event_base, int32_t event_id, void* event_data) {
        if (event_base == WIFI_EVENT) {
            switch(event_id) {
                case WIFI_EVENT_STA_START:
                    ESP_LOGI(TAG, "WIFI_EVENT_STA_START: WiFi station started.");
                    state_ = WiFiState::kDisconnected;
                    break;
                case WIFI_EVENT_STA_CONNECTED:
                    ESP_LOGI(TAG, "WIFI_EVENT_STA_CONNECTED: Authenticated with AP.");
                    state_ = WiFiState::kConnected;
                    last_reconnect_attempt_ = 0;
                    break;
                case WIFI_EVENT_STA_DISCONNECTED:
                    ESP_LOGW(TAG, "WIFI_EVENT_STA_DISCONNECTED: Lost connection to AP.");
                    state_ = WiFiState::kDisconnected;
                    if (disconnect_callback_) {
                        disconnect_callback_();
                    }
                    if (auto_reconnect_) {
                        int64_t now = esp_timer_get_time();
                        if (last_reconnect_attempt_ == 0 || (now - last_reconnect_attempt_) / 1000 > reconnect_interval_ms_) {
                             ESP_LOGI(TAG, "Auto-reconnect enabled. Attempting to reconnect...");
                             esp_wifi_connect();
                             last_reconnect_attempt_ = now;
                        } else {
                             ESP_LOGI(TAG, "Auto-reconnect: Waiting for interval before retrying.");
                        }
                    } else {
                        ESP_LOGI(TAG, "Auto-reconnect disabled. Will not attempt to reconnect.");
                    }
                    break;
                case WIFI_EVENT_SCAN_DONE:
                    ESP_LOGD(TAG, "WIFI_EVENT_SCAN_DONE received.");
                    // This event fires for ALL scans. We only process results for public scans,
                    // which are identified by the is_scanning_ flag.
                    if (is_scanning_.load()) {
                        is_scanning_ = false; // The scan is now complete.
                        ProcessGeneralScanDone();
                    }
                    break;
                default:
                    break;
            }
        } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
            ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
            ESP_LOGI(TAG, "Got IP address: " IPSTR, IP2STR(&event->ip_info.ip));
            // This confirms connection is fully usable.
            state_ = WiFiState::kConnected;
            if (connect_callback_) {
                connect_callback_();
            }
        }
    }

// --- Member Variables ---
public:
    std::atomic<WiFiState> state_;
    std::atomic<bool> is_scanning_;
    std::array<char, kMaxSSIDLength> ssid_;
    std::array<char, kMaxPasswordLength> password_;
    std::vector<APInfo> scan_results_;
    std::atomic<bool> auto_reconnect_;
    int reconnect_interval_ms_;
    int64_t last_reconnect_attempt_;
    ScanCallback scan_callback_;
    ConnectCallback connect_callback_;
    DisconnectCallback disconnect_callback_;
    esp_event_handler_instance_t event_handler_instance_;
};


// --- WiFiManager Public Methods (delegating to PIMPL) ---

WiFiManager::WiFiManager() : pimpl_(std::make_unique<Impl>()) {}

WiFiManager::~WiFiManager() = default;

void WiFiManager::Init() {
    pimpl_->Init();
}

void WiFiManager::Deinit() {
    pimpl_->Deinit();
}

void WiFiManager::Connect() {
    pimpl_->Connect();
}

void WiFiManager::Disconnect() {
    pimpl_->Disconnect();
}

bool WiFiManager::Reconnect(bool immediate) {
    return pimpl_->Reconnect(immediate);
}

void WiFiManager::SetReconnectInterval(int interval_ms) {
    pimpl_->reconnect_interval_ms_ = interval_ms;
}

void WiFiManager::LoadCredentials(const char* ssid, const char* password) {
    pimpl_->LoadCredentials(ssid, password);
}

void WiFiManager::ClearCredentials() {
    pimpl_->ClearCredentials();
}

void WiFiManager::GetCredentials(std::array<char, kMaxSSIDLength>& ssid_out,
                               std::array<char, kMaxPasswordLength>& password_out) const {
    ssid_out = pimpl_->ssid_;
    password_out = pimpl_->password_;
}

void WiFiManager::StartScan(bool blocking) {
    pimpl_->StartScan(blocking);
}

void WiFiManager::StopScan() {
    pimpl_->StopScan();
}

std::vector<WiFiManager::APInfo> WiFiManager::GetScanResults() {
    return pimpl_->scan_results_;
}

void WiFiManager::SetScanCallback(ScanCallback callback) {
    pimpl_->scan_callback_ = callback;
}

void WiFiManager::SetConnectCallback(ConnectCallback callback) {
    pimpl_->connect_callback_ = callback;
}

void WiFiManager::SetDisconnectCallback(DisconnectCallback callback) {
    pimpl_->disconnect_callback_ = callback;
}

WiFiManager::WiFiState WiFiManager::GetWiFiState() const {
    if (pimpl_->is_scanning_.load()) {
        return WiFiState::kScanning;
    }
    return pimpl_->state_.load();
}

}