/**
 * @file WiFiManager.h
 * @brief WiFi Manager class for handling Wi-Fi connections, scanning, and credential management.
 * This header is completely decoupled from ESP-IDF implementation details using the PIMPL idiom.
 */

#pragma once

#include <array>
#include <vector>
#include <memory> // For std::unique_ptr

namespace platform {

/**
 * @class WiFiManager
 * @brief Manages Wi-Fi connectivity, scanning, and credential storage using the PIMPL idiom.
 */
class WiFiManager {
public:
    // --- Public Constants ---
    static constexpr size_t kMaxSSIDLength = 32;     ///< Maximum SSID length.
    static constexpr size_t kMaxPasswordLength = 64; ///< Maximum Wi-Fi password length.
    static constexpr size_t kMaxAPList = 25;         ///< Maximum number of APs stored in scan results.
    static constexpr int kDefaultReconnectIntervalMs = 10000; ///< Default reconnection interval in milliseconds.

    // --- Public Enums and Typedefs ---

    /**
     * @enum SecurityType
     * @brief Enumeration of Wi-Fi security types.
     */
    enum class SecurityType {
        kOpen,
        kWep,
        kWpa,
        kWpa2,
        kWpa3,
        kWpa2Enterprise,
        kWpa3Enterprise,
        kUnknown
    };

    /**
     * @enum WiFiState
     * @brief Enumeration of Wi-Fi connection states.
     */
    enum class WiFiState {
        kDeinitialized,
        kDisconnected,
        kConnecting,
        kConnected,
        kScanning
    };

    /**
     * @struct APInfo
     * @brief Structure to store information about an access point.
     */
    struct APInfo {
        std::array<char, kMaxSSIDLength> ssid{}; ///< SSID of the access point.
        int rssi;                                ///< Signal strength (RSSI).
        SecurityType security;                   ///< Security type.

        /**
         * @brief Equality operator to compare APInfo objects.
         * @param other Another APInfo object.
         * @return True if the SSIDs match, false otherwise.
         */
        bool operator==(const APInfo& other) const {
            return ssid == other.ssid;
        }
    };

    // --- Callback Definitions ---
    using ScanCallback = void (*)(const std::vector<APInfo>&);
    using ConnectCallback = void (*)();
    using DisconnectCallback = void (*)();


    // --- Public Methods ---

    /**
     * @brief Constructor for WiFiManager.
     */
    WiFiManager();

    /**
     * @brief Destructor for WiFiManager.
     */
    ~WiFiManager();

    // --- Deleted copy and move semantics to prevent accidental copying ---
    WiFiManager(const WiFiManager&) = delete;
    WiFiManager& operator=(const WiFiManager&) = delete;
    WiFiManager(WiFiManager&&) = delete;
    WiFiManager& operator=(WiFiManager&&) = delete;

    /**
     * @brief Initializes the Wi-Fi manager.
     */
    void Init();

    /**
     * @brief Deinitializes the Wi-Fi manager.
     */
    void Deinit();

    /**
     * @brief Connects to the configured Wi-Fi network.
     * Enables the auto-reconnect feature internally.
     */
    void Connect();

    /**
     * @brief Disconnects from the current Wi-Fi network.
     * Disables the auto-reconnect feature internally.
     */
    void Disconnect();

    /**
     * @brief Manually triggers a reconnection attempt.
     * Also enables the auto-reconnect feature for subsequent disconnects.
     * @param immediate If true, attempts to reconnect immediately, bypassing the interval timer. Defaults to false.
     * @return True if a reconnect was initiated, false otherwise (e.g., if called too soon with immediate=false).
     */
    bool Reconnect(bool immediate = false);

    /**
     * @brief Sets the interval between automatic reconnection attempts.
     * @param interval_ms The time in milliseconds to wait before retrying.
     */
    void SetReconnectInterval(int interval_ms);

    /**
     * @brief Loads Wi-Fi credentials (SSID & password).
     * @param ssid The Wi-Fi SSID.
     * @param password The Wi-Fi password.
     */
    void LoadCredentials(const char* ssid, const char* password);

    /**
     * @brief Clears stored Wi-Fi credentials.
     */
    void ClearCredentials();

    /**
     * @brief Retrieves the currently stored Wi-Fi credentials.
     * @param ssid_out Output parameter for SSID.
     * @param password_out Output parameter for password.
     */
    void GetCredentials(std::array<char, kMaxSSIDLength>& ssid_out,
                        std::array<char, kMaxPasswordLength>& password_out) const;

    /**
     * @brief Starts a Wi-Fi scan.
     * @param blocking If true, waits for the scan to complete before returning.
     */
    void StartScan(bool blocking);

    /**
     * @brief Stops an ongoing Wi-Fi scan.
     */
    void StopScan();

    /**
     * @brief Gets the most recent scan results.
     * @return A vector of APInfo structures containing scan results.
     */
    std::vector<APInfo> GetScanResults();

    /**
     * @brief Sets a callback function to be called when a scan completes.
     * @param callback The callback function.
     */
    void SetScanCallback(ScanCallback callback);

    /**
     * @brief Sets a callback function to be called on successful Wi-Fi connection (IP received).
     * @param callback The callback function.
     */
    void SetConnectCallback(ConnectCallback callback);

    /**
     * @brief Sets a callback function to be called on Wi-Fi disconnection.
     * @param callback The callback function.
     */
    void SetDisconnectCallback(DisconnectCallback callback);

    /**
     * @brief Gets the current Wi-Fi state.
     * @return The current state of the Wi-Fi connection.
     */
    WiFiState GetWiFiState() const;

private:
    // Forward declaration of the implementation class (PIMPL).
    struct Impl; 
    
    // The pointer to the implementation.
    std::unique_ptr<Impl> pimpl_;
};

}
