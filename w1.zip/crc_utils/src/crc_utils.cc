#include "crc_utils.h"

// This header provides access to the hardware-optimized CRC functions that are
// part of the ESP32's read-only memory (ROM).
#include "rom/crc.h"

namespace CrcUtils {

uint16_t Crc16Be(const uint8_t* data, size_t length) {
  // Delegate the calculation to the ESP-IDF ROM function for CRC-16
  // Big-Endian. The initial CRC value (0xFFFF) is handled by the ROM function.
  // The ROM function crc16_be does not require a final XOR.
  return crc16_be(0xFFFF, data, length);
}

uint16_t Crc16Le(const uint8_t* data, size_t length) {
  // Delegate the calculation to the ESP-IDF ROM function for CRC-16
  // Little-Endian (used for Modbus). The initial CRC value (0xFFFF) is handled
  // by the ROM function. The ROM function crc16_le does not require a final XOR.
  return crc16_le(0xFFFF, data, length);
}

uint32_t Crc32Be(const uint8_t* data, size_t length) {
  // Delegate the calculation to the ESP-IDF ROM function for CRC-32
  // Big-Endian. The initial CRC value is passed as the first argument. The
  // result is then XORed as per the standard CRC-32 algorithm specification.
  uint32_t crc = crc32_be(0xFFFFFFFF, data, length);
  return crc ^ 0xFFFFFFFF;
}

uint32_t Crc32Le(const uint8_t* data, size_t length) {
  // Delegate the calculation to the ESP-IDF ROM function for CRC-32
  // Little-Endian. This is the most common CRC-32 variant. The initial CRC
  // value is passed as the first argument. The result is then XORed as per the
  // standard CRC-32 algorithm specification.
  uint32_t crc = crc32_le(0xFFFFFFFF, data, length);
  return crc ^ 0xFFFFFFFF;
}

}  // namespace CrcUtils
