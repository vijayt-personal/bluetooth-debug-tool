#ifndef COMPONENTS_CRC_UTILS_INCLUDE_CRC_HPP_
#define COMPONENTS_CRC_UTILS_INCLUDE_CRC_HPP_

#include <cstddef>
#include <cstdint>

/**
 * @file
 * @brief Provides hardware-accelerated CRC-16 and CRC-32 calculation utilities.
 *
 * This header defines a set of functions for calculating common CRC checksums.
 * The underlying implementation uses the ESP32's hardware ROM functions for
 * optimal performance. The header itself is platform-agnostic.
 */

namespace CrcUtils {

/**
 * @brief Calculates CRC-16/MODBUS (Big-Endian).
 *
 * This function computes the CRC-16 checksum using the big-endian (BE) model,
 * commonly known as CRC-16/MODBUS.
 *
 * Parameters:
 * - Polynomial: 0x8005
 * - Initial Value: 0xFFFF
 * - Final XOR: None
 * - Reflection: None
 *
 * @param[in] data Pointer to the input data buffer.
 * @param[in] length The number of bytes in the data buffer.
 * @return The 16-bit CRC checksum.
 */
uint16_t Crc16Be(const uint8_t* data, size_t length);

/**
 * @brief Calculates CRC-16/ARC (Little-Endian).
 *
 * This function computes the CRC-16 checksum using the little-endian (LE)
 * model. This is a widely used standard, also known as CRC-16/LHA or
 * CRC-16/ARC.
 *
 * Parameters:
 * - Polynomial: 0x8005 (Reflected: 0xA001)
 * - Initial Value: 0xFFFF
 * - Final XOR: None
 * - Reflection: Input and Output
 *
 * @param[in] data Pointer to the input data buffer.
 * @param[in] length The number of bytes in the data buffer.
 * @return The 16-bit CRC checksum.
 */
uint16_t Crc16Le(const uint8_t* data, size_t length);

/**
 * @brief Calculates CRC-32/ISO-HDLC (Big-Endian).
 *
 * This function computes the standard CRC-32 checksum using the big-endian (BE)
 * model, also known as CRC-32/ADCCP.
 *
 * Parameters:
 * - Polynomial: 0x04C11DB7
 * - Initial Value: 0xFFFFFFFF
 * - Final XOR: 0xFFFFFFFF
 * - Reflection: None
 *
 * @param[in] data Pointer to the input data buffer.
 * @param[in] length The number of bytes in the data buffer.
 * @return The 32-bit CRC checksum.
 */
uint32_t Crc32Be(const uint8_t* data, size_t length);

/**
 * @brief Calculates CRC-32 (Little-Endian).
 *
 * This function computes the most common CRC-32 checksum using the
 * little-endian (LE) model. It is the standard used in Ethernet, PNG, Gzip,
 * and many other protocols.
 *
 * Parameters:
 * - Polynomial: 0x04C11DB7 (Reflected: 0xEDB88320)
 * - Initial Value: 0xFFFFFFFF
 * - Final XOR: 0xFFFFFFFF
 * - Reflection: Input and Output
 *
 * @param[in] data Pointer to the input data buffer.
 * @param[in] length The number of bytes in the data buffer.
 * @return The 32-bit CRC checksum.
 */
uint32_t Crc32Le(const uint8_t* data, size_t length);

}  // namespace CrcUtils

#endif  // COMPONENTS_CRC_UTILS_INCLUDE_CRC_HPP_
