/**
 * @file NetworkManager.cpp
 * @brief Implementation of the NetworkManager static class.
 */
#include "network_manager.h"
#include "esp_netif.h"
#include "esp_log.h"
        
static const char* TAG = "NetworkManager";

namespace platform {
        
void NetworkManager::Init() {
    ESP_LOGI(TAG, "Initializing core network stack...");
    ESP_ERROR_CHECK(esp_netif_init());
}

void NetworkManager::Deinit() {
}

}
