/**
 * @file NetworkManager.h
 * @brief A static class to abstract the initialization of the core network stack.
 *
 * The TCP/IP stack initialization.
 */
#ifndef PLATFORM_NETWORK_MANAGER_H_
#define PLATFORM_NETWORK_MANAGER_H_

namespace platform {

class NetworkManager {
public:
    /**
     * @brief Initializes the underlying TCP/IP adapter.
     * Must be called once at application startup before any other network operations.
     */
    static void Init();

    /**
     * @brief De-initialize TCP/IP adapter.
     */
    static void Deinit();

private:
    // Make constructor private to enforce static-only usage
    NetworkManager() = default; 
};

}

#endif // PLATFORM_NETWORK_MANAGER_H_
