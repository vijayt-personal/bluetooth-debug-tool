#include "ExampleProtoService.h"
#include <iostream>

namespace app {

using platform::connectivity::BLEManager;

ExampleProtoService::ExampleProtoService() 
    : service_uuid_(EXAMPLE_SERVICE_UUID) {
    std::cout << "ExampleProtoService: Constructed." << std::endl;
}

void ExampleProtoService::Init(const ActivityCallback& on_activity) {
    std::cout << "ExampleProtoService: Init() called. Registering service..." << std::endl;
    
    // 1. Store the callback function provided by BleComm.
    on_activity_callback_ = on_activity;

    // 2. Define the characteristics for this service.
    std::vector<BLEManager::CharacteristicData> characteristics = {
        {
            CHAR_PROTO_IN_UUID,
            static_cast<uint32_t>(BLEManager::CharProperty::WRITE),
            // This lambda is the BLE characteristic's callback.
            [this](const void* data, size_t size) {
                // It calls our internal handler.
                if (this->HandleData(data, size)) {
                    // If our handler confirms the data was valid...
                    std::cout << "ExampleProtoService: Valid data handled. Notifying manager of activity." << std::endl;
                    // ...we call the stored function to reset the inactivity timer.
                    this->on_activity_callback_();
                }
            }
        },
        {
            CHAR_PROTO_OUT_UUID,
            BLEManager::CharProperty::READ | BLEManager::CharProperty::NOTIFY,
            nullptr 
        }
    };

    // 3. Register the service and its characteristics with the BLE Manager.
    BLEManager::AddServiceUUID(service_uuid_.c_str());
    BLEManager::RegisterService(service_uuid_, characteristics);
}

void ExampleProtoService::OnConnect() {
    std::cout << "ExampleProtoService: OnConnect handler called. Sending welcome message." << std::endl;
    SendProtoOutput({'W','E','L','C','O','M','E'});
}

void ExampleProtoService::OnDisconnect() {
    std::cout << "ExampleProtoService: OnDisconnect handler called. (No action needed)" << std::endl;
    // This is a "dummy" implementation. It must exist, but it can be empty.
}

// --- Private Methods ---

bool ExampleProtoService::HandleData(const void* data, size_t size) {
    if (size > 0) {
        // Business logic for processing the protobuf message would go here.
        // For this example, any non-empty packet is considered valid.
        SendProtoOutput({'A','C','K'});
        return true; // Return true to indicate the packet was valid.
    }
    // Packet was empty or malformed.
    return false;
}

void ExampleProtoService::SendProtoOutput(const std::vector<uint8_t>& payload) {
    BLEManager::SetCharacteristicValue(CHAR_PROTO_OUT_UUID, payload.data(), payload.size(), true);
}

} // namespace app
