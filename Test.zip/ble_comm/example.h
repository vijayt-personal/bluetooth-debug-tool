#ifndef EXAMPLE_PROTO_SERVICE_H
#define EXAMPLE_PROTO_SERVICE_H

#include "ble_manager.h" // Note: This will be the non-static version
#include <string>
#include <vector>
#include <cstdint>
#include <functional>

namespace app {

// Forward declare to avoid circular dependencies if services need each other.
class ProvisioningManager; 
using platform::connectivity::BLEManager;

/**
 * @brief An example BLE service that receives its dependencies via its constructor.
 */
class ExampleProtoService {
public:
    using ActivityCallback = std::function<void()>;

    /**
     * @brief Constructs the service.
     * @param ble_manager A reference to the BLE manager instance to be used.
     * @param prov_manager A reference to another dependency needed by this service.
     */
    ExampleProtoService(BLEManager& ble_manager, ProvisioningManager& prov_manager);
    ~ExampleProtoService() = default;
    
    /**
     * @brief Required method. Initializes the service's internal state and registers it.
     * @param on_activity A function to call when a valid packet is received.
     */
    void Init(const ActivityCallback& on_activity);

    /**
     * @brief Required method, called by BleComm when a client connects.
     */
    void OnConnect();

    /**
     * @brief Required method, called by BleComm when a client disconnects.
     */
    void OnDisconnect();

private:
    bool HandleData(const void* data, size_t size);
    void SendProtoOutput(const std::vector<uint8_t>& payload);

    // --- Dependencies ---
    BLEManager& ble_manager_; // Stores a reference to the injected BLE Manager
    ProvisioningManager& prov_manager_;

    // --- Member Variables ---
    std::string service_uuid_;
    ActivityCallback on_activity_callback_;
};

} // namespace app

#endif // EXAMPLE_PROTO_SERVICE_H
