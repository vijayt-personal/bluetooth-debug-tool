#ifndef DEVICE_H
#define DEVICE_H

#include "BleComm.h"
#include "ExampleProtoService.h"
#include "ProvisioningManager.h"
#include "ble_manager.h" // The non-static version

#include <string>

namespace app {

/**
 * @brief Represents the main application, encapsulating all major components.
 *
 * This class owns the BLE manager, all services, and their dependencies.
 * It is responsible for initializing and running the main application logic.
 */
class Device {
public:
    /**
     * @brief Constructs the main Device application and all its components.
     */
    Device();
    ~Device() = default;

    /**
     * @brief Initializes all subsystems and starts the device's BLE advertising.
     */
    void Init();

    /**
     * @brief Runs the main application loop. This function does not return.
     */
    void Run();


private:
    // --- Core Components & Dependencies ---
    // Declaration order matters for initialization!
    
    // 1. The single instance of the BLE hardware manager.
    platform::connectivity::BLEManager ble_manager_;

    // 2. Dependencies required by services.
    ProvisioningManager prov_manager_;

    // 3. The services themselves.
    ExampleProtoService proto_service_;
    // TimeService time_service_; // Other services would be declared here

    // --- The Main BLE Orchestrator ---
    // This is declared last as it takes other components in its constructor.
    BleComm<ExampleProtoService /*, TimeService*/> ble_communicator_;
};

} // namespace app

#endif // DEVICE_H
------------------------------
#include "Device.h"
#include <thread>   // For simulating time passing in the main loop
#include <chrono>

namespace app {

// The member initializer list constructs all components in their declaration order.
Device::Device()
    // 1. ble_manager_ is default-constructed.
    : ble_manager_(),

      // 2. prov_manager_ is default-constructed.
      prov_manager_(),

      // 3. Construct proto_service_, passing its required dependencies.
      proto_service_(ble_manager_, prov_manager_),

      // 4. Finally, construct ble_communicator_, passing its dependencies
      //    and moving the already-constructed services into it.
      ble_communicator_(
          ble_manager_,                 // The BLE manager instance
          osal::Duration(15000),      // 15-second inactivity timeout
          std::move(proto_service_)   // The service(s) it will manage
      )
{
    // The constructor body is empty because the initializer list did all the work.
}

void Device::Init() {
    // Initialize the BLE communicator, which in turn initializes all the services.
    ble_communicator_.Init("MyDevice");

    // Start advertising
    ble_communicator_.StartAdvertising();
}

void Device::Run() {
    // This is the main application loop. In a real RTOS, this would be a task.
    while (true) {
        // The main loop can be used for other application logic.
        // There are no BleComm periodic tasks to call, thanks to the OSAL timer.
        
        // For example:
        // prov_manager_.CheckForUpdates();

        // Yield the task.
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

} // namespace app
-------------------------

#include "Device.h"

/**
 * @brief Main application entry point.
 */
int main() {
    // 1. Create a single instance of the entire application.
    //    The constructor will create and wire together all the components.
    app::Device my_device;

    // 2. Initialize the device subsystems.
    my_device.Init();

    // 3. Run the main application logic. This call blocks forever.
    my_device.Run();

    return 0; // This line is never reached.
}
