#ifndef BLE_COMM_H
#define BLE_COMM_H

#include "ble_manager.h"
#include "osal_timer.h"
#include <tuple>
#include <string>
#include <utility>
#include <functional>
#include <memory>
#include <iostream> // For logging/simulation

namespace app {

// Note: We now must use the non-static version of BLEManager
using platform::connectivity::BLEManager;

/**
 * @brief Manages the lifecycle and global events for a set of BLE services.
 *
 * This class orchestrates services by calling their Init, OnConnect, and
 * OnDisconnect methods. It is given a reference to the BLEManager instance
 * it should use (Dependency Injection).
 *
 * @tparam Services A parameter pack of the service types managed by this instance.
 */
template<typename... Services>
class BleComm {
public:
    /**
     * @brief Constructs the BleComm manager.
     * @param ble_manager A reference to the BLEManager instance to be used.
     * @param inactivity_timeout The timeout period before disconnecting.
     * @param services A variadic list of r-value references to the services this
     * instance will manage. The services are moved into the internal tuple.
     */
    BleComm(BLEManager& ble_manager, osal::Duration inactivity_timeout, Services&&... services)
        : ble_manager_(ble_manager),
          services_(std::make_tuple(std::forward<Services>(services)...)) {
        std::cout << "BleComm: Constructed." << std::endl;

        // Create the one-shot inactivity timer.
        inactivity_timer_ = std::make_unique<osal::Timer>(
            "BleInactivityTmr",
            [this]() { this->OnInactivityTimeout(); },
            inactivity_timeout,
            false // One-shot, not periodic
        );
    }

    ~BleComm() = default;

    // Prevent copy and assign
    BleComm(const BleComm&) = delete;
    BleComm& operator=(const BleComm&) = delete;

    /**
     * @brief Initializes the BLEManager and all managed services.
     * @param device_name The name for the BLE device.
     */
    void Init(const std::string& device_name) {
        std::cout << "BleComm: Initializing BLE with name: " << device_name << std::endl;

        // Use the injected BLEManager instance
        ble_manager_.Init(device_name);
        ble_manager_.SetConnectionCallback([this]() { this->OnBleConnect(); });
        ble_manager_.SetDisconnectionCallback([this]() { this->OnBleDisconnect(); });

        auto activity_callback = [this]() {
            this->RestartInactivityTimer();
        };

        // Pass the BLEManager reference to each service's Init method
        std::apply(
            [&](auto&... s) {
                (s.Init(ble_manager_, activity_callback), ...);
            },
            services_
        );
    }

    /**
     * @brief Starts BLE advertising.
     */
    void StartAdvertising() {
        std::cout << "BleComm: Starting advertising." << std::endl;
        ble_manager_.StartAdvertising();
    }

private:
    void OnBleConnect() {
        std::cout << "BleComm: Client connected. Notifying all services and starting inactivity timer." << std::endl;
        std::apply([](auto&... s) { (s.OnConnect(), ...); }, services_);
        inactivity_timer_->Start();
    }

    void OnBleDisconnect() {
        std::cout << "BleComm: Client disconnected. Notifying all services and stopping inactivity timer." << std::endl;
        inactivity_timer_->Stop();
        std::apply([](auto&... s) { (s.OnDisconnect(), ...); }, services_);
    }

    void RestartInactivityTimer() {
        std::cout << "BleComm: Activity detected, resetting inactivity timer." << std::endl;
        inactivity_timer_->Reset();
    }

    void OnInactivityTimeout() {
        std::cout << "BleComm: Inactivity timeout! Disconnecting client." << std::endl;
        ble_manager_.Disconnect();
    }

    // --- Member Variables ---
    BLEManager& ble_manager_; // Stores a reference to the manager
    std::tuple<Services...> services_;
    std::unique_ptr<osal::Timer> inactivity_timer_;
};

} // namespace app

#endif // BLE_COMM_H
