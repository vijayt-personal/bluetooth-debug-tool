#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H

#include <cstddef>  // For size_t
#include <cstdlib>  // For malloc, free
#include <new>      // For placement new
#include <utility>  // For std::move

/**
 * @brief Defines the behavior of the buffer when it is full.
 */
enum class OverwritePolicy {
  kOverwrite,       ///< Overwrite the oldest data when the buffer is full.
  kDoNotOverwrite,  ///< Do not add new data when the buffer is full.
};

/**
 * @brief A robust, thread-unsafe circular buffer for embedded systems using two-phase initialization.
 * @tparam T The type of the elements to be stored in the buffer.
 *
 * @details This class is designed for maximum safety in exception-free,
 * resource-constrained environments. It uses a two-phase initialization pattern.
 *
 * @note **USAGE PATTERN:**
 * 1. Default-construct the object: `CircularBuffer<MyType> my_buffer;`
 * 2. Initialize it using `Init()`: `if (my_buffer.Init(100)) { ... }`
 * 3. Use the buffer.
 * 4. Optionally call `Reset()` to deallocate and allow for re-initialization.
 */
template <typename T>
class CircularBuffer {
 public:
  /**
   * @brief Default constructor. Creates an empty, uninitialized buffer.
   */
  CircularBuffer() = default;

  /**
   * @brief Destructor. Automatically cleans up resources by calling Reset().
   */
  ~CircularBuffer() { Reset(); }

  // Disable copy and move operations.
  CircularBuffer(const CircularBuffer&) = delete;
  CircularBuffer& operator=(const CircularBuffer&) = delete;
  CircularBuffer(CircularBuffer&&) = delete;
  CircularBuffer& operator=(CircularBuffer&&) = delete;

  /**
   * @brief Initializes the buffer, allocating memory.
   * @param[in] capacity The maximum number of elements the buffer can hold. Must be > 0.
   * @param[in] policy The policy to use when the buffer is full.
   * @return true if initialization was successful, false otherwise.
   */
  bool Init(size_t capacity, OverwritePolicy policy = OverwritePolicy::kOverwrite) {
    // Prevent re-initialization of an already valid buffer to avoid memory leaks.
    if (buffer_ != nullptr) {
      return false;
    }
    // Prevent initialization with zero capacity.
    if (capacity == 0) {
      return false;
    }
    
    buffer_ = static_cast<T*>(malloc(sizeof(T) * capacity));
    if (buffer_ == nullptr) {
      return false; // Allocation failed.
    }

    // If allocation succeeded, set the parameters.
    capacity_ = capacity;
    policy_ = policy;
    return true;
  }

  /**
   * @brief Deallocates memory and resets the buffer to an uninitialized state.
   * @details Allows the object to be re-initialized with Init().
   */
  void Reset() {
    if (buffer_ == nullptr) {
      return; // Already reset or was never initialized.
    }
    Clear();
    free(buffer_);

    // Reset all members to their default state.
    buffer_ = nullptr;
    capacity_ = 0;
    head_ = 0;
    tail_ = 0;
    size_ = 0;
  }

  /**
   * @brief Adds an item to the buffer.
   * @return false if the buffer is uninitialized, full (with kDoNotOverwrite), or on other errors.
   */
  bool Push(const T& item) {
    // Use the buffer pointer as the "is initialized" check.
    if (buffer_ == nullptr || (IsFull() && policy_ == OverwritePolicy::kDoNotOverwrite)) {
      return false;
    }
    
    if (IsFull()) { // This implies overwrite policy is active
      buffer_[tail_].~T();
      tail_ = (tail_ + 1) % capacity_;
    } else {
      size_++;
    }

    new (&buffer_[head_]) T(item);
    head_ = (head_ + 1) % capacity_;
    return true;
  }

  /**
   * @brief Removes the oldest item from the buffer.
   * @return false if the buffer is uninitialized or empty.
   */
  bool Pop(T* item) {
    if (buffer_ == nullptr || IsEmpty()) {
      return false;
    }
    *item = std::move(buffer_[tail_]);
    buffer_[tail_].~T();
    tail_ = (tail_ + 1) % capacity_;
    size_--;
    return true;
  }

  /** @brief Checks if the buffer is empty. */
  bool IsEmpty() const { return size_ == 0; }

  /** @brief Checks if the buffer is full. */
  bool IsFull() const { return (buffer_ != nullptr) && (size_ == capacity_); }

  /** @brief Gets the current number of elements. */
  size_t Size() const { return size_; }

  /** @brief Gets the maximum capacity. */
  size_t Capacity() const { return capacity_; }

 private:
  /** @brief Internal clear that only handles element destruction, not deallocation. */
  void Clear() {
    while (size_ > 0) {
      buffer_[tail_].~T();
      tail_ = (tail_ + 1) % capacity_;
      size_--;
    }
  }

  // Members are intentionally not const to allow for two-phase initialization.
  size_t capacity_ = 0;
  OverwritePolicy policy_ = OverwritePolicy::kOverwrite;
  T* buffer_ = nullptr;

  size_t head_ = 0;
  size_t tail_ = 0;
  size_t size_ = 0;
};

#endif  // CIRCULAR_BUFFER_H