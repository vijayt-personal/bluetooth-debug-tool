#ifndef BACKLOG_ENTRY_H
#define BACKLOG_ENTRY_H

#include <cstdint> // For uint8_t, etc.
#include <cstddef> // For size_t

// Define the different types of packets you might handle.
enum class PacketType : uint8_t {
  kControl,
  kData,
  kAcknowledgement,
  kError
};

// Define a maximum size for the payload. This memory will be part of the
// struct itself, making each struct a fixed size.
constexpr size_t kMaxPayloadSize = 64;

/**
 * @brief Represents a single entry in our data backlog.
 * @details This is a simple Plain Old Data (POD) style struct. The compiler
 * will automatically generate correct copy/move/destruction operations for it,
 * so we don't need to write any special member functions.
 */
struct BacklogEntry {
  PacketType type;
  size_t payload_size = 0; // The actual number of bytes used in the payload
  uint8_t payload[kMaxPayloadSize] = {0};
};

#endif // BACKLOG_ENTRY_H