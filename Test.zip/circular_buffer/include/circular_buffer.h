#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H

#include <cstddef>  // For size_t
#include <memory>   // For std::bad_alloc
#include <new>      // For placement new
#include <stdexcept> // For std::runtime_error (or other exceptions)

/**
 * @brief Defines the behavior of the buffer when it is full.
 */
enum class OverwritePolicy {
  kOverwrite,       ///< Overwrite the oldest data when the buffer is full.
  kDoNotOverwrite,  ///< Do not add new data when the buffer is full.
};

/**
 * @brief A thread-unsafe, templated circular buffer.
 * @tparam T The type of the elements to be stored in the buffer.
 *
 * @details This class implements a circular buffer with a capacity that can be
 * defined at runtime. It uses `malloc` and `free` for memory management.
 * The behavior upon reaching full capacity is configurable via an OverwritePolicy.
 * This implementation requires careful handling of object lifetimes using
 * placement new and explicit destructor calls, especially for non-POD types.
 */
template <typename T>
class CircularBuffer {
 public:
  /**
   * @brief Constructs a new Circular Buffer.
   * @param[in] capacity The maximum number of elements the buffer can hold. Must be > 0.
   * @param[in] policy The policy to use when the buffer is full.
   * @throw std::bad_alloc If memory allocation for the buffer fails.
   * @throw std::invalid_argument If capacity is 0.
   */
  explicit CircularBuffer(size_t capacity,
                          OverwritePolicy policy = OverwritePolicy::kOverwrite)
      : capacity_(capacity),
        policy_(policy),
        buffer_(static_cast<T*>(malloc(sizeof(T) * capacity_))) {
    if (capacity_ == 0) {
      throw std::invalid_argument("Buffer capacity cannot be zero.");
    }
    if (!buffer_) {
      throw std::bad_alloc();
    }
  }

  /**
   * @brief Destroys the Circular Buffer.
   * @details This destructor will explicitly call the destructor for any
   * remaining objects in the buffer before freeing the allocated memory.
   */
  ~CircularBuffer() {
    Clear();
    free(buffer_);
  }

  // Disable copy and move operations to prevent shallow copies and simplify
  // manual memory management.
  CircularBuffer(const CircularBuffer&) = delete;
  CircularBuffer& operator=(const CircularBuffer&) = delete;
  CircularBuffer(CircularBuffer&&) = delete;
  CircularBuffer& operator=(CircularBuffer&&) = delete;

  /**
   * @brief Adds an item to the buffer.
   * @param[in] item The item to be added to the buffer.
   * @return true if the item was successfully pushed.
   * @return false if the buffer is full and the policy is kDoNotOverwrite.
   */
  bool Push(const T& item) {
    if (IsFull()) {
      if (policy_ == OverwritePolicy::kDoNotOverwrite) {
        return false;
      }
      // Overwrite the oldest element by calling its destructor and advancing tail.
      buffer_[tail_].~T();
      tail_ = (tail_ + 1) % capacity_;
    } else {
      // Only increment size if we are not overwriting an existing element.
      size_++;
    }
    // Use placement new to construct the new object at the head.
    new (&buffer_[head_]) T(item);
    head_ = (head_ + 1) % capacity_;
    return true;
  }

  /**
   * @brief Removes the oldest item from the buffer.
   * @param[out] item Pointer to a variable where the popped item will be stored.
   * @return true if an item was successfully popped.
   * @return false if the buffer is empty.
   */
  bool Pop(T* item) {
    if (IsEmpty()) {
      return false;
    }
    // Move the object from the buffer before destroying it.
    *item = std::move(buffer_[tail_]);
    // Explicitly call the destructor of the object being removed.
    buffer_[tail_].~T();
    tail_ = (tail_ + 1) % capacity_;
    size_--;
    return true;
  }

  /**
   * @brief Checks if the buffer is empty.
   * @return true if the buffer contains no elements.
   */
  bool IsEmpty() const { return size_ == 0; }

  /**
   * @brief Checks if the buffer is full.
   * @return true if the number of elements equals the capacity.
   */
  bool IsFull() const { return size_ == capacity_; }

  /**
   * @brief Gets the current number of elements in the buffer.
   * @return The number of elements currently stored.
   */
  size_t Size() const { return size_; }

  /**
   * @brief Gets the maximum capacity of the buffer.
   * @return The maximum number of elements the buffer can hold.
   */
  size_t Capacity() const { return capacity_; }

  /**
   * @brief Removes all elements from the buffer.
   * @details This method ensures that the destructors of all contained
   * objects are called.
   */
  void Clear() {
    while (!IsEmpty()) {
      buffer_[tail_].~T();
      tail_ = (tail_ + 1) % capacity_;
      size_--;
    }
    // Reset indices for clarity.
    head_ = 0;
    tail_ = 0;
  }

 private:
  T* const buffer_;  ///< Pointer to the allocated buffer memory.
  const size_t capacity_;   ///< The maximum capacity of the buffer.
  const OverwritePolicy policy_;  ///< The configured overwrite policy.

  size_t head_ = 0;  ///< Index of the next free slot to write to.
  size_t tail_ = 0;  ///< Index of the oldest element to read from.
  size_t size_ = 0;  ///< The current number of elements in the buffer.
};

#endif  // CIRCULAR_BUFFER_H
