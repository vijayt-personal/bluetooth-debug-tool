#include "osal_mutex_impl.h"
#include <esp_log.h>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalMutex";

MutexImpl::MutexImpl() : mutex_handle_(nullptr) {
    // The FreeRTOS ...RecursiveMutex... APIs create a mutex suitable for recursive locking.
    mutex_handle_ = xSemaphoreCreateRecursiveMutex();
    if (mutex_handle_ == nullptr) {
        ESP_LOGE(kTag, "Failed to create recursive mutex.");
    }
}

MutexImpl::~MutexImpl() {
    if (mutex_handle_ != nullptr) {
        vSemaphoreDelete(mutex_handle_);
        mutex_handle_ = nullptr;
    }
}

bool MutexImpl::Lock(Duration timeout) {
    if (mutex_handle_ == nullptr) {
        return false;
    }

    TickType_t ticks_to_wait;
    if (timeout == kMaxDuration) {
        ticks_to_wait = portMAX_DELAY;
    } else {
        ticks_to_wait = pdMS_TO_TICKS(timeout.count());
        // Ensure a minimum wait of 1 tick for any non-zero duration that might round down to 0.
        if (timeout.count() > 0 && ticks_to_wait == 0) {
            ticks_to_wait = 1;
        }
    }
    return (xSemaphoreTakeRecursive(mutex_handle_, ticks_to_wait) == pdTRUE);
}

bool MutexImpl::Unlock() {
    if (mutex_handle_ == nullptr) {
        return false;
    }
    return (xSemaphoreGiveRecursive(mutex_handle_) == pdTRUE);
}

} // namespace osal
