#pragma once

#include "osal_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

namespace osal {

/**
 * @class SemaphoreImpl
 * @brief The private implementation of the osal::Semaphore.
 */
class SemaphoreImpl {
public:
    SemaphoreImpl(uint32_t max_count, uint32_t initial_count);
    ~SemaphoreImpl();

    SemaphoreImpl(const SemaphoreImpl&) = delete;
    SemaphoreImpl& operator=(const SemaphoreImpl&) = delete;
    SemaphoreImpl(SemaphoreImpl&&) = default;
    SemaphoreImpl& operator=(SemaphoreImpl&&) = default;

    bool Acquire(Duration timeout);
    bool Release();
    bool ReleaseFromISR(bool& higher_priority_task_woken);
    uint32_t GetCount() const;

    SemaphoreHandle_t semaphore_handle_;
};

} // namespace osal
