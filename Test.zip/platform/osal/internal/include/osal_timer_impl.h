#pragma once

#include "osal_timer.h" 
#include "freertos/FreeRTOS.h"
#include "freertos/timers.h"
#include <string>

namespace osal {

/**
 * @class TimerImpl
 * @brief The private implementation of the osal::Timer.
 */
class TimerImpl {
public:
    TimerImpl(const std::string& name,
              TimerCallback callback,
              Duration period,
              bool auto_reload);
    ~TimerImpl();
    
    TimerImpl(const TimerImpl&) = delete;
    TimerImpl& operator=(const TimerImpl&) = delete;
    TimerImpl(TimerImpl&&) = default;
    TimerImpl& operator=(TimerImpl&&) = default;

    bool Start(Duration block_time);
    bool Stop(Duration block_time);
    bool Reset(Duration block_time);
    bool ChangePeriod(Duration new_period, Duration block_time);
    bool IsRunning() const;

    TimerHandle_t timer_handle_;
    std::string name_;
    // The std::function callback must be stored within the implementation
    // object to guarantee its lifetime.
    TimerCallback user_callback_;
};

} // namespace osal
