#pragma once

#include "osal_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

namespace osal {

/**
 * @class EventGroupImpl
 * @brief The private implementation of the osal::EventGroup.
 */
class EventGroupImpl {
public:
    EventGroupImpl();
    ~EventGroupImpl();

    EventGroupImpl(const EventGroupImpl&) = delete;
    EventGroupImpl& operator=(const EventGroupImpl&) = delete;
    EventGroupImpl(EventGroupImpl&&) = default;
    EventGroupImpl& operator=(EventGroupImpl&&) = default;

    EventBits SetBits(EventBits bits_to_set);
    EventBits ClearBits(EventBits bits_to_clear);
    EventBits WaitBits(EventBits bits_to_wait_for, bool clear_on_exit, bool wait_for_all, Duration timeout);
    EventBits GetBits() const;
    EventBits SetBitsFromISR(EventBits bits_to_set, bool& higher_priority_task_woken);
    EventBits Sync(EventBits bits_to_set, EventBits bits_to_wait_for, Duration timeout);

    EventGroupHandle_t event_group_handle_;
};

} // namespace osal
