#pragma once

#include "osal_types.h"
#include <memory>

/**
 * @file osal_semaphore.h
 * @brief Provides a C++ wrapper for a counting semaphore.
 */

namespace osal {

class SemaphoreImpl; // Forward declaration

/**
 * @class Semaphore
 * @brief A counting semaphore synchronization primitive.
 *
 * @details Semaphores are used to control access to a shared resource or for
 * synchronization between tasks. A counting semaphore maintains a count
 * from zero to a specified maximum value.
 */
class Semaphore {
public:
    /**
     * @brief Constructs a counting semaphore.
     * @param max_count The maximum count the semaphore can hold. For a binary
     * semaphore, use a value of 1. Must be greater than 0.
     * @param initial_count The initial count of the semaphore upon creation.
     * Defaults to 0.
     */
    explicit Semaphore(uint32_t max_count, uint32_t initial_count = 0);
    
    /**
     * @brief Destroys the Semaphore and releases its resources.
     */
    ~Semaphore();

    // Non-copyable
    Semaphore(const Semaphore&) = delete;
    Semaphore& operator=(const Semaphore&) = delete;

    // Movable
    Semaphore(Semaphore&& other) noexcept;
    Semaphore& operator=(Semaphore&& other) noexcept;

    /**
     * @brief Acquires (takes or decrements) the semaphore.
     * @param timeout The maximum duration to wait for the semaphore to become
     * available. Use osal::kMaxDuration to wait indefinitely.
     * @return true if the semaphore was acquired, false on timeout or error.
     */
    bool Acquire(Duration timeout = kMaxDuration);

    /**
     * @brief Releases (gives or increments) the semaphore.
     * @return true if the semaphore was released successfully, false on error
     * (e.g., if the semaphore is already at its maximum count).
     */
    bool Release();

    /**
     * @brief Releases the semaphore from an Interrupt Service Routine (ISR).
     * @param [out] higher_priority_task_woken Set to true by the underlying OS
     * if releasing the semaphore caused a task of higher priority than the
     * currently running task to unblock. A context switch should be requested
     * if this is the case.
     * @return true if the semaphore was released successfully, false on error.
     */
    bool ReleaseFromISR(bool& higher_priority_task_woken);
    
    /**
     * @brief Gets the current count of the semaphore.
     * @return The number of available resources the semaphore is guarding.
     * Returns 0 if the semaphore is invalid.
     */
    uint32_t GetCount() const;

private:
    std::unique_ptr<SemaphoreImpl> impl_;
};

} // namespace osal
