#pragma once

#include "osal_types.h"
#include <memory>
#include <functional>
#include <string>

/**
 * @file osal_task.hpp
 * @brief Provides a C++ wrapper for a FreeRTOS task.
 */

namespace osal {

// Forward declaration of the implementation class to hide FreeRTOS details.
class TaskImpl;

/**
 * @brief Defines the function signature for a task entry point.
 * @param userData A void pointer to user-defined data passed during task creation.
 */
using TaskFunction = std::function<void(void* userData)>;

/**
 * @class Task
 * @brief A class that encapsulates a FreeRTOS task, managing its lifecycle.
 *
 * @details The Task object creates and starts a FreeRTOS task upon construction.
 * The underlying FreeRTOS task will run until its function returns or
 * it is explicitly deleted. The C++ Task object can go out of scope,
 * and the FreeRTOS task will continue to run (detached).
 */
class Task {
public:
    /**
     * @brief Constructs a Task and starts its execution.
     * @param task_function The function the task will execute.
     * @param user_data A pointer to user data that will be passed to the task
     * function. Can be nullptr.
     * @param name A descriptive name for the task (used in debugging).
     * @param stack_depth The size of the task stack in words (e.g., 4-byte words on ESP32).
     * @param priority The priority of the task (0 is the lowest).
     * @param core_id The CPU core to pin the task to. Use osal::kNoCoreAffinity
     * to allow the scheduler to choose a core.
     */
    Task(TaskFunction task_function,
         void* user_data,
         const std::string& name,
         uint32_t stack_depth = kDefaultTaskStackDepth,
         uint32_t priority = kDefaultTaskPriority,
         int core_id = kNoCoreAffinity);

    /**
     * @brief Destroys the Task C++ object.
     * @warning This does NOT automatically delete the underlying FreeRTOS task.
     * The running task becomes detached. To stop the task, it must
     * either return from its function or be explicitly deleted via
     * the Delete() method.
     */
    ~Task();

    // The Task is non-copyable.
    Task(const Task&) = delete;
    Task& operator=(const Task&) = delete;

    // The Task is movable.
    Task(Task&& other) noexcept;
    Task& operator=(Task&& other) noexcept;

    /**
     * @brief Suspends the task's execution.
     */
    void Suspend();

    /**
     * @brief Resumes a suspended task.
     */
    void Resume();

    /**
     * @brief Forcibly deletes the underlying FreeRTOS task.
     * @warning Use with extreme caution. This can lead to resource leaks if
     * the task has not cleaned up its allocated resources (e.g.,
     * memory, mutexes). The preferred method is for a task to manage
     * its own lifecycle and exit cleanly by returning from its function.
     */
    void Delete();

    /**
     * @brief Puts the calling task to sleep for a specified duration.
     * @param duration The amount of time to sleep. The units are determined by
     * the osal::Duration type (milliseconds).
     */
    static void SleepFor(Duration duration);

    /**
     * @brief Gets the current system tick count from the FreeRTOS kernel.
     * @return The number of ticks since the scheduler started.
     */
    static uint32_t GetTickCount();

    /**
     * @brief Gets the minimum amount of free stack space for the *calling* task.
     * @details This is the stack "high-water mark". A lower number indicates the task
     * has used more of its stack and has come closer to overflowing.
     * @return The minimum free stack space in words.
     */
    static uint32_t GetMinFreeStackWords();

    /**
     * @brief Checks if the task was created successfully.
     * @return true if the underlying FreeRTOS task handle is valid, false otherwise.
     */
    bool IsValid() const;

private:
    std::unique_ptr<TaskImpl> impl_;
};

} // namespace osal
