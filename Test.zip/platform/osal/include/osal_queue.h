#pragma once

#include "osal_types.h"
#include <memory>
#include <cstddef> // For size_t

/**
 * @file osal_queue.h
 * @brief Provides a C++ wrapper for a FreeRTOS queue.
 */

namespace osal {

class QueueImpl; // Forward declaration

/**
 * @class Queue
 * @brief A thread-safe FIFO (First-In, First-Out) queue.
 *
 * @details Queues allow tasks and ISRs to send and receive data safely.
 * The queue can store a fixed number of items of a fixed size.
 */
class Queue {
public:
    /**
     * @brief Constructs a Queue.
     * @param item_count The maximum number of items the queue can hold.
     * @param item_size The size, in bytes, of each item in the queue.
     */
    Queue(uint32_t item_count, uint32_t item_size);

    /**
     * @brief Destroys the Queue and releases its resources.
     */
    ~Queue();

    // Non-copyable
    Queue(const Queue&) = delete;
    Queue& operator=(const Queue&) = delete;

    // Movable
    Queue(Queue&& other) noexcept;
    Queue& operator=(Queue&& other) noexcept;

    /**
     * @brief Sends (posts) an item to the back of the queue.
     * @param item_to_send A pointer to the item to be copied into the queue.
     * @param timeout The maximum duration to wait if the queue is full. Use osal::kMaxDuration to wait indefinitely.
     * @return true if the item was successfully sent, false on timeout or error.
     */
    bool Send(const void* item_to_send, Duration timeout = kMaxDuration);

    /**
     * @brief Receives (retrieves) an item from the front of the queue.
     * @param buffer A pointer to a buffer where the received item will be copied.
     * @param timeout The maximum duration to wait if the queue is empty. Use osal::kMaxDuration to wait indefinitely.
     * @return true if an item was successfully received, false on timeout or error.
     */
    bool Receive(void* buffer, Duration timeout = kMaxDuration);

    /**
     * @brief Peeks at an item from the front of the queue without removing it.
     * @param buffer A pointer to a buffer where the peeked item will be copied.
     * @param timeout The maximum duration to wait if the queue is empty. Use osal::kMaxDuration to wait indefinitely.
     * @return true if an item was successfully peeked, false on timeout or error.
     */
    bool Peek(void* buffer, Duration timeout = kMaxDuration) const;
    
    /**
     * @brief Sends an item to the back of the queue from an ISR.
     * @param item_to_send A pointer to the item to be copied into the queue.
     * @param [out] higher_priority_task_woken Set to true by the underlying OS
     * if sending to the queue caused a higher priority task to unblock.
     * @return true if the item was successfully sent, false if the queue was full.
     */
    bool SendFromISR(const void* item_to_send, bool& higher_priority_task_woken);

    /**
     * @brief Receives an item from the front of the queue from an ISR.
     * @param buffer A pointer to a buffer where the received item will be copied.
     * @param [out] higher_priority_task_woken Set to true by the underlying OS
     * if receiving from the queue caused a higher priority task to unblock.
     * @return true if an item was successfully received, false if the queue was empty.
     */
    bool ReceiveFromISR(void* buffer, bool& higher_priority_task_woken);

    /**
     * @brief Gets the number of messages currently in the queue.
     * @return The number of items in the queue. Returns 0 if the handle is invalid.
     */
    uint32_t GetCount() const;

    /**
     * @brief Resets the queue to its original empty state.
     * @return true if the reset was successful, false otherwise.
     */
    bool Reset();


private:
    std::unique_ptr<QueueImpl> impl_;
};

} // namespace osal
