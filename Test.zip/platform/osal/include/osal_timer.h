#pragma once

#include "osal_types.h"
#include <memory>
#include <functional>
#include <string>

/**
 * @file osal_timer.h
 * @brief Provides a C++ wrapper for a software timer.
 */

namespace osal {

class TimerImpl; // Forward declaration

/**
 * @brief Defines the function signature for a timer callback.
 */
using TimerCallback = std::function<void()>;

/**
 * @class Timer
 * @brief A software timer that executes a callback function upon expiration.
 *
 * @details Timers are managed by a central timer service task within the OS.
 * They are suitable for events that do not require high-precision timing.
 * They can be configured as one-shot or periodic (auto-reloading).
 */
class Timer {
public:
    /**
     * @brief Constructs a Timer. The timer is not started automatically.
     * @param name A descriptive name for the timer (for debugging).
     * @param callback The function to execute when the timer expires.
     * @param period The period of the timer.
     * @param auto_reload If true, the timer is periodic. If false, it is a
     * one-shot timer.
     */
    Timer(const std::string& name,
          TimerCallback callback,
          Duration period,
          bool auto_reload);

    /**
     * @brief Destroys the Timer and removes it from the OS timer service.
     */
    ~Timer();

    // Non-copyable
    Timer(const Timer&) = delete;
    Timer& operator=(const Timer&) = delete;

    // Movable
    Timer(Timer&& other) noexcept;
    Timer& operator=(Timer&& other) noexcept;

    /**
     * @brief Starts the timer.
     * @param block_time The maximum duration to wait if the command cannot be
     * sent to the timer service task immediately.
     * @return true if the start command was successfully sent, false otherwise.
     */
    bool Start(Duration block_time = Duration(0));

    /**
     * @brief Stops the timer.
     * @param block_time The maximum duration to wait for the stop command to be sent.
     * @return true if the stop command was successfully sent, false otherwise.
     */
    bool Stop(Duration block_time = Duration(0));

    /**
     * @brief Resets the timer's expiration time.
     * @details If the timer was running, its expiry time is recalculated from the
     * moment Reset is called. If it was stopped, it is started.
     * @param block_time The maximum duration to wait for the reset command to be sent.
     * @return true if the reset command was successfully sent, false otherwise.
     */
    bool Reset(Duration block_time = Duration(0));

    /**
     * @brief Changes the period of the timer.
     * @param new_period The new period for the timer.
     * @param block_time The maximum duration to wait for the command to be sent.
     * @return true if the command was successfully sent, false otherwise.
     */
    bool ChangePeriod(Duration new_period, Duration block_time = Duration(0));

    /**
     * @brief Checks if the timer is currently active (running).
     * @return true if the timer has been started and has not yet expired (or is
     * periodic), false otherwise.
     */
    bool IsRunning() const;

private:
    std::unique_ptr<TimerImpl> impl_;
};

} // namespace osal
