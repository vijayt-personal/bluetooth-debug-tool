#include "osal_queue.h"
#include "osal_queue_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalQueue";

Queue::Queue(uint32_t item_count, uint32_t item_size)
    : impl_(std::make_unique<QueueImpl>(item_count, item_size)) {}

Queue::~Queue() = default;

Queue::Queue(Queue&& other) noexcept = default;

Queue& Queue::operator=(Queue&& other) noexcept = default;

bool Queue::Send(const void* item_to_send, Duration timeout) {
    if (!impl_ || !impl_->queue_handle_) {
        ESP_LOGE(kTag, "Send: Queue not properly initialized.");
        return false;
    }
    return impl_->Send(item_to_send, timeout);
}

bool Queue::Receive(void* buffer, Duration timeout) {
    if (!impl_ || !impl_->queue_handle_) {
        ESP_LOGE(kTag, "Receive: Queue not properly initialized.");
        return false;
    }
    return impl_->Receive(buffer, timeout);
}

bool Queue::Peek(void* buffer, Duration timeout) const {
    if (!impl_ || !impl_->queue_handle_) {
        ESP_LOGE(kTag, "Peek: Queue not properly initialized.");
        return false;
    }
    return impl_->Peek(buffer, timeout);
}

bool Queue::SendFromISR(const void* item_to_send, bool& higher_priority_task_woken) {
    if (!impl_ || !impl_->queue_handle_) {
        higher_priority_task_woken = false;
        return false;
    }
    return impl_->SendFromISR(item_to_send, higher_priority_task_woken);
}

bool Queue::ReceiveFromISR(void* buffer, bool& higher_priority_task_woken) {
    if (!impl_ || !impl_->queue_handle_) {
        higher_priority_task_woken = false;
        return false;
    }
    return impl_->ReceiveFromISR(buffer, higher_priority_task_woken);
}

uint32_t Queue::GetCount() const {
    if (!impl_ || !impl_->queue_handle_) {
        ESP_LOGE(kTag, "GetCount: Queue not properly initialized.");
        return 0;
    }
    return impl_->GetCount();
}

bool Queue::Reset() {
    if (!impl_ || !impl_->queue_handle_) {
        ESP_LOGE(kTag, "Reset: Queue not properly initialized.");
        return false;
    }
    return impl_->Reset();
}

} // namespace osal
