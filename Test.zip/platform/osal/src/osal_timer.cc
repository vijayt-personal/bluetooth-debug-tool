#include "osal_timer.h"
#include "osal_timer_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalTimer";

Timer::Timer(const std::string& name,
             TimerCallback callback,
             Duration period,
             bool auto_reload)
    : impl_(std::make_unique<TimerImpl>(name, std::move(callback), period, auto_reload)) {}

Timer::~Timer() = default;

Timer::Timer(Timer&& other) noexcept = default;

Timer& Timer::operator=(Timer&& other) noexcept = default;

bool Timer::Start(Duration block_time) {
    if (!impl_ || !impl_->timer_handle_) {
        ESP_LOGE(kTag, "Start: Timer not properly initialized.");
        return false;
    }
    return impl_->Start(block_time);
}

bool Timer::Stop(Duration block_time) {
    if (!impl_ || !impl_->timer_handle_) {
        ESP_LOGE(kTag, "Stop: Timer not properly initialized.");
        return false;
    }
    return impl_->Stop(block_time);
}

bool Timer::Reset(Duration block_time) {
    if (!impl_ || !impl_->timer_handle_) {
        ESP_LOGE(kTag, "Reset: Timer not properly initialized.");
        return false;
    }
    return impl_->Reset(block_time);
}

bool Timer::ChangePeriod(Duration new_period, Duration block_time) {
    if (!impl_ || !impl_->timer_handle_) {
        ESP_LOGE(kTag, "ChangePeriod: Timer not properly initialized.");
        return false;
    }
    return impl_->ChangePeriod(new_period, block_time);
}

bool Timer::IsRunning() const {
    if (!impl_ || !impl_->timer_handle_) {
        return false;
    }
    return impl_->IsRunning();
}

} // namespace osal
