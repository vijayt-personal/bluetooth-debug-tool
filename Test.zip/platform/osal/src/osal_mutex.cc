#include "osal_mutex.h"
#include "osal_mutex_impl.h"
#include <esp_log.h>
#include <utility>

namespace osal {

// File-static logger tag
static const char* kTag = "OsalMutex";

Mutex::Mutex() : impl_(std::make_unique<MutexImpl>()) {}

Mutex::~Mutex() = default;

Mutex::Mutex(Mutex&& other) noexcept = default;

Mutex& Mutex::operator=(Mutex&& other) noexcept = default;

bool Mutex::Lock(Duration timeout) {
    if (!impl_ || !impl_->mutex_handle_) {
        ESP_LOGE(kTag, "Lock: Mutex not properly initialized.");
        return false;
    }
    return impl_->Lock(timeout);
}

bool Mutex::TryLock() {
    return Lock(Duration(0));
}

bool Mutex::Unlock() {
    if (!impl_ || !impl_->mutex_handle_) {
        ESP_LOGE(kTag, "Unlock: Mutex not properly initialized.");
        return false;
    }
    return impl_->Unlock();
}

} // namespace osal
